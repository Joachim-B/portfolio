import {
    ChatInputCommandInteraction,
    Guild,
    Message,
    SlashCommandBuilder,
} from 'discord.js'
import QuoteData from '../../../db-objects/data/quote-data'
import { Categories } from '../../../utils/common/sharedEnums'
import { InteractionError, MWEmbedBuilder } from '../../../utils/common/sharedElements'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'

export default class QuoteCommand extends BaseSlashCommand {
    category = Categories.misc
    command = new SlashCommandBuilder()
        .setName('quote')
        .setDescription('Send a random quote from the server')
        .addIntegerOption(o => o
            .setName('range')
            .setDescription('Number of recent quotes to choose from (default:150)')
            .setMinValue(1)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const range = interaction.options.getInteger('range') ?? 150
        const embed = await this.getQuoteEmbed(interaction.guild, range)
        await interaction.reply({ embeds: [embed] })
    }

    async getQuoteEmbed(guild: Guild, range: number, charactersLimit?: number) {
        const data = new QuoteData(guild.id)
        await data.loadAsync()

        if (!data.channelId) {
            throw new InteractionError('The quote command is not setup!', false)
        }
        const quoteChannel = await this.dUtils().getTextChannelAsync(data.channelId, guild)
        const filter = charactersLimit
            ? (m: Message) => (m.content ?? '' != '') && !m.author.bot && !m.hasThread && m.content.length <= charactersLimit
            : (m: Message) => (m.content ?? '' != '') && !m.author.bot && !m.hasThread
        const messages = (await this.dUtils().getMessagesAsync(range, quoteChannel.id, guild, filter))

        const selectedMessage = this.dUtils().utils.getRandomValue(messages)
        if (!selectedMessage) {
            throw new InteractionError('No quotes have been found...')
        }
        const author = selectedMessage.author
        const reply = selectedMessage.content

        const embed = new MWEmbedBuilder()
            .setAuthor({ name: author.displayName, iconURL: author.avatarURL(), url: selectedMessage.url })
            .setDescription(reply + `\n[Message link](${selectedMessage.url})`)

        return embed
    }
}

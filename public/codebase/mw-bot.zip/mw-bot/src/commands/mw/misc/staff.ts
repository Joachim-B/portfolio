import { SlashCommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import { Categories } from '../../../utils/common/sharedEnums';
import StaffData from '../../../db-objects/data/staff';
import { MWEmbedBuilder } from '../../../utils/common/sharedElements';
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand';

export default class StaffCommand extends BaseSlashCommand {
    command = new SlashCommandBuilder()
        .setName('staff')
        .setDescription('List all the staff members')
    category = Categories.misc;
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new StaffData(interaction.guildId)
        await data.loadAsync()

        const staffRoleIds = data.staffRoles;
        const fetchedRoles = await Promise.all(staffRoleIds.map(id => this.dUtils().getRoleAsync(id, interaction.guild)))
        const hasMissingRoles = fetchedRoles.some(role => role == undefined);
        const staffRoles = fetchedRoles.filter(role => role != undefined);

        const description = staffRoles
            .sort((a, b) => b.position - a.position)
            .map(role => {
                const memberList = role.members.map(m => `<@${m.id}>`).join(', ');
                const usernameList = role.members.map(m => `\`@${m.user.username}\``).join(', ');
                return `**<@&${role.id}>** :\n- ${memberList}\n- ${usernameList}\n`;
            })
            .join('\n');

        const embed = new MWEmbedBuilder()
            .setTitle('Official list of Staff members')
            .setDescription(description || 'No staff roles have been setup.')

        await interaction.reply({ embeds: [embed] })

        if (hasMissingRoles) {
            data.staffRoles = staffRoles.map(r => r.id)
            await data.saveAsync()
        }
    }
}
import { SlashCommandBuilder, ChatInputCommandInteraction } from 'discord.js'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'
import { Categories } from '../../../utils/common/sharedEnums'
import PaladinData from '../../../db-objects/data/paladins'
import { InteractionError, MWEmbedBuilder } from '../../../utils/common/sharedElements'

export default class PaladinsCommand extends BaseSlashCommand {
    category = Categories.misc
    command = new SlashCommandBuilder()
        .setName('paladins')
        .setDescription('Display the current Paladins')

    async execute(interaction: ChatInputCommandInteraction) {
        const data = new PaladinData(interaction.guildId)
        await data.loadAsync()

        if (!data.paladinRoleId) {
            throw new InteractionError('This command is not setup yet.')
        }

        const paladinRole = await this.dUtils().getRoleAsync(data.paladinRoleId, interaction.guild)
        const headPaladinRole = await this.dUtils().getRoleAsync(data.headPaladinRoleId, interaction.guild)

        if (!paladinRole) {
            throw new InteractionError('The Paladin role doesn\'t exist !', false)
        }

        let description = ''
        let paladins = paladinRole.members

        if (headPaladinRole && headPaladinRole.members.size > 0) {
            description += headPaladinRole.members.map(m => `- ${m} \`@${m.user.username}\` **- Head Paladin**`).join('\n') ?? ''
            description += '\n'
            const headPaladinMemberIds = new Set<string>(headPaladinRole.members.keys());
            paladins = paladins.filter(m => !headPaladinMemberIds.has(m.id));
        }

        description += paladins.map(m => `- ${m} \`@${m.user.username}\``).join('\n')

        const embed = new MWEmbedBuilder()

        description = `### List of the Current Paladins\n${description}`

        if (data.description) {
            const [part1, part2] = data.description.split('|')
            if (part2) {
                embed.setTitle(part1)
                description = `${part2}\n${description}`
            }
            else {
                description = `${part1}\n${description}`
            }
        }

        embed.setDescription(description)
        await embed.displayMWEmbed(interaction)
    }
}
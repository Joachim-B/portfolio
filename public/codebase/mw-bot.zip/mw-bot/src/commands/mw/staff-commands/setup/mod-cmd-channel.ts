import {
    ChannelType,
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import ModCmdData from '../../../../db-objects/data/mod-cmd-data'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class ModCmdChannelSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('mod-cmd-channel')
        .setDescription('Setup mod commands channel')
        .addChannelOption((option) =>
            option
                .setName('channel')
                .setDescription('The channel for mod commands')
                .setRequired(false)
                .addChannelTypes(ChannelType.GuildText)
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const channel = interaction.options.getChannel('channel')

        const data = new ModCmdData(interaction.guild.id)
        await data.loadAsync()

        if (!channel) {
            data.channelId = null
            await interaction.reply({
                content: 'Mod command channel reset.',
            })
            return
        }

        this.dUtils().mustBeTextChannelAsync(channel)

        data.channelId = channel.id
        await data.saveAsync()

        await interaction.reply({
            content: 'Mod command channel updated.',
        })
    }
}

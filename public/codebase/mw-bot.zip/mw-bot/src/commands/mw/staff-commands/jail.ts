import {
    ChannelType,
    ChatInputCommandInteraction,
    MessageFlags,
    PermissionsBitField,
    SlashCommandBuilder,
    ThreadAutoArchiveDuration,
} from 'discord.js'
import JailData from '../../../db-objects/data/jail-data'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'
import { InteractionError, MWEmbedBuilder } from '../../../utils/common/sharedElements'
import { Categories } from '../../../utils/common/sharedEnums'

export default class JailCommand extends BaseSlashCommand {
    category = Categories.moderation
    command = new SlashCommandBuilder()
        .setName('jail')
        .setDescription('Puts a user in jail')
        .addUserOption((option) =>
            option
                .setName('user')
                .setDescription('The user to put in jail')
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ModerateMembers)

    async execute(interaction: ChatInputCommandInteraction) {
        
        const data = new JailData(interaction.guild.id)
        await data.loadAsync()

        if (!(data.jailChannelId && data.jailRoleId && data.roleToRemoveId)) {
            throw new InteractionError('The jail command is not setup!')
        }

        const jailRole = await this.dUtils().getRoleAsync(data.jailRoleId, interaction.guild)
        const roleToRemove = await this.dUtils().getRoleAsync(data.roleToRemoveId, interaction.guild)
        const jailChannel = await this.dUtils().getTextChannelAsync(data.jailChannelId, interaction.guild)

        if (!jailRole) {
            throw new InteractionError('Could not find the jail role.')
        }
        if (!roleToRemove) {
            throw new InteractionError('Could not find the role to remove.')
        }

        const user = interaction.options.getUser('user')
        const memberToJail = await this.dUtils().getMemberAsync(user.id, interaction.guild)

        if (memberToJail.roles.cache.some((r) => r.id === jailRole.id)) {
            throw new InteractionError(`This member already has the ${jailRole} role`)
        }

        await this.dUtils().updateMemberRolesAsync(memberToJail, jailRole, roleToRemove, 'This user deserves to be in jail')

        const threadChannel = await jailChannel.threads
            .create({
                name: `Jail-Thread-${memberToJail.displayName}`,
                autoArchiveDuration: ThreadAutoArchiveDuration.OneDay,
                reason: `${memberToJail.displayName} was jailed`,
                type: ChannelType.PrivateThread,
            })

        // Ping the author of the thread
        await (await threadChannel.send(`${interaction.user}`)).delete()

        await interaction.reply({
            content: `Jail thread created for ${memberToJail} : ${threadChannel}`,
            flags: MessageFlags.Ephemeral
        })

        await threadChannel.send(
            `# You are here for a reason ${memberToJail}`
        )

        if (!data.logChannelId) {
            return
        }

        const logChannel = await this.dUtils().getTextChannelAsync(data.logChannelId, interaction.guild)

        if (logChannel) {
            const embed = new MWEmbedBuilder()
                .setDescription(`Jail thread created by ${interaction.user} : ${threadChannel}`)
            logChannel.send({ embeds: [embed] })
        }
    }

}

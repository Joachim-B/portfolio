import {
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import AnalysisData from '../../../../db-objects/data/analysis'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements'

export default class MessageCountSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
    .setName('count')
    .setDescription('Counts the number of messages sent by each member')
    
    async execute(interaction: ChatInputCommandInteraction) {
        const data = new AnalysisData(interaction.guild.id)
        await data.loadAsync()
        if (await data.noDataLoaded(interaction)) {
            return
        }

        const userData = new Array<UserData>()

        data.messages.forEach(m => {
            const selectedData = userData.find(data => data.id == m.authorId)
            if (selectedData) {
                selectedData.messageCount++;
            }
            else {
                const newData: UserData = {
                    id: m.authorId,
                    messageCount: 1
                }
                userData.push(newData)
            }
        })

        const reply = userData.sort((u1, u2) => u2.messageCount - u1.messageCount).map(d => `<@${d.id}> : **${d.messageCount}**`).join('\n')

        const embed = new MWEmbedBuilder()
            .setTitle('Amount of messages posted by each user :')
            .setDescription(reply);

        await embed.displayMWEmbed(interaction)
    }
}

interface UserData {
    id: string;
    messageCount: number;
}
import {
    ChannelType,
    ChatInputCommandInteraction,
    FetchMessagesOptions,
    Message,
    SlashCommandSubcommandBuilder,
    TextChannel,
} from 'discord.js'
import AnalysisData from '../../../../db-objects/data/analysis'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class LoadSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
    .setName('load')
    .setDescription('Loads the channel data for analysis')
    .addStringOption((option) =>
        option
            .setName('oldest-message-id')
            .setDescription('The oldest message')
            .setRequired(true)
    )
    .addStringOption((option) =>
        option
            .setName('latest-message-id')
            .setDescription('The newest message (leave empty to select the last message of the channel)')
            .setRequired(false)
    )
    .addChannelOption((option) =>
        option
            .setName('channel')
            .setDescription('The channel to analyse (leave empty to select the current channel)')
            .setRequired(false)
            .addChannelTypes(ChannelType.GuildText)
    )

    async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const oldestMessageId = interaction.options.getString('oldest-message-id')
        const latestMessageId = interaction.options.getString('latest-message-id')
        const channelId = interaction.options.getChannel('channel')?.id ?? interaction.channelId

        const channel = await this.dUtils().getTextChannelAsync(channelId, interaction.guild)

        const replyMessage = await interaction.reply({
            content: 'Loading messages...'
        })

        const oldestMessage = await this.dUtils().getMessageAsync(oldestMessageId, channelId, interaction.guild)

        const latestMessage = latestMessageId ? await this.dUtils().getMessageAsync(latestMessageId, channelId, interaction.guild)
            : (channel.messages.cache.sort().last())

        const messages = await fetchMessages(oldestMessage, latestMessage, channel)

        replyMessage.edit({
            content: `Loaded **${messages.length}** messages.`
        })

        const data = new AnalysisData(interaction.guild.id)
        data.messages = messages.map(m => {
            return {
                authorId: m.author.id,
                message: m
            };
        });
        await data.saveAsync()
    }
}

async function fetchMessages(oldestMessage: Message<true>, latestMessage: Message<true>, channel: TextChannel): Promise<Message<true>[]> {
    if ((await channel.messages.fetch({ limit: 1 })).size == 0) {
        return new Array<Message<true>>()
    }

    let lastId = latestMessage.id;
    const messagesBetween = new Array<Message<true>>();
    messagesBetween.push(latestMessage);

    while (true) {
        const options: FetchMessagesOptions = { limit: 100 };
        options.before = lastId;

        const messages = await channel.messages.fetch(options);
        lastId = messages.at(messages.size - 1)?.id;

        for (const message of messages.values()) {
            if (message.id > oldestMessage.id) {
                messagesBetween.push(message);
            }
            if (message.id === oldestMessage.id) {
                messagesBetween.push(message);
                break;
            }
        }

        if (!lastId) {
            break;
        }
    }

    return messagesBetween
}
import {
    PermissionsBitField,
} from 'discord.js'
import BaseSlashCommandGroup from '../../../utils/common/abstraction/baseSlashCommandGroup'
import { Categories } from '../../../utils/common/sharedEnums'

export default class MessageStatsBase extends BaseSlashCommandGroup {
    constructor() {
        super(Categories.messageStats, __filename);
        this.command.setDefaultMemberPermissions(PermissionsBitField.Flags.ManageChannels)
    }
}

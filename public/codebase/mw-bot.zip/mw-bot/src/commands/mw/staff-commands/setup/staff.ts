import {
    ActionRowBuilder,
    ChatInputCommandInteraction,
    RoleSelectMenuBuilder,
    RoleSelectMenuInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'
import StaffData from '../../../../db-objects/data/staff'

export default class StaffSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('staff')
        .setDescription('Setup the staff roles')
    async execute(interaction: ChatInputCommandInteraction) {
        const data = new StaffData(interaction.guild.id)
        await data.loadAsync()

        const roleMenu = new RoleSelectMenuBuilder()
            .setCustomId('staffroles')
            .setMinValues(0)
            .setMaxValues(20)
            .setDefaultRoles(...data.staffRoles)

        const component = new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(roleMenu)
        const response = await interaction.reply({ components: [component] })

        try {
            const confirmation = await response.awaitMessageComponent({ filter: i => i.user.id === interaction.user.id, time: 120_000 }) as RoleSelectMenuInteraction;
            data.staffRoles = confirmation.values
            await data.saveAsync()
            await interaction.editReply({ content: 'Staff roles updated.', components: [] })
        }
        catch {
            await interaction.editReply({ content: 'Confirmation not received within 1 minute, cancelling...', components: [] });
        }
    }
}

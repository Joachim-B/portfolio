import {
    ChatInputCommandInteraction,
    PermissionsBitField,
    SlashCommandBuilder,
} from 'discord.js'
import JailData from '../../../db-objects/data/jail-data'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'
import { Categories } from '../../../utils/common/sharedEnums'
import { MWEmbedBuilder } from '../../../utils/common/sharedElements'

export default class JailCommand extends BaseSlashCommand {
    command = new SlashCommandBuilder()
        .setName('unjail')
        .setDescription('Unjails a user')
        .addUserOption((option) =>
            option
                .setName('user')
                .setDescription('The user to unjail')
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ModerateMembers)
    category = Categories.moderation

    async execute(interaction: ChatInputCommandInteraction) {
        const data = new JailData(interaction.guild.id)
        await data.loadAsync()
        if (
            !data.jailChannelId ||
            !data.jailRoleId ||
            !data.roleToRemoveId
        ) {
            await interaction.reply({
                content: 'The jail command is not setup!',
            })
            return
        }

        const jailRole = interaction.guild.roles.cache.find((r) => r.id === data.jailRoleId)
        const roleToAddBack = interaction.guild.roles.cache.find((r) => r.id === data.roleToRemoveId)

        if (!jailRole) {
            await interaction.reply({
                content: 'Could not find the jail role.',
            })
            return
        }
        if (!roleToAddBack) {
            await interaction.reply({
                content: 'Could not find the role to remove.',
            })
            return
        }

        const user = interaction.options.getUser('user')
        const memberInJail = await this.dUtils().getMemberAsync(user.id, interaction.guild)

        if (!memberInJail.roles.cache.some((r) => r.id === jailRole.id)) {
            await interaction.reply({
                content: `This member doesn't have the ${jailRole} role`,
            })
            return
        }

        // Remove member role and add jail role
        await this.dUtils().updateMemberRolesAsync(memberInJail, roleToAddBack, jailRole, 'The jail sentence has ended')

        await interaction.reply({
            content: `${memberInJail} has been unjailed.`,
        })

        const logChannel = await this.dUtils().getTextChannelAsync(data.logChannelId, interaction.guild)

        if (logChannel) {
            const embed = new MWEmbedBuilder()
                .setDescription(`${memberInJail} has been unjailed by ${interaction.user}`)
            logChannel.send({ embeds: [embed] })
        }
    }
}

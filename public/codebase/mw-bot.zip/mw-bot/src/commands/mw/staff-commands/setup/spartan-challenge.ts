import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ChallengeRolesData from '../../../../db-objects/data/challenge-roles-data';

export default class SetupSpartanCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('spartan-challenge')
        .setDescription('Setup the Spartan challenge command')
        .addStringOption(o => o
            .setName('spartan-challenge-description')
            .setDescription('The description for the Spartan challenges')
            .setRequired(true)
        )
        .addStringOption(o => o
            .setName('spartan-lvl0-message')
            .setDescription('The message displayed in /level if user is Level 0')
            .setRequired(true)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const spartanChallengeDescription = interaction.options.getString('spartan-challenge-description')
        const spartanLvl0Message = interaction.options.getString('spartan-lvl0-message')
        const data = new ChallengeRolesData(interaction.guildId)
        await data.loadAsync()
        data.spartanChallengeDescription = spartanChallengeDescription
        data.level0Message = spartanLvl0Message
        await data.saveAsync()
        await interaction.reply('Spartan data updated.')
    }
}
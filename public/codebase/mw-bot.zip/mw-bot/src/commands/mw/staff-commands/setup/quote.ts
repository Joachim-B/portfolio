import {
    ChannelType,
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import QuoteData from '../../../../db-objects/data/quote-data'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class QuoteSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('quote')
        .setDescription('Setup quotes channel')
        .addChannelOption((option) =>
            option
                .setName('channel')
                .setDescription('The quote channel')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const channel = interaction.options.getChannel('channel')
        this.dUtils().mustBeTextChannelAsync(channel)

        const data = new QuoteData(interaction.guild.id)
        data.channelId = channel.id
        await data.saveAsync()

        await interaction.reply({
            content: 'Quote channel updated.',
        })
    }
}

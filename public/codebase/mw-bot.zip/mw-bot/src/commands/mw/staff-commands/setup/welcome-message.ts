import {
    SlashCommandSubcommandBuilder,
    ChatInputCommandInteraction,
    ChannelType,
    MessageFlags,
} from 'discord.js'
import WelcomeData from '../../../../db-objects/data/welcome-data'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class WelcomeMessageSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('welcome-message')
        .setDescription('Setup welcome message')
        .addChannelOption((option) =>
            option
                .setName('welcome-channel')
                .setDescription('The channel to send the greetings message to')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)
        )
        .addStringOption((option) =>
            option
                .setName('content-message-link')
                .setDescription(
                    'The link to the message with the greetings content.'
                )
        )
        .addStringOption((option) =>
            option
                .setName('embed-title')
                .setDescription(
                    'The embed title.'
                )
        )
        .addStringOption((option) =>
            option
                .setName('embed-content-message-link')
                .setDescription(
                    'The link to the message with the embed content.'
                )
        )
        .addStringOption((option) =>
            option
                .setName('attachment-link')
                .setDescription(
                    'The attachment file link.'
                )
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const welcomeChannel = interaction.options.getChannel('welcome-channel')
        const messageLink = interaction.options.getString('content-message-link')
        const embedTitle = interaction.options.getString('embed-title')
        const embedLink = interaction.options.getString('embed-content-message-link')
        const attachmentLink = interaction.options.getString('attachment-link')

        if (messageLink) this.dUtils().mustBeDiscordMessageLinkAsync(messageLink)
        if (embedLink) this.dUtils().mustBeDiscordMessageLinkAsync(embedLink)
        
        let messageContent: string
        let embedContent: string

        if (messageLink) {
            messageContent = (await this.dUtils().getMessageByLinkAsync(messageLink, interaction.guild))?.content
            if (!messageContent) {
                await interaction.reply({
                    content: 'Invalid URL. Please provide a correct greeting message link.',
                    flags: MessageFlags.Ephemeral,
                })
                return
            }
        }

        if (embedLink) {
            embedContent = (await this.dUtils().getMessageByLinkAsync(embedLink, interaction.guild))?.content
            if (!embedContent) {
                await interaction.reply({
                    content: 'Invalid URL. Please provide a correct embed message link.',
                    flags: MessageFlags.Ephemeral,
                })
                return
            }
        }

        const data = new WelcomeData(interaction.guild.id)
        data.welcomeChannel = welcomeChannel.id
        data.message = messageContent
        data.embedTitle = embedTitle
        data.embedContent = embedContent
        data.attachmentLink = attachmentLink
        await data.saveAsync()

        await interaction.reply({
            content: 'Welcome message updated.',
        })
    }
}

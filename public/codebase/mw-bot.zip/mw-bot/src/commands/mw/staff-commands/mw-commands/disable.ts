import {
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'
import AllowedCommandsData from '../../../../db-objects/data/commands-data'
import { InteractionError } from '../../../../utils/common/sharedElements'
import cacheManager from '../../../../utils/cache-manager'

export default class CommandsEnableSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('disable')
        .setDescription('Disable commands in a server')
        .addStringOption((option) =>
            option
                .setName('type')
                .setDescription('The commands type')
                .addChoices(
                    { name: 'Championships', value: 'CHAMPIONSHIP' },
                    { name: 'Connect', value: 'CONNECT' })
                .setRequired(true)
        )
        .addStringOption(o => o
            .setName('server-id')
            .setDescription('Enter the ID of a specific server')
        )
    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply()
        const guildId = interaction.options.getString('server-id') ?? interaction.guildId
        const commandType = interaction.options.getString('type')

        const guild = guildId == interaction.guildId
            ? interaction.guild
            : await this.dUtils().getGuildAsync(guildId, interaction.client, true)

        const data = await new AllowedCommandsData().loadAsync()
        if (commandType == 'CHAMPIONSHIP') {
            const index = data.championshipAllowedGuilds.indexOf(guildId)
            if (index == -1) {
                throw new InteractionError('This server isn\'t registered to this type of commands!')
            }

            delete data.championshipAllowedGuilds[index]
        }
        else {
            const index = data.connectAllowedGuilds.indexOf(guildId)
            if (index == -1) {
                throw new InteractionError('This server isn\'t registered to this type of commands!')
            }

            delete data.connectAllowedGuilds[index]
        }

        await data.saveAsync()
        cacheManager.reloadGuildCommands(guild, data)
        await interaction.editReply('The commands have been updated for the server !')
    }
}

import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'
import PaladinData from '../../../../db-objects/data/paladins'

export default class PaladinsSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('paladins')
        .setDescription('Setup the Paladin message')
        .addRoleOption((option) =>
            option
                .setName('paladin-role')
                .setDescription('The Paladin role')
                .setRequired(true)
        )
        .addRoleOption((option) =>
            option
                .setName('head-paladin-role')
                .setDescription('The Head Paladin role')
        )
        .addStringOption((option) =>
            option
                .setName('embed-description')
                .setDescription('Input text (separate the title from the description with |)')
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const paladinRole = interaction.options.getRole('paladin-role')
        const headPaladinRole = interaction.options.getRole('head-paladin-role')
        const description = interaction.options.getString('embed-description')

        const data = new PaladinData(interaction.guild.id)

        data.paladinRoleId = paladinRole.id
        data.headPaladinRoleId = headPaladinRole?.id
        data.description = description

        await data.saveAsync()

        await interaction.reply({
            content: 'Paladin command updated!',
        })
    }
}

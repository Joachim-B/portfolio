import {
    PermissionsBitField,
} from 'discord.js'
import { Categories } from '../../../utils/common/sharedEnums'
import BaseSlashCommandGroup from '../../../utils/common/abstraction/baseSlashCommandGroup'

export default class CommandsBase extends BaseSlashCommandGroup {
    constructor() {
        super(Categories.setup, __filename)
        this.command.setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    }
}
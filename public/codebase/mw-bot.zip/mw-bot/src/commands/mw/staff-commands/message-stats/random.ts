import {
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import AnalysisData from '../../../../db-objects/data/analysis'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import { InteractionError, MWEmbedBuilder } from '../../../../utils/common/sharedElements';

export default class RandomSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('random')
        .setDescription('Retrieves a random message from a user')
        .addUserOption((option) =>
            option
                .setName('user')
                .setDescription('The selected user')
                .setRequired(true)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const user = interaction.options.getUser('user', true);

        const data = await new AnalysisData(interaction.guild.id).loadAsync();
        if (await data.noDataLoaded(interaction)) {
            return;
        }

        const filteredMessages = data.messages.filter(m => m.authorId === user.id && m.message.content);

        if (!filteredMessages || filteredMessages.length === 0) {
            throw new InteractionError('No messages with content were found from the specified author.')
        }

        const selectedMessage = filteredMessages[Math.floor(Math.random() * filteredMessages.length)];

        const embed = new MWEmbedBuilder()
            .setTitle(`Random message by ${user.displayName}`)
            .setDescription(selectedMessage.message.content);

        await embed.displayMWEmbed(interaction)
    }
}

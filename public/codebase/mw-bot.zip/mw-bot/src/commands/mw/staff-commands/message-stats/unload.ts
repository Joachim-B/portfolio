import {
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import AnalysisData from '../../../../db-objects/data/analysis'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class UnloadSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('unload')
        .setDescription('Clears the loaded data');

    async execute(interaction: ChatInputCommandInteraction) {
        const data = new AnalysisData(interaction.guild.id);
        data.messages = null;
        await data.saveAsync();

        await interaction.reply({ content: 'The messages have been unloaded.' });
    }
}
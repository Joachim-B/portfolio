import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements';
import StreakMessageData, { MessageType } from '../../../../db-objects/data/streak-messages';

export default class SubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('List all streak messages')
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = await new StreakMessageData().loadAsync()

        const messages = data.messageData.sort((a, b) => {
            // Milestone messages come first, sorted by milestone ascending
            if (a.type === MessageType.Milestone && b.type === MessageType.Milestone) {
                return a.milestone - b.milestone;
            }
            if (a.type === MessageType.Milestone) return -1;
            if (b.type === MessageType.Milestone) return 1;
        
            // Edging messages come second, sorted by id ascending
            if (a.type === MessageType.Edging && b.type === MessageType.Edging) {
                return a.id - b.id;
            }
            if (a.type === MessageType.Edging) return -1;
            if (b.type === MessageType.Edging) return 1;
        
            // Relapse messages come last, sorted by id ascending
            return a.id - b.id;
        })
        .map(m => `**ID:${m.id} – ${m.type == MessageType.Milestone ? `DAY ${m.milestone}` : m.type == MessageType.Edging ? 'Edging/Peeking' : m.type} –** ${m.message}`)

        const embed = new MWEmbedBuilder()
            .setTitle('Streak messages list')
            .setDescription(messages.join('\n\n') || '*No streak messages yet*')

        await embed.displayMWEmbed(interaction)
    }
}
import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import UrgeData from '../../../../db-objects/data/urge-data';
import { InteractionError } from '../../../../utils/common/sharedElements';

export default class NofapAddRoleCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Add a message to \'/urge\'')
        .addStringOption(o => o
            .setName('message')
            .setDescription('Input text')
            .setRequired(true)
        )
        .addStringOption(o => o
            .setName('image-link')
            .setDescription('The image link')
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const message = interaction.options.getString('message')
        const attachmentLink = interaction.options.getString('image-link')
        if (attachmentLink && !await this.dUtils().utils.isImage(attachmentLink)) {
            throw new InteractionError('Invalid image link. The URL should point directly to an image file (ending in .png, .jpg, .gif, etc.). Links from Tenor or Giphy may not work properly. Please provide a direct image URL.')
        }
        const data = await new UrgeData().loadAsync()
        const id = data.nextId
        data.messages.push({message, id, attachmentLink: attachmentLink})
        data.nextId++

        await data.saveAsync()
        await interaction.reply({ content: 'The `/urge` message has been added successfully!' })
    }
}
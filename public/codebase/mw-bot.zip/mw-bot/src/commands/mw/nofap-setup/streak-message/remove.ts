import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import { InteractionError } from '../../../../utils/common/sharedElements';
import StreakMessageData from '../../../../db-objects/data/streak-messages';

export default class SubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Remove one streak message')
        .addIntegerOption(o => o
            .setName('id')
            .setDescription('The message ID')
            .setRequired(true)
            .setMinValue(0)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const id = interaction.options.getInteger('id')

        const data = await new StreakMessageData().loadAsync()
        const index = data.messageData.findIndex(m => m.id == id)
        if (index == -1) {
            throw new InteractionError(`Message with ID:**${id}** not found!`)
        }

        const { confirmed, confirmationMessage } = await this.dUtils().displayConfirmationMessage(interaction, `Are you sure to delete this message ? (ID:${id})`)
        if (!confirmed) {
            return
        }

        data.messageData.splice(index, 1);
        await data.saveAsync()

        await confirmationMessage.update({ content: 'The message has been deleted successfully!', components: [] })
    }
}
import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import { InteractionError } from '../../../../utils/common/sharedElements';
import StreakMessageData, { MessageType } from '../../../../db-objects/data/streak-messages';

export default class SubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Add a message to display during nofap check-ins.')
        .addStringOption(o => o
            .setName('message')
            .setDescription('Input text (separate the title from the description with |)')
            .setRequired(true)
        )
        .addStringOption(o => o
            .setName('type')
            .setDescription('The type of message')
            .addChoices(
                { name: 'Milestone', value: 'MILESTONE' },
                { name: 'Edging/Peeking', value: 'EDGING' },
                { name: 'Relapse', value: 'RELAPSE' }
            )
            .setRequired(true)
        )
        .addIntegerOption(o => o
            .setName('milestone')
            .setDescription('The no-nut milestone when the message is displayed (only for Milestone type).')
            .setMinValue(1)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const message = interaction.options.getString('message')
        const type = interaction.options.getString('type')
        const milestone = interaction.options.getInteger('milestone')

        const messageType: MessageType =
            type == 'MILESTONE' ? MessageType.Milestone
                : type == 'EDGING' ? MessageType.Edging
                    : MessageType.Relapse

        if (messageType == MessageType.Milestone && !milestone) {
            throw new InteractionError('The milestone parameter has to be set!')
        }

        const data = await new StreakMessageData().loadAsync()
        const id = data.nextId

        data.messageData.push({ id, message, type:messageType, milestone})
        data.nextId++

        await data.saveAsync()
        await interaction.reply(`The message has been added successfully ! **(ID:${id})**`)
    }
}
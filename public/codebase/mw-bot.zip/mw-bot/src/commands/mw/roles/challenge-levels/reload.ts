import {
    ChatInputCommandInteraction,
    MessageFlags,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import ChallengeLevelData from '../../../../db-objects/data/challenge-levels-data'
import ChallengeRolesData from '../../../../db-objects/data/challenge-roles-data'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'
import SharedFunctions from '../../../../utils/common/sharedFunctions'

export default class ReloadSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('reload')
        .setDescription('Reload the level role of every users')

    async execute(interaction: ChatInputCommandInteraction) {
        const levelData = new ChallengeLevelData(interaction.guild.id)
        const roleData = new ChallengeRolesData(interaction.guild.id)
        await levelData.loadAsync()
        await roleData.loadAsync()

        if (levelData.challengeLevelIds.length === 0 || roleData.challengeRoleIds.length === 0) {
            await interaction.reply({ content: 'The challenge roles and levels haven\'t been set up.', flags: MessageFlags.Ephemeral })
            return
        }

        const totalMembers = interaction.guild.memberCount
        let membersProcessed = 0

        const reply = await interaction.reply('Reloading all the challenge levels...')
        let progressMessage = await reply.edit({ content: 'Reloading all the challenge levels...' })

        const challengeLevelRolesIds = levelData.challengeLevelIds.map(lr => lr.roleId)

        const guildMembers = interaction.guild.members.cache

        const tasks = guildMembers.map(async member => {
            const memberChallengeRolesCount = member.roles.cache.filter(r => roleData.challengeRoleIds.includes(r.id)).size
            const memberLevelRoles = member.roles.cache.filter(r => challengeLevelRolesIds.includes(r.id))

            if (memberChallengeRolesCount === 0) {
                if (memberLevelRoles.size !== 0) {
                    await member.roles.remove(memberLevelRoles)
                }
            } else {
                const correctLevelRoleId = new SharedFunctions().getCorrectLevelRoleId(memberChallengeRolesCount, levelData)

                if (memberLevelRoles.size !== 1 || !memberLevelRoles.has(correctLevelRoleId)) {
                    if (memberLevelRoles.size > 0) {
                        await member.roles.remove(memberLevelRoles)
                    }
                    await member.roles.add(correctLevelRoleId)
                }
            }

            membersProcessed++

            if (membersProcessed % (totalMembers / 100) === 0) {
                progressMessage = await progressMessage.edit(`Reload... ${(membersProcessed / totalMembers * 100).toFixed(0)}%`)
            }
        })

        await Promise.all(tasks)

        await progressMessage.edit('Level roles reload finished')
    }
}
import {
    ChatInputCommandInteraction,
    MessageFlags,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import CategoryRoleData from '../../../../db-objects/data/category-roles'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class RemoveSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Removes a category role')
        .addRoleOption((option) =>
            option
                .setName('role')
                .setDescription('The category role')
                .setRequired(true)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const role = interaction.options.getRole('role', true);
        const data = new CategoryRoleData(interaction.guild.id);
        await data.loadAsync();

        let index = data.categoryRoleIds.indexOf(role.id, 0);
        if (index < 0) {
            await interaction.reply({
                content: `${role} is not a category role`,
                flags: MessageFlags.Ephemeral
            });
            return;
        }

        data.categoryRoleIds.splice(index, 1);
        index = data.ghostRoleIds.indexOf(role.id, 0);
        data.ghostRoleIds.splice(index, 1);

        await data.saveAsync();
        await interaction.reply({
            content: `Removed the role ${role}.`,
            flags: MessageFlags.Ephemeral
        });
    }
}
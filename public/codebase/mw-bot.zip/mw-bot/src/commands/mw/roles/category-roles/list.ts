import {
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import CategoryRoleData from '../../../../db-objects/data/category-roles'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements';

export default class ListSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('Gets the list of every challenge roles');

    async execute(interaction: ChatInputCommandInteraction) {
        await this.dUtils().checkIfModCmdChannel(interaction)

        const data = new CategoryRoleData(interaction.guild.id);
        await data.loadAsync();

        if (data.categoryRoleIds.length == 0) {
            const embed = new MWEmbedBuilder()
                .setTitle('Category Roles')
                .setDescription('No category roles');

            await interaction.reply({ embeds: [embed] });
            return;
        }

        await this.dUtils().fetchDataAsync(interaction.guild, { roles: true })

        const roleList = interaction.guild.roles.cache
            .filter(role => role.id !== interaction.guild.id) // Removes @everyone role
            .sort((a, b) => b.position - a.position)
            .map(role => {
                if (data.getGhostRoleIdsSet().has(role.id)) {
                    return `### ${role} :ghost:`;
                } else if (data.getCategoryRoleIdsSet().has(role.id)) {
                    return `### ${role}`;
                } else {
                    return `${role}`;
                }
            })
            .join('\n');

        const embed = new MWEmbedBuilder()
            .setTitle('Category Roles')
            .setDescription(roleList || 'No roles found');

        await embed.displayMWEmbed(interaction)

        await cleanUpRoles(data, interaction);
    }
}

async function cleanUpRoles(data: CategoryRoleData, interaction: ChatInputCommandInteraction) {
    const validRoleIds = Array.from(data.categoryRoleIds).filter(id => interaction.guild.roles.cache.has(id))
    data.categoryRoleIds = validRoleIds
    const validGhostIds = Array.from(data.ghostRoleIds).filter(id => validRoleIds.includes(id))
    data.ghostRoleIds = validGhostIds

    await data.saveAsync()
}
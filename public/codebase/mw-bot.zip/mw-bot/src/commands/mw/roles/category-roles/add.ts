import {
    ChatInputCommandInteraction,
    MessageFlags,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import CategoryRoleData from '../../../../db-objects/data/category-roles'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class AddSubCommand extends BaseSlashSubCommand {
    command =  new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Adds a category role')
        .addRoleOption((option) =>
            option
                .setName('role')
                .setDescription('The category role')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const role = interaction.options.getRole('role')
        const data = new CategoryRoleData(interaction.guild.id)
        await data.loadAsync()

        if (data.getCategoryRoleIdsSet().has(role.id)) {
            await interaction.reply({
                content: `${role} is already a category role.`,
                flags: MessageFlags.Ephemeral
            })
            return
        }

        data.categoryRoleIds.push(role.id)
        await data.saveAsync()

        await interaction.reply({
            content: `Added the role ${role}.`,
            flags: MessageFlags.Ephemeral
        })
    }
}
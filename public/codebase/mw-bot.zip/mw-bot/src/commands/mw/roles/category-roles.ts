import { PermissionsBitField } from 'discord.js'
import { Categories } from '../../../utils/common/sharedEnums'
import BaseSlashCommandGroup from '../../../utils/common/abstraction/baseSlashCommandGroup'

export default class CategoryRolesBase extends BaseSlashCommandGroup {
    constructor() {
        super(Categories.categoryRoles, __filename);
        this.command.setDefaultMemberPermissions(PermissionsBitField.Flags.ManageRoles)
    }
}

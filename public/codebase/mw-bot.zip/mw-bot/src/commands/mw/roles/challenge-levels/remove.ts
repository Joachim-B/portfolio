import {
    ChatInputCommandInteraction,
    MessageFlags,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import ChallengeLevelData from '../../../../db-objects/data/challenge-levels-data'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class RemoveSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Removes a challenge level')
        .addRoleOption(option =>
            option
                .setName('role')
                .setDescription('The level role')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const role = interaction.options.getRole('role')
        const challengeRoles = new ChallengeLevelData(interaction.guild.id)
        await challengeRoles.loadAsync()

        const index = challengeRoles.challengeLevelIds.findIndex(c => c.roleId === role.id)
        if (index < 0) {
            await interaction.reply({
                content: `${role} is not a level role.`,
                flags: MessageFlags.Ephemeral,
            })
            return
        }

        challengeRoles.challengeLevelIds.splice(index, 1)

        await challengeRoles.saveAsync()
        await interaction.reply({
            content: `Removed the role ${role}.`,
            flags: MessageFlags.Ephemeral,
        })
    }
}
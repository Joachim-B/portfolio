import {
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'
import ChallengeLevelData from '../../../../db-objects/data/challenge-levels-data';
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements';

export default class ListSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('Gets the list of every challenge levels')

    async execute(interaction: ChatInputCommandInteraction) {
        const data = new ChallengeLevelData(interaction.guild.id)
        await data.loadAsync()

        if (data.challengeLevelIds.length === 0) {
            const embed = new MWEmbedBuilder()
                .setTitle('Server Ranks')
                .setDescription('No level roles')

            await interaction.reply({ embeds: [embed] })
            return
        }

        await this.dUtils().fetchDataAsync(interaction.guild, {roles:true})

        await this.cleanUpLevelRoles(data, interaction)

        const roles = data.challengeLevelIds
            .sort((a, b) => b.level - a.level)
            .map(c => `**${interaction.guild.roles.cache.get(c.roleId)} : ${c.level} ${c.level === 1 ? 'challenge' : 'challenges'}**`)

        const embed = new MWEmbedBuilder()
            .setTitle('Server Ranks')
            .setDescription(roles.join('\n') || 'No roles found')

        await embed.displayMWEmbed(interaction)
    }

    private async cleanUpLevelRoles(data: ChallengeLevelData, interaction: ChatInputCommandInteraction) {
        const validRoleIds = data.challengeLevelIds.filter(c => interaction.guild.roles.cache.has(c.roleId))
        data.challengeLevelIds = validRoleIds
        await data.saveAsync()
    }
}
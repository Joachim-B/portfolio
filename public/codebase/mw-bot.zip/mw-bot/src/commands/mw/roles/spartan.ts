import BaseSlashCommandGroup from '../../../utils/common/abstraction/baseSlashCommandGroup';
import { Categories } from '../../../utils/common/sharedEnums';

export default class SpartanCommand extends BaseSlashCommandGroup {
    constructor() {
        super(Categories.ranking, __filename);
    }
}

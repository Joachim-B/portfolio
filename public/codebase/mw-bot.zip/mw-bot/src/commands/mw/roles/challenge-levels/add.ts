import {
    ChatInputCommandInteraction,
    MessageFlags,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import ChallengeLevelData, { RoleData } from '../../../../db-objects/data/challenge-levels-data'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class AddSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Adds a challenge level')
        .addRoleOption((option) =>
            option
                .setName('role')
                .setDescription('The challenge level')
                .setRequired(true)
        )
        .addIntegerOption((option) =>
            option
                .setName('amount')
                .setDescription('The number of challenge roles needed to obtain the level')
                .setRequired(true)
                .setMinValue(1)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const role = interaction.options.getRole('role')
        const data = new ChallengeLevelData(interaction.guild.id)
        await data.loadAsync()

        const index = data.challengeLevelIds.findIndex(c => c.roleId == role.id)
        if (index > -1) {
            await interaction.reply({
                content: `${role} is already a level role.`,
                flags: MessageFlags.Ephemeral
            })
            return
        }

        const roleData = new RoleData()
        roleData.roleId = role.id
        roleData.level = interaction.options.getInteger('amount')

        data.challengeLevelIds.push(roleData)
        await data.saveAsync()

        await interaction.reply({
            content: `Added the role ${role}.`,
            flags: MessageFlags.Ephemeral
        })
    }
}

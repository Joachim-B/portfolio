import {
    ChatInputCommandInteraction,
    MessageFlags,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import CategoryRoleData from '../../../../db-objects/data/category-roles'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class AddGhostSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('add-ghost')
        .setDescription('Adds a category role that doesn\'t appear')
        .addRoleOption((option) =>
            option
                .setName('role')
                .setDescription('The ghost category role')
                .setRequired(true)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const role = interaction.options.getRole('role', true);
        const data = new CategoryRoleData(interaction.guild.id);
        await data.loadAsync();

        if (data.getCategoryRoleIdsSet().has(role.id)) {
            await interaction.reply({
                content: `${role} is already a category role.`,
                flags: MessageFlags.Ephemeral
            });
            return;
        }

        data.categoryRoleIds.push(role.id);
        data.ghostRoleIds.push(role.id);
        await data.saveAsync();

        await interaction.reply({
            content: `Added the role ${role}.`,
            flags: MessageFlags.Ephemeral
        });
    }
}

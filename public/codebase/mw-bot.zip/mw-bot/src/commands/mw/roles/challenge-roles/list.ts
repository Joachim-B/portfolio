import {
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'
import ChallengeRolesData from '../../../../db-objects/data/challenge-roles-data'
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements'

export default class ListSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('Gets the list of every challenge role')

    async execute(interaction: ChatInputCommandInteraction) {
        const challengeRoles = new ChallengeRolesData(interaction.guild.id)
        await challengeRoles.loadAsync()

        const roles = challengeRoles.challengeRoleIds
            .map(id => interaction.guild.roles.cache.get(id))
            .filter(role => role !== null)
            .sort((a, b) => b!.position - a!.position) // Non-null assertion to ensure roles are not null

        const embed = new MWEmbedBuilder()
            .setTitle('Spartan Challenges')
            .setDescription(roles.length == 0 ? 'No roles found' : `${roles.join('\n')}\n\n**Total : ${roles.length}**`)

        await interaction.reply({ embeds: [embed] })
        await this.cleanUpChallengeRoles(challengeRoles, interaction)
    }

    private async cleanUpChallengeRoles(data: ChallengeRolesData, interaction: ChatInputCommandInteraction) {
        const validRoleIds = data.challengeRoleIds.filter(id => interaction.guild.roles.cache.has(id))
        data.challengeRoleIds = validRoleIds
        await data.saveAsync()
    }
}
import {
    ButtonBuilder,
    ButtonStyle,
    ChatInputCommandInteraction,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'
import ChallengeRolesData from '../../../../db-objects/data/challenge-roles-data'
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements'

export default class ChallengesCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('challenge')
        .setDescription('Description of the Spartan challenge')

    async execute(interaction: ChatInputCommandInteraction) {
        const challengeRoles = new ChallengeRolesData(interaction.guild.id)
        await challengeRoles.loadAsync()

        const roles = (await Promise.all(
            challengeRoles.challengeRoleIds.map(async id => {
                return await this.dUtils().getRoleAsync(id, interaction.guild);
            })
        ))
            .filter(role => role !== null)
            .sort((a, b) => b.position - a.position);

        const description = challengeRoles.spartanChallengeDescription ?? '*No description provided*'

        const mainEmbed = new MWEmbedBuilder()
            .setTitle('The Spartan Challenge')
            .setDescription(description)
            .setColor(0x2ecc71)

        const buttonRow = roles.length == 0 ? undefined
            : this.dUtils().getButtonRowBuilder(
                new ButtonBuilder()
                    .setCustomId('more')
                    .setLabel('📜')
                    .setStyle(ButtonStyle.Primary)
            )

        const reply = await interaction.reply({ embeds: [mainEmbed], components: [buttonRow] })

        if (!buttonRow) {
            return
        }

        const collector = this.dUtils().createButtonCollector(reply, undefined, 60)

        collector.on('collect', async i => {
            if (i.customId != 'more') {
                return
            }

            const rolesList = `\n### List of Roles\n${roles.map(r => `- ${r} (${r.members.size} holder${r.members.size == 1 ? '' : 's'})`).join('\n')}\n\n**Total: ${roles.length}** challenges`

            mainEmbed.setDescription(description + rolesList)
            await i.message.edit({ embeds: [mainEmbed], components: [] })
            await i.deferUpdate()
        })
    }
}
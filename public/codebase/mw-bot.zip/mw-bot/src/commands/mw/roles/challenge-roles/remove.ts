import {
    ChatInputCommandInteraction,
    MessageFlags,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import ChallengeRolesData from '../../../../db-objects/data/challenge-roles-data'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class RemoveSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Removes a challenge role')
        .addRoleOption(option =>
            option
                .setName('role')
                .setDescription('The challenge role')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const role = interaction.options.getRole('role')
        const challengeRoles = new ChallengeRolesData(interaction.guild.id)
        await challengeRoles.loadAsync()

        const index = challengeRoles.challengeRoleIds.indexOf(role.id)
        if (index < 0) {
            await interaction.reply({
                content: `${role} is not a challenge role.`,
                flags: MessageFlags.Ephemeral,
            })
            return
        }

        challengeRoles.challengeRoleIds.splice(index, 1)

        await challengeRoles.saveAsync()
        await interaction.reply({
            content: `Removed the role ${role}.`,
            flags: MessageFlags.Ephemeral,
        })
    }
}
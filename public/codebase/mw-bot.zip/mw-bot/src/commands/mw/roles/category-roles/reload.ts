import {
    ChatInputCommandInteraction,
    MessageFlags,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import CategoryRoleData from '../../../../db-objects/data/category-roles'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class ReloadSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('reload')
        .setDescription('Reload the category roles on every users');

    async execute(interaction: ChatInputCommandInteraction) {
        const data = new CategoryRoleData(interaction.guild.id);
        await data.loadAsync();

        if (data.categoryRoleIds.length === 0) {
            await interaction.reply({ content: 'No category roles have been setup.', flags: MessageFlags.Ephemeral });
            return;
        }

        const totalMembers = interaction.guild.memberCount;
        let membersProcessed = 0;
        const reply = await interaction.reply('Reloading all the category roles...');
        let progressMessage = await reply.edit({ content: 'Reloading all the category roles...' });

        await this.dUtils().fetchDataAsync(interaction.guild, { members: true, roles: true })

        const guildMembers = interaction.guild.members.cache;

        const tasks = Array.from(guildMembers, async ([_, member]) => {
            await this.dUtils().updateMemberCategoryRolesAsync(member)
            membersProcessed++;

            if (membersProcessed % (totalMembers / 100) === 0) {
                progressMessage = await progressMessage.edit(`Reload... ${(membersProcessed / totalMembers * 100).toFixed(0)}%`);
            }
        });

        await Promise.all(tasks);

        progressMessage = await progressMessage.edit('Category roles reload finished');
    }
}
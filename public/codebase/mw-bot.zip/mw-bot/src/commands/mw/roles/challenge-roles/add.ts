import {
    ChatInputCommandInteraction,
    MessageFlags,
    SlashCommandSubcommandBuilder,
} from 'discord.js'
import ChallengeRolesData from '../../../../db-objects/data/challenge-roles-data'
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand'

export default class AddSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Adds a challenge role')
        .addRoleOption(option =>
            option
                .setName('role')
                .setDescription('The challenge role')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const role = interaction.options.getRole('role')
        const challengeRoles = new ChallengeRolesData(interaction.guild.id)
        await challengeRoles.loadAsync()

        const index = challengeRoles.challengeRoleIds.indexOf(role.id, 0)
        if (index > -1) {
            await interaction.reply({
                content: `${role} is already a challenge role.`,
                flags: MessageFlags.Ephemeral,
            })
            return
        }

        challengeRoles.challengeRoleIds.push(role.id)
        await challengeRoles.saveAsync()

        await interaction.reply({
            content: `Added the role ${role}.`,
            flags: MessageFlags.Ephemeral,
        })
    }
}
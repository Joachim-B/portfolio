import {
    ActionRowBuilder,
    APIApplicationCommandOptionChoice,
    BaseInteraction,
    ButtonBuilder,
    ButtonInteraction,
    ButtonStyle,
    CacheType,
    ChatInputCommandInteraction,
    RestOrArray,
    SlashCommandBuilder,
} from 'discord.js'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'
import { InteractionPrefix, Categories } from '../../../utils/common/sharedEnums'
import { Dictionary, InteractionError, MWEmbedBuilder } from '../../../utils/common/sharedElements'
import ChampionshipsData, { ChampionshipsSettings, GuildData, TeamData } from '../../../db-objects/data/championship-data'
import ChampionshipUtils from '../../../utils/championship-utils/utils'

export default class ShowCommand extends BaseSlashCommand {
    category = Categories.championship
    command = this.getCommand()

    getCommand(teamChoices?: APIApplicationCommandOptionChoice<string>[], multipleServers?: boolean) {
        const command = new SlashCommandBuilder()
            .setName('show')
            .setDescription('Display a scoreboard')

        if (teamChoices) {
            const defaultChoices: RestOrArray<APIApplicationCommandOptionChoice<string>> = [{ name: 'Global', value: ScoreboardType.global }, { name: 'Solo', value: ScoreboardType.solo }]
            if (multipleServers) {
                defaultChoices.push(
                    { name: 'Global (Server only)', value: `${ScoreboardType.globalServerOnly}` },
                    { name: 'Solo (Server only)', value: ScoreboardType.soloServerOnly },
                    { name: 'Servers Average', value: ScoreboardType.serverAverage }
                )
            }
            defaultChoices.push(...teamChoices)

            command.addStringOption((option) =>
                option
                    .setName('scoreboard')
                    .setDescription('The team to delete')
                    .setRequired(true)
                    .addChoices(defaultChoices))
                .addBooleanOption(o => o
                    .setName('show-usernames')
                    .setDescription('Show player usernames instead of IDs')
                )
        }

        return command
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const scoreboard = interaction.options.getString('scoreboard')
        const showUsernames = interaction.options.getBoolean('show-usernames') ?? false
        if (!scoreboard) {
            throw new InteractionError('No scoreboard has been specified!')
        }

        await this.displayScoreboard(interaction, scoreboard, 1, showUsernames)
    }

    async handleLeaderboardButton(interaction: ButtonInteraction<CacheType>) {
        const { customId } = interaction
        const buttonSections = customId.split('.')
        const scoreboardType = buttonSections[1]
        const page = Number.parseInt(buttonSections[2])
        const showUsernames = buttonSections[3] != undefined

        await this.displayScoreboard(interaction, scoreboardType, page, showUsernames)
    }

    async displayScoreboard(interaction: BaseInteraction, scoreboardType: string, page: number, showUsernames: boolean) {
        if (interaction.isChatInputCommand()) {
            await interaction.deferReply()
        }
        const data = new ChampionshipsData(interaction.guildId);
        const championship = (await data.getChampionshipAsync()).data

        let scoreboardData: ScoreboardData
        switch (scoreboardType) {
            case ScoreboardType.global:
                scoreboardData = this.getGlobalScoreboard(championship)
                break;
            case ScoreboardType.globalServerOnly:
                scoreboardData = this.getGlobalScoreboard(championship, interaction.guildId)
                break;
            case ScoreboardType.solo:
                scoreboardData = this.getSoloScoreboard(championship, showUsernames)
                break;
            case ScoreboardType.soloServerOnly:
                scoreboardData = this.getSoloScoreboard(championship, showUsernames, interaction.guildId)
                break;
            case ScoreboardType.serverAverage:
                scoreboardData = this.getServerScoreboard(championship)
                break;
            default:
                scoreboardData = this.getTeamScoreboard(championship, scoreboardType, showUsernames)
                break;
        }

        const color = Object.values(ScoreboardType).includes(scoreboardType as ScoreboardType) ? 0xf1c557 : 0x900000
        const embed = new MWEmbedBuilder(false)
            .setTitle(scoreboardData.title)
            .setDescription(this.generateScoreboardString(scoreboardData.scoreboard, page))
            .setColor(color)
            .setFooter({text: 'Wanna join? Type \'/championship\''})

        const buttons = this.generatePaginationButtons(page, scoreboardData.scoreboard?.length ?? 0, scoreboardType, showUsernames)

        if (interaction.isChatInputCommand()) {
            await interaction.editReply({ embeds: [embed], components: buttons ? [buttons] : undefined })
        }
        else if (interaction.isButton()) {
            await interaction.update({ embeds: [embed], components: buttons ? [buttons] : undefined })
        }
    }

    private getGlobalScoreboard(championship: ChampionshipsSettings, guildId?: string) {
        const title = `__${championship.name}__ Leaderboard${guildId ? ' (Server-only)' : ''}`
        const teamScores = this.getGlobaLeaderboardItems(championship, guildId)
        return new ScoreboardData(title, teamScores)
    }

    private getSoloScoreboard(championship: ChampionshipsSettings, showUsernames: boolean, guildId?: string) {
        const embedTitle = `__${championship.name}__ Solo Leaderboard${guildId ? ' (Server-only)' : ''}`
        const playerScores = this.getSoloLeaderboardItems(championship, guildId, showUsernames)
        return new ScoreboardData(embedTitle, playerScores)
    }

    private getTeamScoreboard(championship: ChampionshipsSettings, teamId: string, showUsernames: boolean) {
        const team = championship.teams[teamId]
        if (!team) {
            const embedTitle = 'This team doesn\'t exist'
            return new ScoreboardData(embedTitle, undefined)
        }

        const embedTitle = `__${team.name}__ Leaderboard`

        const playersArray = Object.entries(team.scoreboard).map(([playerId, player]) => {
            const displayName = showUsernames ? `\`@${player.username}\`` : `<@${playerId}>`;
            return new LeaderboardItem(displayName, player.score);
        })

        playersArray.sort((a, b) => b.score - a.score);

        if (team.bonusPoints && team.bonusPoints != 0) {
            playersArray.push(new LeaderboardItem('Bonus', team.bonusPoints))
        }

        return new ScoreboardData(embedTitle, playersArray)
    }

    private getServerScoreboard(championship: ChampionshipsSettings) {
        const guilds = championship.guilds
        const serverLeaderboard = Object.values(guilds).map(guild => {
            const serverScore = Object.values(guild.teamIds.map(id => championship.teams[id]))?.reduce((sum, team) => sum + (team.totalPoints ?? 0), 0)
            const teamCount = guild.teamIds.length
            const serverAverage = teamCount > 0 ? Math.fround(serverScore / teamCount) : 0
            return new LeaderboardItem(`${guild.name}\n   [Points: ${serverScore}; Teams: ${teamCount}] Average`, serverAverage)
        })

        serverLeaderboard.sort((a, b) => b.score - a.score);

        const embedTitle = 'Average points per servers'

        return new ScoreboardData(embedTitle, serverLeaderboard)
    }

    generateScoreboardString(leaderboard: LeaderboardItem[], page: number): string {
        if (!leaderboard || leaderboard.length == 0) {
            return 'The scoreboard is empty'
        }
        const start = (page - 1) * ITEMS_PER_PAGE

        const description = Array.from(leaderboard).splice(start, ITEMS_PER_PAGE).map((item, index) => {
            const position = index + start + 1
            switch (position) {
                case 1:
                    return `### 🏆 ${position}. ${item.name} : **${item.score}**`
                case 2:
                    return `**🥈 ${position}. ${item.name} : ${item.score}**`
                case 3:
                    return `**🥉 ${position}. ${item.name} : ${item.score}**\n`
                default:
                    return `${position}. ${item.name} : **${item.score}**`
            }
        }).join('\n');

        return description == '' ? 'Invalid request' : description
    }

    private generatePaginationButtons(page: number, totalEntries: number, leaderboardType: ScoreboardType | string, showUsernames: boolean) {
        const totalPages = Math.ceil(totalEntries / ITEMS_PER_PAGE);
        if (totalPages <= 1) {
            return
        }

        const leaderboardString = typeof leaderboardType !== 'string' ? ScoreboardType[leaderboardType] : leaderboardType
        const buttonIdPrefix = `${InteractionPrefix[InteractionPrefix.champLeaderboard]}.${leaderboardString}`

        const row = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`${buttonIdPrefix}.${page - 1}${showUsernames ? '.@' : ''}`)
                    .setLabel('◀️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(page === 1),
                new ButtonBuilder()
                    .setCustomId('page')
                    .setLabel(`${page}/${totalPages}`)
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId(`${buttonIdPrefix}.${page + 1}${showUsernames ? '.@' : ''}`)
                    .setLabel('▶️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(page === totalPages)
            );

        return row;
    }

    getGlobaLeaderboardItems(championship: ChampionshipsSettings, guildId: string) {
        const formatLeaderboardItem = (teamName: string, alias?: string) => {
            return alias ? `${teamName} (${alias})` : teamName;
        };

        const {teams, aliasMap} = this.getScoreboardScale(championship, guildId)

        const teamScores = Object.values(teams).map(team => {
            const alias = aliasMap ? aliasMap[team.guildId]?.alias : undefined;
            const displayName = formatLeaderboardItem(team.name, alias);
            return new LeaderboardItem(displayName, team.totalPoints)
        })
        teamScores.sort((a, b) => b.score - a.score);
        return teamScores
    }

    private getSoloLeaderboardItems(championship: ChampionshipsSettings, guildId: string, showUsernames: boolean) {
        const formatLeaderboardItem = (playerId: string, player: any, alias?: string) => {
            const displayName = showUsernames ? `\`@${player.username}\`` : `<@${playerId}>`;
            return alias ? `${displayName} (${alias})` : displayName;
        };

        const {teams, aliasMap} = this.getScoreboardScale(championship, guildId)

        const playerScores = Object.values(teams).flatMap(team =>
            Object.entries(team.scoreboard).map(([playerId, player]) => {
                const alias = aliasMap ? aliasMap[team.guildId]?.alias : undefined;
                const displayName = formatLeaderboardItem(playerId, player, alias);
                return new LeaderboardItem(displayName, player.score);
            })
        );
        playerScores.sort((a, b) => b.score - a.score);
        return playerScores
    }

    private getScoreboardScale(championship: ChampionshipsSettings, guildId: string) {
        let teams: Dictionary<TeamData>
        let aliasMap: Dictionary<GuildData>

        if (guildId) {
            teams = new ChampionshipUtils().getGuildTeams(guildId, championship);
        } else {
            teams = championship.teams;
            if (Object.keys(championship.guilds).length > 1) {
                aliasMap = championship.guilds;
            }
        }
        return {teams, aliasMap}
    }
}

const ITEMS_PER_PAGE = 10

class ScoreboardData {
    title: string
    scoreboard: LeaderboardItem[]

    constructor(title: string, scoreboard: LeaderboardItem[]) {
        this.title = title
        this.scoreboard = scoreboard
    }
}

class LeaderboardItem {
    name: string;
    score: number;

    constructor(name: string, score: number) {
        this.name = name;
        this.score = score;
    }
}

export enum ScoreboardType {
    global = 'GLOBAL',
    solo = 'SOLO',
    globalServerOnly = 'GLOBAL_SERVER',
    soloServerOnly = 'SOLO_SERVER',
    serverAverage = 'SERVER_AVERAGE'
}
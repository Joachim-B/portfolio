import BaseSlashSubCommandGroup from '../../../../utils/common/abstraction/baseSlashSubCommandGroup';

export default class ChampRegistrationSubCommand extends BaseSlashSubCommandGroup {
    constructor() {
        super(__filename)
    }
}
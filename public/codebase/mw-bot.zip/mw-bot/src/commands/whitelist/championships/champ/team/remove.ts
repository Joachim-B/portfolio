import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, APIApplicationCommandOptionChoice } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../../db-objects/data/championship-data';
import { InteractionError } from '../../../../../utils/common/sharedElements';
import ChampionshipUtils, { IScoreBoardDynamicSubCommand } from '../../../../../utils/championship-utils/utils';

export default class ChampTeamRemoveSubCommand extends BaseSlashSubCommand implements IScoreBoardDynamicSubCommand {
    command = this.getCommand()
    async execute(interaction: ChatInputCommandInteraction) {
        const teamId = interaction.options.getString('team')
        if (!teamId) {
            throw new InteractionError('No team has been specified!')
        }

        const result = await this.dUtils().displayConfirmationMessage(interaction, 'Are you sure to remove this team ?')
        if (!result.confirmed) {
            return
        }

        const data = new ChampionshipsData(interaction.guildId)
        await data.removeTeamAsync(teamId)

        await new ChampionshipUtils().reloadCommandsChoices(interaction)
        await result.confirmationMessage.update({content: 'The team has been removed successfully.', components: []})
    }
    getCommand(teamChoices?: APIApplicationCommandOptionChoice<string>[]) {
        const command = new SlashCommandSubcommandBuilder()
            .setName('remove')
            .setDescription('Remove a team')
        
        if (teamChoices) {
            command.addStringOption((option) =>
                option
                    .setName('team')
                    .setDescription('The team to delete')
                    .setRequired(true)
                    .addChoices(...teamChoices))
        }

        return command
    }
}
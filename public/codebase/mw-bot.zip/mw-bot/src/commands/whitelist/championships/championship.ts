import { SlashCommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand';
import { Categories } from '../../../utils/common/sharedEnums';
import ChampionshipsData, { ChampionshipsSettings } from '../../../db-objects/data/championship-data';
import { MWEmbedBuilder } from '../../../utils/common/sharedElements';
import ShowCommand from './show';

export default class ChampionshipCommand extends BaseSlashCommand {
    command = new SlashCommandBuilder()
        .setName('championship')
        .setDescription('Get info about the championship')
    category = Categories.championship;
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        await interaction.deferReply()
        const data = new ChampionshipsData(interaction.guildId);

        const description = await this.getConfig(data)
        const embed = new MWEmbedBuilder()
            .setDescription(description)
            .setColor(0xf1c557)

        await embed.displayMWEmbed(interaction)
    }

    private async getConfig(data: ChampionshipsData): Promise<string> {
        const showCommand = new ShowCommand()

        const descriptionP1 =
            `### What is the Championship?
Participate in daily challenges for two weeks to lead your team to the top of the leaderboard!
### What kind of daily challenges?
- **Self-improvement tasks**
- **Mental health tasks**
- **Physical tasks** *... and much more!*

**__Join the championship now by entering the designated channel!__**`;

        try {
            const championship = (await data.getChampionshipAsync()).data
            const welcomeTitle = `## Welcome to __${championship.name}__ !`
            const competingServers = Object.keys(championship.guilds).length === 1 ? ''
                : `\n### Competing servers :
${await this.getCompetingServers(championship, data)}`;

            const leaderboard = `\n### Current leaderboard :
${showCommand.generateScoreboardString(showCommand.getGlobaLeaderboardItems(championship, undefined), 1)}

**__Number of participants :__ ${Object.keys(championship.playerToTeamMapping).length}**`

            return `${welcomeTitle}\n${descriptionP1}${leaderboard}${competingServers}`;
        }
        catch {
            return `## Welcome to the __Championship__ !\n${descriptionP1}`
        }
        

        
    }

    private async getCompetingServers(championship: ChampionshipsSettings, data: ChampionshipsData): Promise<string> {
        return (await Promise.all(Object.entries(championship.guilds).map(async ([guildId, guildData]) => {
            const settings = await data.getGuildSettingsAsync(guildId)
            const serverDescription = settings.serverDescription ? ` : ${settings.serverDescription}` : ''
            const inviteLink = settings.inviteLink ? ` **[Join this server!](${settings.inviteLink})**` : ''
            return `**${guildData.name}**${serverDescription}${inviteLink}`
        }))).join('\n')
    }
}
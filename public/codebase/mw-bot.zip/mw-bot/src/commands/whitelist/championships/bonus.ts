import { ChatInputCommandInteraction } from 'discord.js';
import BaseSlashCommandGroup from '../../../utils/common/abstraction/baseSlashCommandGroup'
import { Categories } from '../../../utils/common/sharedEnums';
import ChampionshipUtils, { ChampionshipRoles } from '../../../utils/championship-utils/utils';

export default class ChampCommandBase extends BaseSlashCommandGroup {
    constructor() {
        super(Categories.championship, __filename)
    }
    protected override async beforeExecute(interaction: ChatInputCommandInteraction) {
        await new ChampionshipUtils().throwIfChampCommandUnavailable(interaction, ChampionshipRoles.teamLeader)
    }
}
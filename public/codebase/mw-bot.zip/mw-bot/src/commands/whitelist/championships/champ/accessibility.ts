import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../db-objects/data/championship-data';
import { InteractionError } from '../../../../utils/common/sharedElements';

export default class AccessibilitySubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('accessibility')
        .setDescription('Set the championship public or private')
        .addBooleanOption((option) =>
            option
                .setName('public')
                .setDescription('Make the championship public ?')
                .setRequired(true)
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const publicState = interaction.options.getBoolean('public')

        const guildId = interaction.guildId
        const data = new ChampionshipsData(guildId)
        const champId = await data.getChampId()
        if (champId != guildId) {
            throw new InteractionError('Only the host server can perform this action.')
        }

        await data.setChampionshipVisibilityAsync(champId, publicState)

        const reply = publicState
            ? `The championship is now **public**. To join this championship from another server, use the \`/champ join\` command with the following ID: \`${champId}\`.`
            : 'The championship is now **private**.'

        await interaction.reply({content: reply})
    }
}
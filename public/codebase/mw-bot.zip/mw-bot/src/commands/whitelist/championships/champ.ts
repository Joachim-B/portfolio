import { ChatInputCommandInteraction, PermissionsBitField } from 'discord.js';
import BaseSlashCommandGroup from '../../../utils/common/abstraction/baseSlashCommandGroup'
import { Categories } from '../../../utils/common/sharedEnums';
import ChampionshipUtils, { ChampionshipRoles } from '../../../utils/championship-utils/utils';

export default class ChampCommandBase extends BaseSlashCommandGroup {
    constructor() {
        super(Categories.championshipSetup, __filename)
        this.command.setDefaultMemberPermissions(PermissionsBitField.Flags.ManageRoles)
    }
    protected override async beforeExecute(interaction: ChatInputCommandInteraction) {
        await new ChampionshipUtils().throwIfChampCommandUnavailable(interaction, ChampionshipRoles.manager)
    }
}
import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonInteraction,
    ButtonStyle,
    CacheType,
    ChatInputCommandInteraction,
    SlashCommandBuilder,
} from 'discord.js'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'
import { Categories, InteractionPrefix } from '../../../utils/common/sharedEnums'
import ChampionshipsData from '../../../db-objects/data/championship-data'
import ChampionshipUtils, { ChampionshipRoles } from '../../../utils/championship-utils/utils'

export default class SubmitCommand extends BaseSlashCommand {
    category = Categories.championship
    command = new SlashCommandBuilder()
        .setName('submit')
        .setDescription('Submit points to the leaderboard')
        .addIntegerOption(o => o
            .setName('points')
            .setDescription('The amount of points')
            .setRequired(true)
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const utils = new ChampionshipUtils()
        await utils.throwIfChampCommandUnavailable(interaction, ChampionshipRoles.challenger)
        await interaction.deferReply()
        const data = new ChampionshipsData(interaction.guildId)
        const playerId = interaction.user.id
        const points = interaction.options.getInteger('points')
        const buttonRow = this.getButtons(playerId, points)

        await interaction.editReply({ content: `:new: New submission of **${points}** points by <@${playerId}>`, components: [buttonRow] })
    }

    private getButtons(playerId: string, points: number) {
        const buttonIdPrefix = `${InteractionPrefix[InteractionPrefix.champSubmit]}.${playerId}.${points}`
        const row = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`${buttonIdPrefix}.ok`)
                    .setLabel('Validate')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId(`${buttonIdPrefix}.cancel`)
                    .setLabel('Cancel')
                    .setStyle(ButtonStyle.Secondary)
            );

        return row;
    }

    async handleLeaderboardButton(interaction: ButtonInteraction<CacheType>) {
        const { customId } = interaction
        const buttonSections = customId.split('.')
        const playerId = buttonSections[1]
        const points = Number.parseInt(buttonSections[2])
        const action = buttonSections[3]

        const authorId = interaction.user.id

        const utils = new ChampionshipUtils()
        const data = new ChampionshipsData(interaction.guildId)

        if (action == 'cancel') {
            if (authorId != playerId) {
                await utils.throwIfChampCommandUnavailable(interaction, ChampionshipRoles.teamLeader)
            }
            await interaction.update({ content: `:x: Submission of **${points}** points cancelled.`, components: [] })
        }
        else {
            await utils.throwIfChampCommandUnavailable(interaction, ChampionshipRoles.teamLeader)
            await data.addScoreAsync(playerId, points)
            await interaction.update({ content: `:white_check_mark: Submission of **${points}** points completed!`, components: [] })
        }
    }

}
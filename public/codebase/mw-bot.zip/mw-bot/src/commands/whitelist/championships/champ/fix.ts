import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../db-objects/data/championship-data';
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements';

export default class ChampFixSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('fix')
        .setDescription('Fix the scoreboards\' values')
        .addStringOption(o => o
            .setName('fix-type')
            .setDescription('The fixing attribute')
            .setChoices([
                {name: 'Total points', value: 'TOTAL_POINTS'}
            ])
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new ChampionshipsData(interaction.guildId)
        const result = await data.updateTotalScoresAsync()
        if (result.length == 0) {
            await interaction.reply({content: 'The teams are up to date.'})
        }
        else {
            const resultsToString = result.map(r => `**${r.team.name}** ⮕ ${r.scoreDifference > 0 ? '+' : ''}${r.scoreDifference}`).join('\n')
            const description = `The total points for some teams have been updated :\n\n${resultsToString}`

            const embed = new MWEmbedBuilder()
                .setTitle('Total points update :')
                .setDescription(description)

            await interaction.reply({embeds: [embed]})
        }
    }
}
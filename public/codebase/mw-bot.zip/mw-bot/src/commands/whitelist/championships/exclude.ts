import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js'
import { Categories } from '../../../utils/common/sharedEnums'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'
import ChampionshipsData from '../../../db-objects/data/championship-data'
import ChampionshipUtils, { ChampionshipRoles } from '../../../utils/championship-utils/utils'
import { InteractionError } from '../../../utils/common/sharedElements'
import RegistrationUtils from '../../../utils/championship-utils/registration-utils'

export default class ExcludeCommand extends BaseSlashCommand {
    category = Categories.championship
    command = new SlashCommandBuilder()
        .setName('exclude')
        .setDescription('Remove a player from the championship')
        .addUserOption(o => o
            .setName('player')
            .setDescription('The player to exclude')
            .setRequired(true)
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const utils = new ChampionshipUtils()
        await utils.throwIfChampCommandUnavailable(interaction, ChampionshipRoles.teamLeader)
        const player = interaction.options.getUser('player')
        const data = new ChampionshipsData(interaction.guildId)
        const championship = await data.getChampionshipAsync()

        if (!championship.data.playerToTeamMapping[player.id]) {
            throw new InteractionError('The selected player hasn\'t joined any team! They might be missing a role.')
        }

        const result = await this.dUtils().displayConfirmationMessage(interaction, 'Are you sure to exclude this player ?')
        if (!result.confirmed) {
            return
        }

        utils.checkPlayerUpdateValidity(championship.data, interaction.guildId, player.id)

        const teamRoleId = championship.data.playerToTeamMapping[player.id]
        await data.removePlayersFromTeam(teamRoleId, player.id)

        const teamRole = await this.dUtils().getRoleAsync(teamRoleId, interaction.guild)
        const guildPlayer = await this.dUtils().getMemberAsync(player.id, interaction.guild)
        await this.dUtils().updateMemberRolesAsync(guildPlayer, null, teamRole)

        const replacedPlayer = await new RegistrationUtils().addNextApplicantToTeam(teamRoleId, championship.data, interaction.guild)
        const replaceMessage = replacedPlayer ? `and ${replacedPlayer} is now part of the team` : ''

        const playerCount = utils.getTeamPlayerCount((await data.getChampionshipAsync()).data.playerToTeamMapping, teamRoleId)
        const managerRoleId = (await data.getGuildSettingsAsync(interaction.guildId)).managerRoleId
        const pingManagerString = managerRoleId ? ` <@&${managerRoleId}>` : ''
        const playerCountString = playerCount == 1 ? 'There is **1** member left in the team.' : `There are **${playerCount}** members left in the team.`

        await result.confirmationMessage.update({ content: `The member **${guildPlayer.displayName}** has been removed from **${championship.data.teams[teamRoleId].name}${replaceMessage}**. ${playerCountString}${pingManagerString}`, components: [] })
    }
}
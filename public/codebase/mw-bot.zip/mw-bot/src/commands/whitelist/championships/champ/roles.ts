import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../db-objects/data/championship-data';
import { InteractionError } from '../../../../utils/common/sharedElements';

export default class RoleSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
    .setName('roles')
    .setDescription('Set the roles needed for the championship')
    .addRoleOption((option) => 
        option
            .setName('team-leaders')
            .setDescription('The Team leader role')
    )
    .addRoleOption((option) => 
        option
            .setName('players')
            .setDescription('The role common to every contestants')
    )
    async execute(interaction: ChatInputCommandInteraction) {
        const teamLeaderRole = interaction.options.getRole('team-leaders')
        const playerRole = interaction.options.getRole('players')

        if (!teamLeaderRole && !playerRole) {
            throw new InteractionError('No roles have been provided.')
        }

        const data = new ChampionshipsData(interaction.guildId)
        await data.setGuildRolesAsync(undefined, teamLeaderRole?.id, playerRole?.id)
        await interaction.reply({content: 'The role(s) has been updated successfully.'})
    }
}
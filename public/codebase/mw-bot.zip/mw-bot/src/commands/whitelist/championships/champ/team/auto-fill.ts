import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../../db-objects/data/championship-data';
import ChampionshipUtils from '../../../../../utils/championship-utils/utils';

export default class ChampTeamAutoFillSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('auto-fill')
        .setDescription('Fill teams with players from the waiting list automatically')
        .addBooleanOption(o => o
            .setName('value')
            .setDescription('Activate the process')
            .setRequired(true)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new ChampionshipsData(interaction.guildId)
        const autoFill = interaction.options.getBoolean('value')

        await data.setAutoFillTeamsAsync(autoFill)

        if (!autoFill) {
            await interaction.reply({ content: 'The data has been updated successfully.' })
            return
        }

        const champ = (await data.getChampionshipAsync()).data
        const guildTeams = new ChampionshipUtils().getGuildTeams(interaction.guildId, champ)
        const slotsAvailable = Object.values(guildTeams)
            .map(t => Math.max(0, champ.slotsPerTeam - Object.keys(t.scoreboard).length))
            .reduce((previous, current) => previous + current, 0)

        if (slotsAvailable == 0) {
            await interaction.reply({ content: 'The data has been updated successfully. **0** players have been added to the teams.' })
            return
        }

        await interaction.deferReply()
        const waitingList = champ.guilds[interaction.guildId].waitinglist ?? []
        const newChallengersIdsRandom = waitingList.splice(0, slotsAvailable).sort(() => Math.random() - 0.5)
        const challengerCount = newChallengersIdsRandom.length

        for (const [id, team] of Object.entries(guildTeams)) {
            const teamAvailableSlots = champ.slotsPerTeam - Object.keys(team.scoreboard).length;

            if (teamAvailableSlots > 0 && newChallengersIdsRandom.length > 0) {
                const selectedNewPlayers = await Promise.all(
                    newChallengersIdsRandom.splice(0, teamAvailableSlots).map(p => this.dUtils().getMemberAsync(p, interaction.guild))
                );

                if (selectedNewPlayers.length > 0) {
                    const role = await this.dUtils().getRoleAsync(id, interaction.guild);

                    await Promise.all([
                        ...selectedNewPlayers.map(p => this.dUtils().updateMemberRolesAsync(p, role)),
                        data.addPlayersToTeam(id, ...selectedNewPlayers),
                    ]);
                }
            }
        }

        await interaction.editReply({ content: `The data has been updated successfully. **${challengerCount}** player(s) have been added to the teams.` })
    }
}
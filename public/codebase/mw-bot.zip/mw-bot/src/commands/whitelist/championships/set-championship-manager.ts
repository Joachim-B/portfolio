import {
    ChatInputCommandInteraction,
    PermissionsBitField,
    SlashCommandBuilder,
} from 'discord.js'
import ChampionshipsData from '../../../db-objects/data/championship-data'
import { MWEmbedBuilder } from '../../../utils/common/sharedElements';
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand';
import { Categories } from '../../../utils/common/sharedEnums';

export default class ChampionshipManagerCommand extends BaseSlashCommand {
    category = Categories.championshipSetup;
    command = new SlashCommandBuilder()
        .setName('set-championship-manager')
        .setDescription('Sets the championship manager role')
        .addRoleOption((option) =>
            option
                .setName('role')
                .setDescription('The championship manager role')
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    async execute(interaction: ChatInputCommandInteraction) {
        const role = interaction.options.getRole('role');
        const data = new ChampionshipsData(interaction.guildId)
        await data.setGuildRolesAsync(role.id)
        const embed = new MWEmbedBuilder()
            .setTitle('Championship manager role updated !')
            .setDescription(`The championship manager role has been updated. <@&${role.id}> also need the **Manage Roles** permission to use the \`/champ\` command.`)
        await interaction.reply({embeds:[embed]})
    }
}

import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../../db-objects/data/championship-data';
import { InteractionError } from '../../../../../utils/common/sharedElements';

export default class ChampTeamMaxSlotsSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('slots-per-team')
        .setDescription('Set the max amount of slots available per team')
        .addIntegerOption(o => o
            .setName('value')
            .setDescription('The number of slots')
            .setMinValue(1)
            .setRequired(true)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new ChampionshipsData(interaction.guildId)
        const champId = await data.getChampId()

        if (champId != interaction.guildId) {
            throw new InteractionError('Only the host server can perform this action.')
        }

        const slotsCount = interaction.options.getInteger('value')
        await data.setTeamSlotsAsync(slotsCount)

        await interaction.reply({content: `The default number of slots per team is now : **${slotsCount}**`})
    }
}
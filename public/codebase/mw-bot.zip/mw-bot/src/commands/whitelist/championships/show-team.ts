import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js'
import { InteractionError } from '../../../utils/common/sharedElements'
import { Categories } from '../../../utils/common/sharedEnums'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'
import ChampionshipsData from '../../../db-objects/data/championship-data'
import ShowCommand from './show'

export default class ShowMyTeamCommand extends BaseSlashCommand {
    category = Categories.championship
    command = new SlashCommandBuilder()
        .setName('show-team')
        .setDescription('Displays the player\'s team scoreboard')
        .addBooleanOption(o => o
            .setName('show-usernames')
            .setDescription('Show player usernames instead of IDs')
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const showUsernames = interaction.options.getBoolean('show-usernames') ?? false
        const data = new ChampionshipsData(interaction.guildId)
        const championship = (await data.getChampionshipAsync()).data
        const playerTeamId = championship.playerToTeamMapping[interaction.user.id]
        if (!playerTeamId) {
            throw new InteractionError('You haven\'t joined any team yet!', false)
        }

        await new ShowCommand().displayScoreboard(interaction, playerTeamId, 1, showUsernames)
    }
}
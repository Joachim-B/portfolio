import BaseSlashSubCommandGroup from '../../../../utils/common/abstraction/baseSlashSubCommandGroup';

export default class TeamSubCommandGroup extends BaseSlashSubCommandGroup {
    constructor() {
        super(__filename)
    }
}
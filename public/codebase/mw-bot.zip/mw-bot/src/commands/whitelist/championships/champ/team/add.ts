import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../../db-objects/data/championship-data';
import ChampionshipUtils from '../../../../../utils/championship-utils/utils';
import { InteractionError, MWEmbedBuilder } from '../../../../../utils/common/sharedElements';

export default class ChampTeamAddSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Create a new team based on a given role')
        .addStringOption((option) =>
            option
                .setName('name')
                .setDescription('The team\'s name')
                .setRequired(true)
        )
        .addRoleOption((option) =>
            option
                .setName('role')
                .setDescription('The team\'s role (automatically creates one if unset)')
        )
    public async execute(interaction: ChatInputCommandInteraction) {
        const name = interaction.options.getString('name')
        let role = interaction.options.getRole('role', false)
        // const channel = interaction.options.getChannel('team-channel')

        await interaction.deferReply()

        const players = role ? (await interaction.guild.roles.fetch(role.id)).members : undefined
        const hasPlayers = players ? players.size > 0 : false
        const data = new ChampionshipsData(interaction.guildId)
        const championship = await data.getChampionshipAsync()

        if (!role) {
            role = await interaction.guild.roles.create({ name, color: 'Gold', mentionable: true })
        }
        else {
            if (Object.keys(championship.data.teams).includes(role.id)) {
                throw new InteractionError('A team with the provided role already exists. Please delete the existing team first to proceed.', false)
            }
        }

        await data.createTeamAsync(name, role.id)

        if (hasPlayers) {
            await data.addPlayersToTeam(role.id, ...Array.from(players.values()))
        }

        await new ChampionshipUtils().reloadCommandsChoices(interaction)

        const teamMemberDescription = hasPlayers ? players.map(p => `<@${p.id}> (\`@${p.user.username}\`)`).join('\n')
            : `*There are no members on the team yet. Assign the ${role} role to members to include them in the team.*`

        const embed = new MWEmbedBuilder()
            .setTitle(`Team ${name} created !`)
            .setDescription(`Role associated : ${role}\n\nTeam members : \n${teamMemberDescription}`)

        await interaction.editReply({ embeds: [embed] })
    }
}
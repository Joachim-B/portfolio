import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, APIApplicationCommandOptionChoice } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../../db-objects/data/championship-data';
import { InteractionError } from '../../../../../utils/common/sharedElements';
import ChampionshipUtils, { IScoreBoardDynamicSubCommand } from '../../../../../utils/championship-utils/utils';

export default class ChampForceRemoveSubCommand extends BaseSlashSubCommand implements IScoreBoardDynamicSubCommand {
    command = this.getCommand()
    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player')
        const teamId = interaction.options.getString('team')
        const points = interaction.options.getInteger('points')
        if (!(player && teamId && points)) {
            throw new InteractionError('No player or team have been specified!')
        }

        await interaction.deferReply()
        const newScore = await new ChampionshipsData(interaction.guildId).substractScoreForceAsync(teamId, player, points)
        await interaction.editReply({ content: new ChampionshipUtils().getScoreUpdateFormat(player.displayName, newScore + points, newScore, '-' + points) })
    }

    getCommand(teamChoices?: APIApplicationCommandOptionChoice<string>[]) {
        const command = new SlashCommandSubcommandBuilder()
            .setName('remove')
            .setDescription('Remove points from a specific player and a specific team')

        if (teamChoices) {
            command.addUserOption(o => o
                .setName('player')
                .setDescription('The selected player')
                .setRequired(true)
            )
                .addStringOption((option) =>
                    option
                        .setName('team')
                        .setDescription('The selected team')
                        .setRequired(true)
                        .addChoices(...teamChoices)
                )
                .addIntegerOption(o => o
                    .setName('points')
                    .setDescription('The points to remove')
                    .setMinValue(1)
                    .setRequired(true)
                )
        }

        return command
    }
}
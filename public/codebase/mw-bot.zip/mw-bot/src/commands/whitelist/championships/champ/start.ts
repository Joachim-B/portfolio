import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../db-objects/data/championship-data';
import ChampionshipUtils from '../../../../utils/championship-utils/utils';
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements';

export default class CreateSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('start')
        .setDescription('Start a championship in the server')
        .addStringOption((option) =>
            option
                .setName('name')
                .setDescription('The championship\'s name')
                .setRequired(true)
        )
        .addIntegerOption(o => o
            .setName('slots-per-team')
            .setDescription('Set the max amount of players per teams')
            .setRequired(true)
            .setMinValue(1)
        )
        .addBooleanOption((option) =>
            option
                .setName('public')
                .setDescription('Allows other servers to join the championship (default:false)')
        )
        .addStringOption((option) =>
            option
                .setName('server-acronym')
                .setDescription('Set the server acronym (4 letters max)')
                .setMaxLength(4)
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const message = 'Are you sure you want to start a new championship ? The data of any current championship joined or hosted will be lost.'
        const result = await this.dUtils().displayConfirmationMessage(interaction, message)
        if (!result.confirmed) {
            return
        }

        const utils = new ChampionshipUtils()
        await utils.cleanExistingChampionship(interaction)

        const championshipName = interaction.options.getString('name')
        const publicState = interaction.options.getBoolean('public')
        const acronym = interaction.options.getString('server-acronym')
        const slotsPerTeam = interaction.options.getInteger('slots-per-team')
        const data = new ChampionshipsData(interaction.guildId)
        await data.createChampionshipAsync(championshipName, interaction.guild.name, slotsPerTeam, publicState, acronym ?? interaction.guild.nameAcronym)
        await utils.reloadCommandsChoices(interaction)

        const description =
            `**Championship ID :** ${interaction.guildId}

**__Walkthrough of the Championship Setup Process:__**

1. **Setup the Championship Manager Role:**
   Use the \`/set-championship-manager\` command to create the Championship Manager role.
   This role is required to access the \`/champ\` command and manage the championship.

2. **Setup Team Leader and Challenger Roles:**
   Use the \`/champ roles\` command to create the Team Leader and Challenger roles. 
   Team Leaders will have the ability to manage scoreboards.

3. **Create Teams:**
   Use \`/champ team add\` to create teams.
   You can either assign team roles to participants, or start the registrations for the championship with \`/champ registrations open\`.
   Once the registrations are finished, use \`/champ team auto-fill\` to fill the teams with players.

4. **Start the Championship:**  
   - \`/add\` to add points to a scoreboard.  
   - \`/remove\` to remove points from a scoreboard.  
   - \`/show\` to display a scoreboard.

**Need Support?**  
For any assistance with the bot, join our Discord server to get help with any issues.
Invite link in the bot's profile.`
        const embed = new MWEmbedBuilder()
            .setTitle(`__${championshipName}__ have now begun! 🎉`)
            .setDescription(description)
        await result.confirmationMessage.update({ embeds: [embed], components: [] });
    }
}
import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, APIApplicationCommandOptionChoice, UserSelectMenuBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ButtonInteraction, CacheType, UserSelectMenuInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData, { ChampionshipsSettings, PlayerData } from '../../../../../db-objects/data/championship-data';
import { Dictionary, InteractionError, MWEmbedBuilder } from '../../../../../utils/common/sharedElements';
import { InteractionPrefix } from '../../../../../utils/common/sharedEnums';

export default class ChampTeamConfigSubCommand extends BaseSlashSubCommand {
    command = this.getCommand()
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const teamId = interaction.options.getString('team')
        if (!teamId) {
            throw new InteractionError('No team has been specified!')
        }
        await interaction.deferReply()
        const data = new ChampionshipsData(interaction.guildId)
        const championship = (await data.getChampionshipAsync()).data
        await this.displayDefaultView(interaction, teamId, championship)
    }

    // #region Handle Events

    async handleButtonClick(interaction: ButtonInteraction<CacheType>) {
        const { teamId, status } = this.getParameters(interaction)
        await interaction.deferUpdate()

        const data = new ChampionshipsData(interaction.guildId)
        const champ = (await data.getChampionshipAsync()).data

        if (status != 'back') {
            await this.displayEditingView(interaction, teamId, champ, status)
        }
        else {
            await this.displayDefaultView(interaction, teamId, champ)
        }
    }

    async handleUserSelectMenu(interaction: UserSelectMenuInteraction) {
        const { teamId, status } = this.getParameters(interaction)
        await interaction.deferUpdate()

        const data = new ChampionshipsData(interaction.guildId)

        const guildMembersSelected = await Promise.all(interaction.values.map(async id => await this.dUtils().getMemberAsync(id, interaction.guild)))
        const role = await this.dUtils().getRoleAsync(teamId, interaction.guild)

        if (status == 'add') {
            await data.addPlayersToTeam(teamId, ...guildMembersSelected)
            try {
                await Promise.all(guildMembersSelected.map(m => m.roles.add(role)))
            }
            catch { /* */ }
        }
        else {
            await data.removePlayersFromTeam(teamId, ...interaction.values)
            try {
                await Promise.all(guildMembersSelected.map(m => m.roles.remove(role)))
            }
            catch { /* */ }
        }

        const champ = (await data.getChampionshipAsync()).data
        await this.displayEditingView(interaction, teamId, champ, status)
    }

    private getParameters(interaction: ButtonInteraction<CacheType> | UserSelectMenuInteraction) {
        const { customId } = interaction
        const buttonSections = customId.split('.')
        const teamId = buttonSections[1]
        const status = buttonSections[2]
        const authorId = buttonSections[3]

        if (authorId != interaction.user.id) {
            throw new InteractionError('Only the author can interact with this command!')
        }

        return { teamId, status }
    }

    //#endregion

    private async displayDefaultView(interaction: ChatInputCommandInteraction | ButtonInteraction, teamId: string, championship: ChampionshipsSettings) {
        const embed = await this.getEmbed(interaction, teamId, championship)
        const addPlayerButton = new ButtonBuilder()
            .setCustomId(`${InteractionPrefix.teamConfig}.${teamId}.add.${interaction.user.id}`)
            .setLabel('Add players')
            .setStyle(ButtonStyle.Primary)
        const removePlayerButton = new ButtonBuilder()
            .setCustomId(`${InteractionPrefix.teamConfig}.${teamId}.remove.${interaction.user.id}`)
            .setLabel('Remove players')
            .setStyle(ButtonStyle.Secondary);

        const buttonRow = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(addPlayerButton, removePlayerButton);

        await interaction.editReply({ embeds: [embed], components: [buttonRow] })
    }

    private async displayEditingView(interaction: ButtonInteraction | UserSelectMenuInteraction, teamId: string, championship: ChampionshipsSettings, buttonStatus: string) {
        const embed = await this.getEmbed(interaction, teamId, championship)
        const placeholder = buttonStatus == 'add' ? 'Add players to the team...' : 'Remove players from the team...'

        const playerMenu = new UserSelectMenuBuilder()
            .setCustomId(`${InteractionPrefix.teamConfig}.${teamId}.${buttonStatus}.${interaction.user.id}`)
            .setPlaceholder(placeholder)
            .setMinValues(0)
            .setMaxValues(15)
        const menu = new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(playerMenu)

        const confirmButton = new ButtonBuilder()
            .setCustomId(`${InteractionPrefix.teamConfig}.${teamId}.back.${interaction.user.id}`)
            .setLabel('Back')
            .setStyle(ButtonStyle.Primary);

        const button = new ActionRowBuilder<ButtonBuilder>().addComponents(confirmButton)

        await interaction.editReply({ embeds: [embed], components: [menu, button] })
    }

    private async getEmbed(interaction: ChatInputCommandInteraction | ButtonInteraction | UserSelectMenuInteraction, teamId: string, championship: ChampionshipsSettings) {
        const activePlayers = this.getActivePlayers(championship, teamId)
        const data = new ChampionshipsData(interaction.guildId)
        const teamLeaderRoleId = (await data.getGuildSettingsAsync()).teamLeaderRoleId

        let teamLeaderString = ''
        if (teamLeaderRoleId) {
            const teamLeaderRole = await this.dUtils().getRoleAsync(teamLeaderRoleId, interaction.guild)
            for (const [playerId, player] of Object.entries(activePlayers)) {
                if (teamLeaderRole.members.has(playerId)) {
                    teamLeaderString = `\n**Team Leader :** <@${playerId}> (\`@${player.username}\`)`
                    break;
                }
            }
        }

        const leaderboardItems = Object.entries(activePlayers).sort(([, a], [, b]) => b.score - a.score).map(([key, data]) => `**<@${key}>** (\`@${data.username}\`) : ${data.score}`)
        const teamLeaderboardString = this.generateScoreboardString(leaderboardItems)

        return new MWEmbedBuilder()
            .setTitle(`__${championship.teams[teamId].name}__ Config`)
            .setDescription(`**Role linked :** <@&${teamId}>${teamLeaderString}\n\n${teamLeaderboardString}`)
    }

    private getActivePlayers(championship: ChampionshipsSettings, teamId: string) {
        const activePlayers: Dictionary<PlayerData> = {}
        if (!championship.teams[teamId]) {
            return activePlayers
        }
        for (const playerId of Object.keys(championship.teams[teamId].scoreboard)) {
            if (championship.playerToTeamMapping[playerId] == teamId) {
                activePlayers[playerId] = championship.teams[teamId].scoreboard[playerId]
            }
        }
        return activePlayers
    }

    private generateScoreboardString(leaderboard: string[]): string {
        if (!leaderboard || leaderboard.length == 0) {
            return 'The scoreboard is empty'
        }
        const description = Array.from(leaderboard).map((item, index) => `${index + 1}. ${item}`).join('\n');
        return description == '' ? 'Invalid request' : description
    }

    getCommand(teamChoices?: APIApplicationCommandOptionChoice<string>[]) {
        const command = new SlashCommandSubcommandBuilder()
            .setName('config')
            .setDescription('Configurate a team')

        if (teamChoices) {
            command.addStringOption((option) =>
                option
                    .setName('team')
                    .setDescription('The team to display')
                    .setRequired(true)
                    .addChoices(...teamChoices))
        }

        return command
    }
}
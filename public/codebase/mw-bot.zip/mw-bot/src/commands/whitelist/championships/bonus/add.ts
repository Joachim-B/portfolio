import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, APIApplicationCommandOptionChoice } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipUtils, { IScoreBoardDynamicSubCommand } from '../../../../utils/championship-utils/utils';
import { InteractionError } from '../../../../utils/common/sharedElements';
import ChampionshipsData from '../../../../db-objects/data/championship-data';

export default class AddBonusSubCommand extends BaseSlashSubCommand implements IScoreBoardDynamicSubCommand {
    command = this.getCommand()

    public async execute(interaction: ChatInputCommandInteraction) {
        const teamId = interaction.options.getString('team')
        if (!teamId) {
            throw new InteractionError('No team has been specified!')
        }
        const points = interaction.options.getInteger('points')
        await interaction.deferReply()
        const newScore = await new ChampionshipsData(interaction.guildId).addBonusAsync(teamId, points)
        await interaction.editReply({ content: new ChampionshipUtils().getScoreUpdateFormat('Bonus', newScore - points, newScore, '+' + points) })
    }

    getCommand(teamChoices?: APIApplicationCommandOptionChoice<string>[]) {
        const command = new SlashCommandSubcommandBuilder()
            .setName('add')
            .setDescription('Add bonus points to a team')

        if (teamChoices) {
            command.addStringOption((option) =>
                option
                    .setName('team')
                    .setDescription('The selected team')
                    .setRequired(true)
                    .addChoices(...teamChoices))
                .addIntegerOption(o => o
                    .setName('points')
                    .setDescription('The points to add')
                    .setMinValue(1)
                    .setRequired(true)
                )
        }

        return command
    }
}
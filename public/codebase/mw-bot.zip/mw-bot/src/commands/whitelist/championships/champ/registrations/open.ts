import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, ChannelType, TextChannel } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData, { RegistrationMessageData } from '../../../../../db-objects/data/championship-data';
import { InteractionError } from '../../../../../utils/common/sharedElements';
import RegistrationUtils from '../../../../../utils/championship-utils/registration-utils';

export default class ChampWaitingListOpenSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('open')
        .setDescription('Open registrations to the championship')
        .addChannelOption(o => o
            .setName('channel')
            .setDescription('The channel to send the registration message in')
            .setRequired(true)
            .addChannelTypes(ChannelType.GuildText)
        )
        .addBooleanOption(o => o
            .setName('send-notifications')
            .setDescription('Send a message in the channel whenever a member registers')
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const channel = interaction.options.getChannel('channel') as TextChannel
        const sendNotification = interaction.options.getBoolean('send-notifications') ?? false

        const data = new ChampionshipsData(interaction.guildId)
        const champ = await data.getChampionshipAsync()

        const registrationData = champ.data.guilds[interaction.guildId].registrationMessage ?? new RegistrationMessageData()

        if (registrationData.registrationOpen && registrationData.channelId) {
            const message = await this.dUtils().getMessageAsync(registrationData.messageId, registrationData.channelId, interaction.guild)
            if (message) {
                throw new InteractionError(`The registrations are already open in <#${registrationData.channelId}>!`)
            }
            else {
                registrationData.messageId = undefined
            }
        }

        const confirm = await this.dUtils().displayConfirmationMessage(interaction, 'Are you sure you want to open the registrations ?')
        if (!confirm.confirmed) {
            return
        }

        if (registrationData.channelId && channel.id != registrationData.channelId) {
            const oldMessage = await this.dUtils().getMessageAsync(registrationData.messageId, registrationData.channelId, interaction.guild)
            if (oldMessage) {
                await oldMessage.delete()
            }
            registrationData.messageId = undefined
        }

        const registrationMessage = await new RegistrationUtils().createOpenRegistrationsMessage(channel, registrationData.messageId)
        registrationData.messageId = registrationMessage.id
        registrationData.channelId = channel.id
        registrationData.registrationOpen = true
        registrationData.sendNotifications = sendNotification

        await data.setRegistrationMessageDataAsync(registrationData)
        await confirm.confirmationMessage.update({ content: `The registrations are now open in ${channel} !`, components: [] })
    }
}
import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, APIApplicationCommandOptionChoice } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../../db-objects/data/championship-data';
import { InteractionError } from '../../../../../utils/common/sharedElements';
import ChampionshipUtils, { IScoreBoardDynamicSubCommand } from '../../../../../utils/championship-utils/utils';

export default class ChampTeamRenameSubCommand extends BaseSlashSubCommand implements IScoreBoardDynamicSubCommand {
    command = this.getCommand()
    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply()
        const teamId = interaction.options.getString('team')
        if (!teamId) {
            throw new InteractionError('No team has been specified!')
        }
        const newName = interaction.options.getString('new-name')

        const teamRole = await this.dUtils().getRoleAsync(teamId, interaction.guild)
        await teamRole?.setName(newName)

        const data = new ChampionshipsData(interaction.guildId)
        await data.renameTeamAsync(teamId, newName)
        await new ChampionshipUtils().reloadCommandsChoices(interaction)

        await interaction.editReply({content: 'The team has been renamed successfully.'})
    }
    getCommand(teamChoices?: APIApplicationCommandOptionChoice<string>[]) {
        const command = new SlashCommandSubcommandBuilder()
            .setName('rename')
            .setDescription('Rename a team')
        
        if (teamChoices) {
            command.addStringOption((option) =>
                option
                    .setName('team')
                    .setDescription('The team to delete')
                    .setRequired(true)
                    .addChoices(...teamChoices))
                .addStringOption((option) => 
                option
                    .setName('new-name')
                    .setDescription('The updated name')
                    .setRequired(true))
        }

        return command
    }
}
import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder, TextChannel } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../../db-objects/data/championship-data';
import { InteractionError } from '../../../../../utils/common/sharedElements';
import RegistrationUtils from '../../../../../utils/championship-utils/registration-utils';

export default class ChampWaitingListCloseSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('close')
        .setDescription('Close the registrations to the championship')

    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new ChampionshipsData(interaction.guildId)
        const registrationData = (await data.getChampionshipAsync()).data.guilds[interaction.guildId].registrationMessage

        if (!(registrationData?.registrationOpen ?? false)) {
            throw new InteractionError('The registrations are not open yet!')
        }

        const confirm = await this.dUtils().displayConfirmationMessage(interaction, 'Are you sure you want to close the registrations ?')
        if (!confirm.confirmed) {
            return
        }

        const message = await this.dUtils().getMessageAsync(registrationData.messageId, registrationData.channelId, interaction.guild)
        let channel: TextChannel
        if (message) {
            channel = message.channel as TextChannel
            await message.delete()
        }
        else {
            channel = await this.dUtils().getTextChannelAsync(registrationData.channelId, interaction.guild)
        }

        const editedMessage = await new RegistrationUtils().createCloseRegistrationsMessage(channel)

        registrationData.messageId = editedMessage.id
        registrationData.registrationOpen = false
        await data.setRegistrationMessageDataAsync(registrationData)

        await confirm.confirmationMessage.update({content: 'The registrations have been closed successfully.', components: []})
    }
}
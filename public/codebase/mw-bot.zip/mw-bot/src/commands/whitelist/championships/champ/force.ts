import BaseSlashSubCommandGroup from '../../../../utils/common/abstraction/baseSlashSubCommandGroup'

export default class ForceSubCommandGroup extends BaseSlashSubCommandGroup {
    constructor() {
        super(__filename)
    }
}
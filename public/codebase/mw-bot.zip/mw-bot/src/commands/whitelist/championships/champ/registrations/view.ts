import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../../db-objects/data/championship-data';
import { MWEmbedBuilder } from '../../../../../utils/common/sharedElements';

export default class ChampWaitingListViewSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('view')
        .setDescription('Display the waiting list')

    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new ChampionshipsData(interaction.guildId)
        const waitingList = (await data.getChampionshipAsync()).data.guilds[interaction.guildId].waitinglist

        const fetchedPlayers = await Promise.all(waitingList.map(id => this.dUtils().getMemberAsync(id, interaction.guild)))
        const hasMissingPlayers = fetchedPlayers.some(p => p == undefined);
        const players = fetchedPlayers.filter(p => p != undefined);

        const description = players.map((player, index) => `${index + 1}. ${player} \`@${player.user.username}\``).join('\n')

        const embed = new MWEmbedBuilder()
            .setTitle('Server Waiting list')
            .setDescription(`${description}\n\n**Total: ${players.length}**`)

        await embed.displayMWEmbed(interaction)

        if (hasMissingPlayers) {
            await data.setWaitingListAsync(players.map(p => p.id))
        }
    }
}
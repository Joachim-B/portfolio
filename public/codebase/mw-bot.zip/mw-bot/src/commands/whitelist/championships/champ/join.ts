import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../db-objects/data/championship-data';
import ChampionshipUtils from '../../../../utils/championship-utils/utils';
import { InteractionError } from '../../../../utils/common/sharedElements';

export default class JoinSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('join')
        .setDescription('Join an existing championship')
        .addStringOption((option) =>
            option
                .setName('id')
                .setDescription('The championship\'s name')
                .setRequired(true)
        )
        .addStringOption((option) =>
            option
                .setName('server-acronym')
                .setDescription('Set the server acronym (4 letters max)')
                .setMaxLength(4)
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const champId = interaction.options.getString('id')
        if (champId == interaction.guildId) {
            throw new InteractionError('You cannot join a championship hosted by your own server!')
        }

        const message = 'Are you sure you want to join this championship ? The data of any current championship joined or hosted will be lost.'
        const result = await this.dUtils().displayConfirmationMessage(interaction, message)
        if (!result.confirmed) {
            return
        }

        const utils = new ChampionshipUtils()
        await utils.cleanExistingChampionship(interaction)

        const acronym = interaction.options.getString('server-acronym')
        const data = new ChampionshipsData(interaction.guildId)
        await data.joinChampionshipAsync(champId, interaction.guild.name, acronym ?? interaction.guild.nameAcronym)
        await utils.reloadCommandsChoices(interaction)
        await result.confirmationMessage.update({ content: `**${interaction.guild.name}** is now part of **${(await data.getChampionshipAsync()).data.name}** !`, components: [] });
    }
}
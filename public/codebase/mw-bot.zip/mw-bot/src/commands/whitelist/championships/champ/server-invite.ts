import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData from '../../../../db-objects/data/championship-data';

export default class ChampServerInviteSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('server-invite')
        .setDescription('Setup the server invite and description')
        .addStringOption(o => o
            .setName('invite-link')
            .setDescription('The invite link to your server')
            .setMaxLength(100)
            .setRequired(true)
        )
        .addStringOption(o => o
            .setName('server-description')
            .setDescription('Add a small description')
            .setMaxLength(150)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const inviteLink = interaction.options.getString('invite-link')
        const description = interaction.options.getString('server-description') ?? ''
        const data = new ChampionshipsData(interaction.guildId)
        await data.setServerInviteAsync(inviteLink, description)
        await interaction.reply({content: 'The server invite data has been updated.'})
    }
}
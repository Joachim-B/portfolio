import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ChampionshipsData, { ChampionshipsSettings, GuildSettings } from '../../../../db-objects/data/championship-data';
import ChampionshipUtils from '../../../../utils/championship-utils/utils';
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements';

export default class ConfigSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('config')
        .setDescription('The config for the current championship')

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply()
        const data = new ChampionshipsData(interaction.guildId);
        const [championship, guildSettings] = await Promise.all([
            data.getChampionshipAsync(),
            data.getGuildSettingsAsync()
        ]);

        const title = `__${championship.data.name}__ Config`;
        const description = this.getConfig(championship.data, championship.id, guildSettings, true, true)
        const embed = new MWEmbedBuilder()
            .setTitle(title)
            .setDescription(description)

        await embed.displayMWEmbed(interaction)
    }

    private getConfig(championship: ChampionshipsSettings, champId: string, guildSettings: GuildSettings, showServersDetails: boolean, showTeamDetails: boolean): string {
        const descriptionP1 =
            `**Name :** ${championship.name}
**Championship ID :** ${champId}
**Status :** ${championship.public ? 'Public' : 'Private'}

**__Roles :__**
**Championship manager :** ${this.getRoleFormatted(guildSettings.managerRoleId)}
**Team Leader :** ${this.getRoleFormatted(guildSettings.teamLeaderRoleId)}
**Player :** ${this.getRoleFormatted(guildSettings.playerRoleId)}\n\n`;

        const competingServersCount = Object.keys(championship.guilds).length;
        const competingServers = competingServersCount === 1 ? ''
            : showServersDetails
                ? `**__Competing servers :__**\n${this.getCompetingServers(championship)}\n\n`
                : `**Number of competing servers :** ${competingServersCount}\n`;

        const teams = showTeamDetails
            ? this.getTeamsDetails(championship)
            : `**Number of teams :** ${Object.keys(championship.teams).length}\n`;

        const slotsPerTeam = `**Slots per team **(by default)** : ${championship.slotsPerTeam}**\n`
        const playerCount = `**Number of players : ${Object.keys(championship.playerToTeamMapping).length}**`;

        return `${descriptionP1}${competingServers}${teams}${slotsPerTeam}${playerCount}`;
    }

    private getCompetingServers(championship: ChampionshipsSettings): string {
        return Object.values(championship.guilds)
            .map(guild => `**${guild.name}**`)
            .join('\n');
    }

    private getTeamsDetails(championship: ChampionshipsSettings): string {
        const teamPlayerCounts = new ChampionshipUtils().getTeamsPlayerCount(championship.playerToTeamMapping);
        return `**__Teams :__** ${Object.keys(championship.teams).length}\n${Object.entries(championship.teams)
            .map(([key, teamData]) => {
                const memberCount = teamPlayerCounts[key] || 0;
                return `**${teamData.name} :** ${memberCount === 1 ? '**1** member' : `**${memberCount}** members`}`;
            })
            .join('\n')}\n\n`;
    }

    private getRoleFormatted(roleId: string): string {
        return roleId ? `<@&${roleId}>` : '*Not set*';
    }
}

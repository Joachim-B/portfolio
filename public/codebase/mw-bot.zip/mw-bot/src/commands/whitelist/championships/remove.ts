import {
    ChatInputCommandInteraction,
    SlashCommandBuilder,
} from 'discord.js'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'
import { Categories } from '../../../utils/common/sharedEnums'
import ChampionshipsData from '../../../db-objects/data/championship-data'
import ChampionshipUtils, { ChampionshipRoles } from '../../../utils/championship-utils/utils'

export default class RemoveCommand extends BaseSlashCommand {
    category = Categories.championship
    command = new SlashCommandBuilder()
        .setName('remove')
        .setDescription('Remove points to a player')
        .addUserOption(o => o
            .setName('player')
            .setDescription('The selected player')
            .setRequired(true)
        )
        .addIntegerOption(o => o
            .setName('points')
            .setDescription('The points to add')
            .setMinValue(1)
            .setRequired(true)
        )
    async execute(interaction: ChatInputCommandInteraction) {
        const utils = new ChampionshipUtils()
        await utils.throwIfChampCommandUnavailable(interaction, ChampionshipRoles.teamLeader)
        await interaction.deferReply()
        const player = interaction.options.getUser('player')
        const points = interaction.options.getInteger('points')
        const newScore = await new ChampionshipsData(interaction.guildId).substractScoreAsync(player.id, points)
        await interaction.editReply({ content: utils.getScoreUpdateFormat(player.displayName, newScore + points, newScore, '-' + points) })
    }
}
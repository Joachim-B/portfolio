import { PermissionsBitField } from 'discord.js';
import BaseSlashCommandGroup from '../../../utils/common/abstraction/baseSlashCommandGroup';
import { Categories } from '../../../utils/common/sharedEnums';

export default class ConnectCommand extends BaseSlashCommandGroup {
    constructor() {
        super(Categories.connect, __filename)
        this.command.setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    }
}
import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ConnectData, { ChannelData, HostChannel, HostStatus } from '../../../../db-objects/data/connect-data';
import { InteractionError } from '../../../../utils/common/sharedElements';

export default class ConnectHostSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('host')
        .setDescription('Host a multi-server connection')
        // .addStringOption(o => o
        //     .setName('status')
        //     .setDescription('The connection status')
        //     .addChoices(
        //         {name: 'Public', value: 'PUBLIC'},
        //         {name: 'Private', value: 'PRIVATE'}
        //     )
        // )
        .addBooleanOption(o => o
            .setName('championship-channel')
            .setDescription('Does it concern a championship ? (default:false)')
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const championshipChannel = interaction.options.getBoolean('championship-channel') ?? false
        const data = new ConnectData()
        await data.loadAsync()

        const channelId = interaction.channelId

        if (data.hostChannels[channelId]) {
            throw new InteractionError('This channel is already a hosting channel!')
        }

        data.hostChannels[channelId] = new HostChannel(HostStatus.public, championshipChannel)
        data.hostChannels[channelId].connectedChannels.push(new ChannelData(channelId, interaction.guildId))
        data.channelToHost[channelId] = channelId

        await data.saveAsync()
        await interaction.reply({content: '**This channel is now hosting a session !**\nUse `/connect join` in other servers with the following ID to join the session :'})
        await interaction.channel.send(`**ID:** ${channelId}`)
    }
}
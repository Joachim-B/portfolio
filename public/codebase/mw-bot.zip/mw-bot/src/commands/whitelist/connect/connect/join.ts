import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ConnectData, { ChannelData } from '../../../../db-objects/data/connect-data';
import { InteractionError } from '../../../../utils/common/sharedElements';

export default class ConnectJoinSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('join')
        .setDescription('Join a session')
        .addStringOption(o => o
            .setName('channel-id')
            .setDescription('The host channel ID')
            .setRequired(true)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const hostId = interaction.options.getString('channel-id')
        const channelId = interaction.channelId

        const data = new ConnectData()
        await data.loadAsync()

        if (data.channelToHost[channelId]) {
            throw new InteractionError('This channel has already joined a session!')
        }

        if (!data.hostChannels[hostId]) {
            throw new InteractionError('The ID provided is not valid!')
        }

        data.hostChannels[hostId].connectedChannels.push(new ChannelData(channelId, interaction.guildId))
        data.channelToHost[channelId] = hostId

        await data.saveAsync()
        await interaction.reply({ content: `**${interaction.guild.name}** has joined the session!`, components: [] })
    }
}
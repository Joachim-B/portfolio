import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import ConnectData from '../../../../db-objects/data/connect-data';
import { InteractionError } from '../../../../utils/common/sharedElements';

export default class ConnectQuitSubCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('quit')
        .setDescription('Quit a connected channel');
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new ConnectData()
        await data.loadAsync()

        const channelId = interaction.channelId
        if (!data.channelToHost[channelId]) {
            throw new InteractionError('This channel is not connected!')
        }

        if (data.hostChannels[channelId]) {
            for (const connectedChannelId of data.hostChannels[channelId].connectedChannels) {
                delete data.channelToHost[connectedChannelId.channelId]
            }
            delete data.hostChannels[channelId]
            await interaction.reply({ content: 'The session has ended.', components: [] })
        }
        else {
            const hostId = data.channelToHost[channelId]
            data.hostChannels[hostId].connectedChannels = data.hostChannels[hostId].connectedChannels.filter(c => c.channelId != channelId)
            delete data.channelToHost[channelId]
        }

        await data.saveAsync()
        if (!interaction.replied) {
            await interaction.reply({ content: 'The session has ended.', components: [] })
        }
    }
}
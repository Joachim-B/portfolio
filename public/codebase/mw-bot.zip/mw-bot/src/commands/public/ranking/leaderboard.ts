import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, InteractionResponse, InteractionContextType } from 'discord.js';
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand';
import { Categories } from '../../../utils/common/sharedEnums';
import StreakData, { UserData } from '../../../db-objects/data/streak-data';

const USERS_PER_PAGE = 10;

type LeaderboardEntry = {
    position: number;
    userId: string;
    user: UserData;
};

export default class LeaderboardCommand extends BaseSlashCommand {
    command = new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('View the nofap leaderboard')
        .addStringOption(o => o
            .setName('scope')
            .setDescription('Choose between server-only or global leaderboard')
            .setChoices({ name: 'Server', value: 'SERVER' }, { name: 'Global', value: 'GLOBAL' })
            .setRequired(true)
        )
        .addUserOption(o => o.setName('member').setDescription('Select the user you want to see'))
        .setContexts(InteractionContextType.Guild);

    category = Categories.ranking;

    async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const isServerOnly = interaction.options.getString('scope') !== 'GLOBAL';
        const selectedUserId = interaction.options.getUser('member')?.id ?? interaction.user.id;
        const data = new StreakData();
        await data.loadAsync();

        const leaderboard = this.generateLeaderboard(data.users, isServerOnly ? interaction.guildId : null, selectedUserId);
        if (!leaderboard.length) return this.sendEmptyLeaderboard(interaction, isServerOnly);

        const userIndex = leaderboard.findIndex(entry => entry.userId === selectedUserId);
        const userPage = userIndex !== -1 ? Math.floor(userIndex / USERS_PER_PAGE) + 1 : 1;
        const totalPages = Math.ceil(leaderboard.length / USERS_PER_PAGE);

        await this.sendLeaderboard(interaction, leaderboard, userPage, totalPages, userIndex, isServerOnly);
    }

    generateLeaderboard(users: Map<string, UserData>, guildId: string | null, authorId: string): LeaderboardEntry[] {
        const filteredUsers = Array.from(users.entries())
            .filter(([, user]) => !guildId || user.serverId === guildId)
            .filter(([, user]) => user.username)
            .map(([userId, user]) => [userId, user.getUpdatedVersion()] as [string, UserData]);

        filteredUsers.sort(([idA, userA], [idB, userB]) => userB.totalScore - userA.totalScore || (idA === authorId ? -1 : idB === authorId ? 1 : 0));

        let currentPosition = 0, previousScore: number | null = null;
        return filteredUsers.map(([userId, user], index) => {
            if (user.totalScore !== previousScore) currentPosition = index + 1;
            previousScore = user.totalScore;
            return { position: currentPosition, userId, user };
        });
    }

    async sendEmptyLeaderboard(interaction: ChatInputCommandInteraction, isServerOnly: boolean): Promise<void> {
        const embed = new EmbedBuilder()
            .setTitle(`${isServerOnly ? 'Server' : 'Global'} Leaderboard`)
            .setDescription('*No data available. Start your journey with the command `/nofap checkin`!*')
            .setColor('Blue');
        await interaction.reply({ embeds: [embed] });
    }

    async sendLeaderboard(interaction: ChatInputCommandInteraction, leaderboard: LeaderboardEntry[], page: number, totalPages: number, userIndex: number, isServerOnly: boolean): Promise<void> {
        const serverName = interaction.guild.name
        const embed = this.createLeaderboardEmbed(leaderboard, page, userIndex, isServerOnly, serverName);
        const buttonRow = this.getPaginationButtons(page, totalPages);
        const reply = await interaction.reply({ embeds: [embed], components: buttonRow ? [buttonRow] : [] });

        if (totalPages > 1) this.setupPagination(reply, leaderboard, userIndex, isServerOnly, serverName, totalPages);
    }

    createLeaderboardEmbed(leaderboard: LeaderboardEntry[], page: number, userIndex: number, isServerOnly: boolean, serverName: string): EmbedBuilder {
        const description = this.getLeaderboardPage(leaderboard, page, userIndex, isServerOnly);
        return new EmbedBuilder()
            .setTitle(isServerOnly ? `${serverName} Leaderboard` : 'Global Leaderboard 🌐')
            .setDescription(description)
            .setColor('Blue');
    }

    getLeaderboardPage(leaderboard: LeaderboardEntry[], page: number, userIndex: number, isServerOnly: boolean): string {
        const firstDisplayedIndex = (page - 1) * USERS_PER_PAGE;
        const userIsDisplayed = userIndex >= firstDisplayedIndex && userIndex < firstDisplayedIndex + USERS_PER_PAGE
        const userPageIndex = userIsDisplayed ? userIndex - firstDisplayedIndex : -1

        const pageEntries = leaderboard.slice(firstDisplayedIndex, firstDisplayedIndex + USERS_PER_PAGE);

        if (pageEntries.length === 0) {
            return '*No data available. Start your journey with the command `/nofap checkin`!*';
        }

        const result = pageEntries.map((entry, index) => {
            const { position, user } = entry;

            const inviteStatus = user.requestsMax > user.teammates.length ? '✅' : '❌';
            const endLine = isServerOnly
                ? ` - 🤝${inviteStatus}`
                : user.serverName
                    ? `\n-# ${user.serverName}`
                    : '';

            return `**${index == userPageIndex && leaderboard.length > 1 ? '⭐ ' : ''}#${position}** \`@${user.username ?? 'unknown'}\` - **${user.totalScore} exp**${endLine}`;
        }).join('\n');

        return isServerOnly
            ? `${result}\n\n-# 🤝: Accountability partners: open ✅ / closed ❌`
            : result;
    }

    getPaginationButtons(page: number, totalPages: number): ActionRowBuilder<ButtonBuilder> | null {
        if (totalPages <= 1) return null;
        return new ActionRowBuilder<ButtonBuilder>().addComponents(
            this.createButton('edge.1', '⏪︎', page === 1),
            this.createButton(`${page - 1}`, '◀️', page === 1),
            new ButtonBuilder().setCustomId('page').setLabel(`${page}/${totalPages}`).setStyle(ButtonStyle.Secondary).setDisabled(true),
            this.createButton(`${page + 1}`, '▶️', page === totalPages),
            this.createButton(`edge.${totalPages}`, '⏩', page === totalPages)
        );
    }

    createButton(id: string, label: string, disabled: boolean): ButtonBuilder {
        return new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(ButtonStyle.Primary).setDisabled(disabled);
    }

    setupPagination(reply: InteractionResponse, leaderboard: LeaderboardEntry[], userIndex: number, isServerOnly: boolean, serverName: string, totalPages: number): void {
        const collector = this.dUtils().createButtonCollector(reply, undefined, 180);
        collector.on('collect', async i => {
            const newPage = parseInt(i.customId.replace('edge.', ''));
            const embed = this.createLeaderboardEmbed(leaderboard, newPage, userIndex, isServerOnly, serverName);
            await i.message.edit({ embeds: [embed], components: [this.getPaginationButtons(newPage, totalPages)] });
            await i.deferUpdate();
        });
    }
}

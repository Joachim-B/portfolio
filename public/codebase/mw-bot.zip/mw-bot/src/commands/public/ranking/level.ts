import {
    SlashCommandBuilder,
    ChatInputCommandInteraction,
    GuildMember,
    APIEmbedField,
    Colors,
    InteractionContextType
} from 'discord.js';

import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand';
import { Categories } from '../../../utils/common/sharedEnums';
import { MWEmbedBuilder } from '../../../utils/common/sharedElements';
import StreakData, { UserData } from '../../../db-objects/data/streak-data';
import NofapCommand from '../nofap/nofap/checkin';
import ChallengeRolesData from '../../../db-objects/data/challenge-roles-data';
import ChallengeLevelData from '../../../db-objects/data/challenge-levels-data';
import SharedFunctions from '../../../utils/common/sharedFunctions';

export default class LevelCommand extends BaseSlashCommand {
    command = new SlashCommandBuilder()
        .setName('level')
        .setDescription('View your or another member\'s level')
        .addUserOption(option =>
            option.setName('member').setDescription('Member which you\'d like to view')
        )
        .setContexts(InteractionContextType.Guild);

    category = Categories.ranking;

    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const member = (interaction.options.getMember('member') ?? interaction.member) as GuildMember;

        // Fetch data in parallel for efficiency
        const [nofapField, spartanFields] = await Promise.all([
            this.getNofapLevelField(member),
            this.getSpartanChallengesFields(member)
        ]);

        // Embed 1: Nofap Progression
        const embed1 = new MWEmbedBuilder()
            .setTitle(`${member.user.globalName ?? member.user.username} (\`@${member.user.username}\`) Progression 📈`)
            .setThumbnail(member.displayAvatarURL())
            .setFields([nofapField])
            .setColor(Colors.Blue);

        if (spartanFields.length > 0) {
            // Embed 2: Spartan Challenges
            const embed2 = new MWEmbedBuilder()
                .setFields(spartanFields)
                .setColor(0x2ecc71);

            await interaction.reply({ embeds: [embed1, embed2] });
        } else {
            await interaction.reply({ embeds: [embed1] });
        }
    }

    private async getNofapLevelField(member: GuildMember): Promise<APIEmbedField> {
        const streakData = new StreakData();
        await streakData.loadAsync();

        const userData = (await streakData.loadUserAsync(member.id)) ?? new UserData().loadDefault();
        const updatedUser = userData.getUpdatedVersion()
        const progressionBar = new NofapCommand().getProgressionBar(updatedUser, true);

        // Calculate ranking position
        const rank = Array.from(streakData.users.values())
            .filter(user => user.username && user.todayScore + user.totalScore > updatedUser.totalScore)
            .length + 1;

        const currentStreak = updatedUser.currentStreak + updatedUser.adjustedDays;
        const bestStreak = updatedUser.highestStreak || currentStreak;
        const availableForInvite = updatedUser.teammates.length < updatedUser.requestsMax;

        return {
            name: '🛡️ Nofap Progression',
            value: `${progressionBar}

**⬆️ Total EXP**: ${updatedUser.totalScore}
**🏆 GLOBAL RANK**: **#${rank}**

**🔥 Streak**: ${currentStreak} day${currentStreak !== 1 ? 's' : ''} (Best Streak: ${bestStreak} day${bestStreak !== 1 ? 's' : ''})
**🤝 Accountability Partners**: ${updatedUser.teammates.length}
**📬 Invites **(\`/nofap invite\`): ${availableForInvite ? 'Open ✅' : 'Closed ❌'}`,
            inline: false
        };
    }

    private async getSpartanChallengesFields(member: GuildMember): Promise<APIEmbedField[]> {
        const guildId = member.guild.id;

        if (guildId !== process.env.MW_GUILD) {
            return [];
        }

        const [challengeData, levelData] = await Promise.all([
            new ChallengeRolesData(guildId).loadAsync(),
            new ChallengeLevelData(guildId).loadAsync()
        ]);

        // Filter roles based on challenge data
        const roles = member.roles.cache.filter(role => challengeData.challengeRoleIds.includes(role.id));
        const totalChallenges = roles.size;

        const challengeField: APIEmbedField = {
            name: '🥇 Spartan Challenges',
            value: totalChallenges > 0
                ? `${roles.sort((a, b) => b.position - a.position).map(role => `${role}`).join(' ')}\nTotal: **${totalChallenges} challenges**`
                : challengeData.level0Message,
            inline: true
        };

        const rankField: APIEmbedField = {
            name: '🏛️ Spartan Rank',
            value: this.getSpartanRankField(roles.size, levelData),
            inline: true
        };

        return [challengeField, rankField];
    }

    private getSpartanRankField(challengeCount: number, levelData: ChallengeLevelData): string {
        if (levelData.challengeLevelIds.length === 0) {
            return '*No level roles have been setup.*';
        }

        const correctLevelRoleId = new SharedFunctions().getCorrectLevelRoleId(challengeCount, levelData);
        const nextLevelRole = levelData.challengeLevelIds
            .filter(level => level.level > challengeCount)
            .sort((a, b) => a.level - b.level)[0];

        return [
            correctLevelRoleId ? `**RANK:** <@&${correctLevelRoleId}>` : 'Complete more Spartan challenges to earn a Spartan rank.',
            `**NEXT RANK:** ${nextLevelRole ? `<@&${nextLevelRole.roleId}> (${nextLevelRole.level} challenge${nextLevelRole.level !== 1 ? 's' : ''})` : '*Highest Rank Achieved!*'}`
        ].join('\n');
    }
}

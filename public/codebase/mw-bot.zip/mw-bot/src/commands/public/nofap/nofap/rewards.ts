import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, PermissionsBitField } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import { StreakRewardData } from '../../../../db-objects/data/streak-data';
import NofapRoleData from '../../../../db-objects/data/nofap-roles';
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements';

export default class NofapLevelsCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('rewards')
        .setDescription('Display nofap leveling progression')
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const rewardData = new StreakRewardData();
        const roleData = new NofapRoleData(interaction.guildId);
        await roleData.loadAsync();

        // Check that every role exists
        const unknownRoleIds: string[] = [];

        for (const role of roleData.roles) {
            if (!await this.dUtils().getRoleAsync(role.roleId, interaction.guild)) {
                unknownRoleIds.push(role.roleId);
            }
        }

        if (unknownRoleIds.length > 0) {
            roleData.roles = roleData.roles.filter(r => !unknownRoleIds.includes(r.roleId));
            await roleData.saveAsync();
        }

        const allRewards: { description: string, level: number }[] = [
            ...rewardData.rewards.map(r => ({ description: r.description, level: r.level })),
            ...roleData.roles.map(r => ({ description: `🆕 **New role unlocked**: <@&${r.roleId}>`, level: r.level }))
        ];

        // Sort rewards by level
        const sortedRewards = allRewards.sort((a, b) => a.level - b.level);

        // Format rewards into a detailed string grouped by level
        const rewardDescriptions = sortedRewards.map(r => {
            const levelHeader = `**Level ${r.level}**:`;
            return `- ${levelHeader} ${r.description}`;
        }).join('\n\n');

        // Add an admin note if the user has administrative permissions
        const memberPermissions = interaction.member.permissions as PermissionsBitField;
        const adminNote = memberPermissions.has(PermissionsBitField.Flags.Administrator)
            ? '\n\n🛠️ **Pro Tip**: Use the command `/nofap-roles add` to reward users with a role when they reach a specific level!'
            : '';

        const embedDescription = `### **Level Unlocks**:\n${rewardDescriptions}${adminNote}`;

        const embed = new MWEmbedBuilder()
            .setTitle('Nofap Leveling Progression 📈🏆')
            .setDescription(embedDescription)
            .setColor(0xf1c557);

        await embed.displayMWEmbed(interaction);
    }
}
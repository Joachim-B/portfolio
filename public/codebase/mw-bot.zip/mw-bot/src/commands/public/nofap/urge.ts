import { SlashCommandBuilder, ChatInputCommandInteraction, Colors, PermissionFlagsBits } from 'discord.js';
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand';
import { Categories } from '../../../utils/common/sharedEnums';
import UrgeData from '../../../db-objects/data/urge-data';
import { MWEmbedBuilder } from '../../../utils/common/sharedElements';

export default class SosCommand extends BaseSlashCommand {
    command = new SlashCommandBuilder()
        .setName('urge')
        .setDescription('Obtain advice when urges appear')
    category = Categories.nofap
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = await new UrgeData().loadAsync()
        const message = this.dUtils().utils.getRandomValue(data.messages) ?? { message: '*Under construction*', id: null, attachmentLink: null }

        if (message.attachmentLink && !await this.dUtils().utils.isImage(message.attachmentLink)) {
            message.attachmentLink = null
        }
        
        const showID = message.id && interaction.guildId == process.env.MW_GUILD && interaction.memberPermissions.has(PermissionFlagsBits.ManageChannels)

        const embed = new MWEmbedBuilder()
            .setDescription(message.message)
            .setFooter(showID ? { text: `ID: ${message.id}` } : null)
            .setColor(Colors.Blue)
            .setImage(message.attachmentLink)

        await embed.displayMWEmbed(interaction)
    }
}
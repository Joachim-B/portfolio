import { InteractionContextType } from 'discord.js';
import BaseSlashCommandGroup from '../../../utils/common/abstraction/baseSlashCommandGroup';
import { Categories } from '../../../utils/common/sharedEnums';

export default class StreakCommand extends BaseSlashCommandGroup {
    constructor() {
        super(Categories.nofap, __filename)
        this.command.setContexts(InteractionContextType.Guild)
    }
}
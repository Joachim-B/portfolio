import { ButtonInteraction, ChatInputCommandInteraction, Client, Colors, GuildMember, InteractionEditReplyOptions, MessageFlags, SlashCommandSubcommandBuilder } from 'discord.js';
import { Categories } from '../../../../utils/common/sharedEnums';
import StreakData, { UserData, StreakRewardData, RewardKeys, CheckInResult } from '../../../../db-objects/data/streak-data';
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements';
import QuoteCommand from '../../../mw/misc/quote';
import Utils from '../../../../utils/utils';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import NofapRoleData from '../../../../db-objects/data/nofap-roles';
import StreakMessageData, { MessageData, MessageType } from '../../../../db-objects/data/streak-messages';

const MAX_SCORE = 500
const TWENTY_HOURS = 20 * 60 * 60 * 1000
const FORTY_EIGHT_HOURS = 48 * 60 * 60 * 1000
const TWELVE_HOURS = 12 * 60 * 60 * 1000

export default class NofapCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('checkin')
        .setDescription('Daily nofap check-in')
        .addStringOption(o => o
            .setName('no-porn')
            .setDescription('No porn. Only counts if you chose to start or keep watching.')
            .addChoices(
                { name: '✅', value: 'TRUE' },
                { name: '❌', value: 'FALSE' }
            )
            .setRequired(true)
        )
        .addStringOption(o => o
            .setName('no-edging')
            .setDescription('No edging (Getting close to climax)')
            .addChoices(
                { name: '✅', value: 'TRUE' },
                { name: '❌', value: 'FALSE' }
            )
            .setRequired(true)
        )
        .addStringOption(o => o
            .setName('no-nut')
            .setDescription('No nut / no orgasm. Wet dreams don\'t count!')
            .addChoices(
                { name: '✅', value: 'TRUE' },
                { name: '❌', value: 'FALSE' }
            )
            .setRequired(true)
        )
        .addBooleanOption(o => o
            .setName('private')
            .setDescription('...')
        )
    category = Categories.nofap
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const userId = interaction.user.id
        let userData = await this.loadUserData(userId, interaction)
        const now = Date.now()
        const showPrivate = interaction.options.getBoolean('private') ?? false

        const newResult = this.extractCheckInResult(interaction);
        const isCheckInUpdate = this.isCooldownActive(userData.lastCheck, now);

        let updateMessage: ButtonInteraction | null = null;
        if (isCheckInUpdate) {
            updateMessage = await this.handleCheckInUpdateConfirm(interaction, userData, newResult, now, showPrivate);
            if (!updateMessage) return;
        }

        await this.deferResponse(interaction, updateMessage, showPrivate);

        if (!isCheckInUpdate) {
            userData = userData.getUpdatedVersion()
            userData.lastCheck = now
        }
        userData.lastScoreResult = newResult

        const embedContent = await this.buildEmbedContent(userData, interaction, isCheckInUpdate);

        if (updateMessage) {
            await updateMessage.editReply(embedContent)
        }
        else {
            await interaction.editReply(embedContent)
        }
    }

    getProgressionBar(updatedUser: UserData, breakLine: boolean = false): string {
        const xpLeft = updatedUser.getExpBeforeNextLevel()
        const totalExpForLevel = updatedUser.getNextLevelExp(updatedUser.level);
        const progressPercent = (xpLeft / totalExpForLevel) * 100;
        const filledSquares = Math.round((xpLeft / totalExpForLevel) * 10);  // 10 squares in total
        const emptySquares = 10 - filledSquares;

        const squareEmoji = this.getLevelEmoji(updatedUser.level)
        const progressionBar = squareEmoji.repeat(filledSquares) + '⬜'.repeat(emptySquares);

        return `**[ LEVEL ${updatedUser.level} ]**${breakLine ? '\n' : ' '}${progressionBar}\n**EXP: ${xpLeft}/${totalExpForLevel}** *(${progressPercent.toFixed(0)}%)*`;
    }

    private async loadUserData(userId: string, interaction: ChatInputCommandInteraction): Promise<UserData> {
        const data = new StreakData();
        const userData = await data.loadUserAsync(userId) ?? new UserData().loadDefault();
        userData.username = interaction.user.username;
        userData.serverName = interaction.guild.name;
        userData.serverId = interaction.guildId;
        return userData;
    }

    private extractCheckInResult(interaction: ChatInputCommandInteraction): CheckInResult {
        return {
            noPorn: interaction.options.getString('no-porn') === 'TRUE',
            noEdge: interaction.options.getString('no-edging') === 'TRUE',
            noNut: interaction.options.getString('no-nut') === 'TRUE'
        };
    }

    private isCooldownActive(lastCheck: number | undefined, now: number): boolean {
        return lastCheck !== undefined && (lastCheck + TWENTY_HOURS > now);
    }

    private async handleCheckInUpdateConfirm(interaction: ChatInputCommandInteraction, userData: UserData, newResult: CheckInResult, now: number, showPrivate: boolean): Promise<ButtonInteraction | null> {
        const checkCooldownEnd = userData.lastCheck + TWENTY_HOURS;
        const { confirmationMessage, confirmed } = await this.dUtils().displayConfirmationMessage(interaction,
            `**You are about to update the check-in from <t:${Math.floor(userData.lastCheck / 1000)}:R>** (status: ${this.getNofapEmojis(userData.lastScoreResult, false)}).\n\n` +
            `The data will be replaced with: ${this.getNofapEmojis(newResult, false)}.\nNext check-in unlocks **<t:${Math.floor(checkCooldownEnd / 1000)}:R>**.\n\n**Proceed?**`,
            showPrivate, true);

        if (!confirmed) {
            return null;
        }

        return confirmationMessage;
    }

    private async deferResponse(interaction: ChatInputCommandInteraction, updateMessage: ButtonInteraction | null, showPrivate: boolean): Promise<void> {
        if (updateMessage) {
            await updateMessage.deferUpdate();
        } else {
            await interaction.deferReply({ flags: showPrivate ? MessageFlags.Ephemeral : undefined });
        }
    }

    private async buildEmbedContent(userData: UserData, interaction: ChatInputCommandInteraction, isCheckInUpdate: boolean): Promise<InteractionEditReplyOptions> {
        const userId = interaction.user.id
        const embedTitle = this.getEmbedTitle(isCheckInUpdate);

        const baseScoreData = this.getBaseScoreLine(userData);
        const streakBonusData = this.getStreakBonusData(userData);
        const weekPointsData = this.getWeekPointsLine(userData);
        const teammatesData = await this.getTeammatesDataAndUpdateTeammatesAsync(userId, userData);

        userData.todayScore = this.calculateFinalScore(
            baseScoreData.baseScore,
            weekPointsData.weekPointsBonus,
            streakBonusData.percentBonus,
            teammatesData.teamMultiplier
        );
        await new StreakData().saveUserAsync(userId, userData)
        const updatedUser = userData.getUpdatedVersion();

        const nonutStreakLine = this.getNonutStreakLine(updatedUser);
        const totalLine = this.getTotalScoreLine(userData, updatedUser, teammatesData.teamMultiplier);
        const levelUpLine = this.getLevelUpLine(userData, updatedUser);
        const progressBarLine = this.getProgressBarLine(updatedUser);

        const nofapRoleData = await this.getNofapRoleData(interaction);
        const rolesAddedIds = await this.addNofapRoles(interaction.member as GuildMember, updatedUser, nofapRoleData);
        const rewardsLine = this.getLevelRewardLine(userData, updatedUser, rolesAddedIds, nofapRoleData);

        const mainEmbedDescription = [baseScoreData.baseScoreLine, weekPointsData.weekPointsLine, streakBonusData.streakBonusLine, nonutStreakLine,
        teammatesData.teammatesLine, totalLine, levelUpLine,
            progressBarLine, rewardsLine].join('')

        const activeUsersCount = await this.getActiveUsersCount();
        const seeYouLine = this.getSeeYouLine(userData, activeUsersCount);

        const mainEmbed = this.createMainEmbed(embedTitle, mainEmbedDescription, seeYouLine, isCheckInUpdate);

        const embedRow = [mainEmbed];

        // Team Requests Section
        if (userData.requests.length > 0 && userData.teammates.length < userData.requestsMax) {
            const teamRequestEmbed = this.createTeamRequestEmbed(userData);
            embedRow.push(teamRequestEmbed);
        }

        // Quote / Streak / Relapse Message
        const additionnalEmbed = await this.getAdditionnalEmbed(updatedUser, interaction.client, isCheckInUpdate);
        if (additionnalEmbed) {
            embedRow.push(additionnalEmbed);
        }

        const cooldownInfo = this.getCooldownInfo(userData, isCheckInUpdate);

        return { embeds: embedRow, content: cooldownInfo, components: [] };
    }

    private getEmbedTitle(isCheckInUpdate: boolean): string {
        return isCheckInUpdate ? 'Nofap Check-In Update 📅🔁' : 'Daily Nofap Check-In 📅✅';
    }

    private getBaseScoreLine(userData: UserData): { baseScoreLine: string, baseScore: number } {
        const baseScore = this.calculateBaseScore(userData.lastScoreResult);
        const showCaption = userData.level === 1;
        return {
            baseScoreLine: `${this.getNofapEmojis(userData.lastScoreResult, showCaption)} ⮕ +${baseScore}`,
            baseScore
        }
    }

    private getStreakBonusData(userData: UserData): { streakBonusLine: string, percentBonus: number } {
        const isPerfectDay = Object.values(userData.lastScoreResult).every(v => v);
        if (!isPerfectDay) {
            return { streakBonusLine: '', percentBonus: 0 }
        }

        const perfectStreak = userData.perfectStreak + 1;
        const percentBonus = this.getStreakPercent(perfectStreak);
        const bonusText = percentBonus > 0 ? `** ⮕ Bonus +${percentBonus}% **` : ' ';

        return {
            streakBonusLine: `\n**✨PERFECT! [ ${this.getDayCountFormat(perfectStreak)}${bonusText}]**`,
            percentBonus
        };
    }

    private getWeekPointsLine(userData: UserData): { weekPointsLine: string, weekPointsBonus: number } {
        const weekPointsBonus = userData.weekPoints * 50;
        return {
            weekPointsLine: userData.weekPoints === 0 ? '' : `\nPerfect weeks : **${userData.weekPoints}** ⮕ Bonus +${weekPointsBonus}`,
            weekPointsBonus
        }
    }

    private getTotalScoreLine(userData: UserData, updatedUser: UserData, teamMultiplier: number): string {
        let totalLine = '';
        const weekPointsBonus = userData.weekPoints * 50;
        const percentBonus = this.getStreakPercent(updatedUser.perfectStreak);
        const hasBonus = !(weekPointsBonus === 0 && percentBonus === 0 && teamMultiplier === 1);

        if (hasBonus) {
            totalLine = `\n\n**Total score : ${userData.todayScore}**`;

            if (teamMultiplier !== 1) {
                const streakBonusScore = this.calculateStreakBonusScore(
                    this.calculateBaseScore(userData.lastScoreResult),
                    weekPointsBonus,
                    percentBonus
                );
                totalLine += ` *(${streakBonusScore} × ${teamMultiplier})*`;
            }
        }
        return totalLine;
    }

    private getLevelUpLine(userData: UserData, updatedUser: UserData): string {
        return updatedUser.level > userData.level ? '\n\n✨ **LEVEL UP!** ✨' : '\n';
    }

    private getNonutStreakLine(updatedUser: UserData): string {
        return updatedUser.currentStreak !== 0 && (updatedUser.adjustedDays !== 0 || updatedUser.currentStreak !== updatedUser.perfectStreak)
            ? `\n**🚫🥜 No-nut ⮕ DAY ${updatedUser.currentStreak + updatedUser.adjustedDays}**`
            : '';
    }

    private getProgressBarLine(updatedUser: UserData): string {
        return `\n${this.getProgressionBar(updatedUser)}`;
    }

    private async getNofapRoleData(interaction: ChatInputCommandInteraction): Promise<NofapRoleData> {
        const nofapRoleData = new NofapRoleData(interaction.guildId);
        await nofapRoleData.loadAsync();
        return nofapRoleData;
    }

    private async getAdditionnalEmbed(updatedVersion: UserData, client: Client, isCheckInUpdate: boolean): Promise<MWEmbedBuilder | null> {
        return await this.getStreakMessageEmbedIfEligible(updatedVersion) ?? await this.getQuoteEmbedIfEligible(updatedVersion, client, isCheckInUpdate)
    }

    private async getStreakMessageEmbedIfEligible(updatedVersion: UserData): Promise<MWEmbedBuilder | null> {
        const data = await new StreakMessageData().loadAsync()
        const isPerfectDay = Object.values(updatedVersion.lastScoreResult).every(v => v);
        if (isPerfectDay) {
            const noNutDayCount = updatedVersion.currentStreak + updatedVersion.adjustedDays
            return this.buildStreakMessageEmbed(data, m => m.milestone == noNutDayCount)
        }

        if (!updatedVersion.lastScoreResult.noNut) {
            return this.buildStreakMessageEmbed(data, m => m.type == MessageType.Relapse)
        }

        return this.buildStreakMessageEmbed(data, m => m.type == MessageType.Edging)
    }

    private buildStreakMessageEmbed(data: StreakMessageData, filter: (m: MessageData) => boolean): MWEmbedBuilder {
        const streakMessages = data.messageData.filter(filter)
        if (streakMessages.length == 0) {
            return null
        }

        const selectedMessage = this.dUtils().utils.getRandomValue(streakMessages)
        const message = selectedMessage.message

        const { title, description } = message.includes('|') 
        ? { title: message.split('|')[0], description: message.split('|')[1] || '*No description*' } 
        : { title: null, description: message };

        const embed = new MWEmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor(Colors.Blue)

        return embed
    }

    private async getQuoteEmbedIfEligible(updatedVersion: UserData, client: Client, isCheckInUpdate: boolean): Promise<MWEmbedBuilder | null> {
        if (isCheckInUpdate) {
            return null
        }

        const quoteLevel = new StreakRewardData().rewards.find(r => r.rewardKey === RewardKeys.quotes)?.level;
        if (updatedVersion.level < quoteLevel) {
            return null
        }

        try {
            const mwGuild = client.guilds.cache.get(process.env.MW_GUILD)
            if (!mwGuild) {
                return null
            }

            return await new QuoteCommand().getQuoteEmbed(mwGuild, 150, 150)
        }
        catch { /* No quote embed */ }
    }

    private async getActiveUsersCount(): Promise<number> {
        const data = new StreakData();
        await data.loadAsync();
        return Array.from(data.users).filter(([, u]) => u.lastCheck + FORTY_EIGHT_HOURS > Date.now()).length;
    }

    private getSeeYouLine(userData: UserData, activeUsersCount: number): string {
        return `• Active streaks : ${activeUsersCount} •`;
    }

    private createMainEmbed(embedTitle: string, mainEmbedDescription: string, seeYouLine: string, isCheckInUpdate: boolean): MWEmbedBuilder {
        return new MWEmbedBuilder()
            .setTitle(embedTitle)
            .setDescription(mainEmbedDescription)
            .setColor(isCheckInUpdate ? 0xFF0000 : 0xf1c557)
            .setFooter({ text: seeYouLine });
    }

    private createTeamRequestEmbed(userData: UserData): MWEmbedBuilder {
        const message = `You have received **${userData.requests.length}** team request${userData.requests.length === 1 ? '' : 's'}!\nUse the command \`/nofap requests\` to review them.`;
        return new MWEmbedBuilder()
            .setDescription(message)
            .setColor(Colors.Green);
    }

    private getCooldownInfo(userData: UserData, isCheckInUpdate: boolean): string {
        return isCheckInUpdate ? `New check-in available **<t:${Math.floor((userData.lastCheck + TWENTY_HOURS) / 1000)}:R>**. 🕑` : '';
    }

    private getNofapEmojis(result: CheckInResult, caption: boolean) {
        const { noPorn, noEdge, noNut } = result
        if (caption) {
            return `No porn: ${noPorn ? '✅' : '❌'} No edging: ${noEdge ? '✅' : '❌'} No nut: ${noNut ? '✅' : '❌'}`
        }
        return `${noPorn ? '✅' : '❌'}${noEdge ? '✅' : '❌'}${noNut ? '✅' : '❌'}`
    }

    private calculateBaseScore(result: CheckInResult): number {
        const falseCount = [result.noPorn, result.noEdge, result.noNut].filter(value => !value).length;

        return falseCount === 3 ? 50 :
            falseCount === 2 ? 100 :
                falseCount === 1 ? 200 :
                    MAX_SCORE;
    }

    private getStreakPercent(perfectStreak: number): number {
        if (perfectStreak < 2) {
            return 0
        }

        return (perfectStreak - 1) * 10
    }

    private getDayCountFormat(currentStreak: number) {
        const day = 'Day ' + currentStreak
        if (currentStreak == 5) {
            return `${day}📈`
        }
        if (currentStreak % 30 == 0) {
            return `👑${day}👑`
        }
        if (currentStreak % 7 == 0) {
            return `${day}🎉`
        }
        if (currentStreak % 10 == 0) {
            return `🏆${day}🏆`
        }
        if (currentStreak > 10 && new Utils().randomNumber(0, 12) == 0) {
            return `${day}📈`
        }
        return `${day}🔥`
    }

    private async getTeammatesDataAndUpdateTeammatesAsync(userId: string, userData: UserData): Promise<{ teammatesLine: string; teamMultiplier: number }> {
        if (userData.teammates.length === 0) {
            return { teammatesLine: '', teamMultiplier: 1 };
        }

        const data = new StreakData()
        await data.saveUserAsync(userId, userData)
        await data.loadAsync();

        const teamMultiplier = this.getTeamMultiplier(userData, data.users);
        const teammateScores: string[] = [];

        userData.teammates = userData.teammates.filter(teammateId => {
            const teammate = data.users.get(teammateId);
            if (!teammate) return false;

            const teammateStatus = this.getTeammateStatus(teammateId, teammate, userData.lastCheck);
            teammateScores.push(teammateStatus.scoreText);

            if (teammateStatus.checkedToday) {
                teammate.todayScore = this.getTodayScore(teammate, data.users);
                data.saveUserAsync(teammateId, teammate);
            }

            return true;
        });

        const teammatesLine = teammateScores.length
            ? `\n### Accountability partners 🤝 :\n${teammateScores.join('\n')}${teamMultiplier === 1 ? '' : `\nScore multiplier: *×${teamMultiplier}*`}`
            : '';

        return { teammatesLine, teamMultiplier };
    }

    private getTeamMultiplier(user: UserData, database: Map<string, UserData>): number {
        if (user.teammates.length === 0) return 1;

        let multiplier = 1;
        for (const teammateId of user.teammates) {
            const teammate = database.get(teammateId);
            if (!teammate?.lastCheck) continue;
            if (!this.isCheckWithinRange(teammate.lastCheck, user.lastCheck)) continue;

            multiplier *= this.calculateTeammateBonus(teammate.lastScoreResult);
        }
        return parseFloat(multiplier.toFixed(2));
    }

    private getTeammateStatus(userId: string, teammate: UserData, userLastCheck: number) {
        if (!teammate.lastCheck) {
            return { scoreText: `- <@${userId}> : *pending*`, checkedToday: false };
        }

        if (!this.isCheckWithinRange(teammate.lastCheck, userLastCheck)) {
            return {
                scoreText: `- <@${userId}> : *pending* (**Last:** ${this.getNofapEmojis(teammate.lastScoreResult, false)})`,
                checkedToday: false
            };
        }

        const bonus = this.calculateTeammateBonus(teammate.lastScoreResult);
        return {
            scoreText: `- <@${userId}> : ${this.getNofapEmojis(teammate.lastScoreResult, false)} *(${this.formatPercentageChange(bonus)})*`,
            checkedToday: true
        };
    }

    private isCheckWithinRange(teammateLastCheck: number, userLastCheck: number): boolean {
        return teammateLastCheck > userLastCheck - TWELVE_HOURS && teammateLastCheck < userLastCheck + TWELVE_HOURS;
    }

    private getTodayScore(user: UserData, database: Map<string, UserData>) {
        const baseScore = this.calculateBaseScore(user.lastScoreResult)
        const weekPoints = user.weekPoints * 50
        const perfectScore = user.lastScoreResult.noPorn && user.lastScoreResult.noEdge && user.lastScoreResult.noNut
        const currentStreak = perfectScore ? user.currentStreak + 1 : 0
        const streakPercent = this.getStreakPercent(currentStreak)
        const teamMultiplier = this.getTeamMultiplier(user, database)

        return this.calculateFinalScore(baseScore, weekPoints, streakPercent, teamMultiplier)
    }

    private calculateFinalScore(baseScore: number, weekPoints: number, streakPercent: number, teamMultiplier: number) {
        return Math.round(this.calculateStreakBonusScore(baseScore, weekPoints, streakPercent) * teamMultiplier)
    }

    private calculateStreakBonusScore(baseScore: number, weekPoints: number, streakPercent: number) {
        baseScore += weekPoints
        return baseScore + baseScore * streakPercent / 100
    }

    private calculateTeammateBonus(result: CheckInResult): number {
        const falseCount = [result.noPorn, result.noEdge, result.noNut].filter(value => !value).length;

        return falseCount === 3 ? 0.2 :
            falseCount === 2 ? 0.4 :
                falseCount === 1 ? 0.8 :
                    1.3;
    }

    private formatPercentageChange(multiplier: number): string {
        const percentageChange = (multiplier - 1) * 100;
        return `${percentageChange >= 0 ? '+' : ''}${percentageChange.toFixed(0)}%`;
    }

    private getLevelEmoji(level: number) {
        const modulo = level % 6
        switch (modulo) {
            case 1:
                return '🟦'
            case 2:
                return '🟩'
            case 3:
                return '🟨'
            case 4:
                return '🟧'
            case 5:
                return '🟥'
            default:
                return '🟪'
        }
    }

    private async addNofapRoles(member: GuildMember, updatedUser: UserData, nofapRoleData: NofapRoleData): Promise<string[]> {
        const lackingRolesIds = nofapRoleData.roles
            .filter(r => r.level <= updatedUser.level && !member.roles.cache.has(r.roleId))
            .map(r => r.roleId);

        const addedRolesId = await Promise.all(
            lackingRolesIds.map(async roleId => {
                try {
                    const role = await this.dUtils().getRoleAsync(roleId, member.guild, true);
                    await member.roles.add(role);
                    return roleId
                } catch {
                    return null
                }
            })
        );

        return addedRolesId.filter(roleId => roleId != null);
    }

    private getLevelRewardLine(oldUser: UserData, updatedUser: UserData, nofapRolesAdded: string[], nofapRoleData: NofapRoleData): string {
        const { level: oldLevel } = oldUser;
        const { level: userLevel, perfectStreak, weekPoints } = updatedUser;
        const rewardData = new StreakRewardData();
        const rewards: string[] = [];

        // Add level-based rewards
        rewards.push(
            ...rewardData.rewards
                .filter(reward => oldLevel < reward.level && userLevel >= reward.level)
                .map(reward => `**Unlocked:** ${reward.description}`)
        );

        // Add new role rewards
        rewards.push(
            ...nofapRolesAdded.map(roleId => `**🆕 New role unlocked**: <@&${roleId}>`)
        );

        // Add perfect streak bonus if applicable
        if (perfectStreak > 0 && perfectStreak % 7 === 0) {
            rewards.push(
                `**Congrats!** You have reached **${perfectStreak}** days with a perfect score! 🎉\n` +
                `- **Perfect weeks: +1** (Bonus tomorrow) (Total: **${weekPoints}**)`
            );
        }

        // Prepare the next reward hint
        const nextRewardLevel = this.getNextRewardLevel(userLevel, rewardData, nofapRoleData)
        if (nextRewardLevel) {
            rewards.push(`\n*Next reward 🏅:* Level ${nextRewardLevel}`);
        }

        // Construct the final output
        const rewardTitle = rewards.length > 0 ? '\n### Rewards :\n' : '';
        return rewardTitle + rewards.join('\n');
    }

    private getNextRewardLevel(userLevel: number, rewardData: StreakRewardData, nofapRoleData: NofapRoleData): number | undefined {
        const allRewardLevels = [
            ...rewardData.rewards.map(r => r.level),
            ...nofapRoleData.roles.map(r => r.level),
        ].filter(level => level > userLevel);

        return allRewardLevels.length == 0 ? undefined
            : Math.min(...allRewardLevels)
    }
}
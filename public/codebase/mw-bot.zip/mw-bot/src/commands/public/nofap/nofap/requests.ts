import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, ButtonBuilder, ButtonStyle, ButtonInteraction } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import StreakData, { StreakRewardData, RewardKeys, UserData } from '../../../../db-objects/data/streak-data';
import { MWEmbedBuilder } from '../../../../utils/common/sharedElements';

export default class StreakRequestsCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('requests')
        .setDescription('View accountability partner requests sent to you')
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new StreakData()
        const levelRequired = new StreakRewardData().rewards.find(r => r.rewardKey == RewardKeys.partners_2).level
        await data.loadAsync()
        const userData = data.users.get(interaction.user.id)
        const updatedUser = userData?.getUpdatedVersion()

        if (!userData || updatedUser.level < levelRequired) {
            await interaction.reply({ content: 'Reach `Level 2` using `/nofap checkin` to access this command!' })
            return
        }

        userData.requests = userData.requests.filter(userId => {
            const requester = data.users.get(userId)?.getUpdatedVersion()
            return requester && requester.teammates.length < requester.requestsMax
        })

        await data.saveUserAsync(interaction.user.id, userData)

        const pendingRequestCount = userData.requests.length
        const teamSlotsAvailable = updatedUser.requestsMax - userData.teammates.length

        if (pendingRequestCount == 0) {
            await interaction.reply({ content: `You have received **0** team requests.\nYou can join with **${teamSlotsAvailable}** additional accountability partners.\nYou currently have **${userData.teammates.length}** accountability partners.` })
            return
        }

        const pendingTeammates = userData.requests.map(userId => `- <@${userId}>`).join('\n')

        if (userData.teammates.length >= updatedUser.requestsMax) {
            const embed = new MWEmbedBuilder()
                .setTitle(`You have ${pendingRequestCount} pending request${pendingRequestCount == 1 ? '' : 's'} !`)
                .setDescription(pendingTeammates + '\nYou have reached the maximum capacity of accountability partners. Level up to team up with more people !')
            await interaction.reply({ embeds: [embed] })
            return
        }

        const embed = new MWEmbedBuilder()
            .setTitle(`You have ${pendingRequestCount} pending request${pendingRequestCount == 1 ? '' : 's'} !`)
            .setDescription(pendingTeammates + `\nYou can join with **${teamSlotsAvailable}** additional accountability partners.`)

        const buttonRow = this.dUtils().getButtonRowBuilder(
            new ButtonBuilder()
                .setCustomId('review')
                .setLabel('Review requests !')
                .setStyle(ButtonStyle.Success)
        )

        const reply = await interaction.reply({ embeds: [embed], components: [buttonRow] })
        const collector = this.dUtils().createButtonCollector(reply, interaction.user.id, 60)

        collector.on('collect', async i => {
            await this.reviewRequests(i, data)
        })
    }

    async reviewRequests(interaction: ButtonInteraction, data: StreakData) {
        const userData = await data.loadUserAsync(interaction.user.id)
        const updatedUser = userData?.getUpdatedVersion()

        if (interaction.customId != 'review') {
            const [teammateId, result] = interaction.customId.split('.')
            userData.requests = userData.requests.filter(u => u != teammateId)
            if (result == 'accept') {
                userData.teammates.push(teammateId)
                const teammate = await data.loadUserAsync(teammateId)
                teammate.teammates.push(interaction.user.id)
                await data.saveUserAsync(teammateId, teammate)
            }
            await data.saveUserAsync(interaction.user.id, userData)
        }

        const nextReviewId = await this.getNextReviewId(userData, data)
        if (!nextReviewId) {
            await interaction.message.edit({ embeds: [], components: [], content: 'All pending requests have been reviewed.' })
            await interaction.deferUpdate()
            return
        }
        if (userData.teammates.length >= updatedUser.requestsMax) {
            await interaction.message.edit({ embeds: [], components: [], content: 'You have reached the limit of partners.' })
            await interaction.deferUpdate()
            return
        }

        const embed = new MWEmbedBuilder()
            .setDescription(`Pending request from : <@${nextReviewId}>`)

        const accept = new ButtonBuilder()
            .setCustomId(`${nextReviewId}.accept`)
            .setLabel('Accept')
            .setStyle(ButtonStyle.Success)

        const deny = new ButtonBuilder()
            .setCustomId(`${nextReviewId}.deny`)
            .setLabel('Deny')
            .setStyle(ButtonStyle.Danger)

        const buttonRow = this.dUtils().getButtonRowBuilder(accept, deny)

        await interaction.message.edit({ embeds: [embed], components: [buttonRow] })
        await interaction.deferUpdate()
    }

    async getNextReviewId(userData: UserData, data: StreakData): Promise<string> {
        return userData.requests.filter(userId => {
            const requester = data.users.get(userId)
            const updatedVersion = requester?.getUpdatedVersion()
            return requester && updatedVersion && requester.teammates.length < updatedVersion.requestsMax
        })[0]
    }
}
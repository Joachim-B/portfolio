import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, MessageFlags } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import StreakData, { StreakRewardData, RewardKeys } from '../../../../db-objects/data/streak-data';

export default class StreakSendRequestCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('invite')
        .setDescription('Invite a user to become an accountability partner')
        .addUserOption(o => o
            .setName('user')
            .setDescription('The selected user')
            .setRequired(true)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new StreakData()
        const levelRequired = new StreakRewardData().rewards.find(r => r.rewardKey == RewardKeys.partners_2).level
        const user = await data.loadUserAsync(interaction.user.id)
        const updatedUser = user?.getUpdatedVersion()

        if (!user || updatedUser.level < levelRequired) {
            await interaction.reply({ content: 'Reach `Level 2` using `/nofap checkin` to access this command!' })
            return
        }

        if (user.teammates.length == updatedUser.requestsMax) {
            await interaction.reply({ content: `You have reached the maximum capacity of accountability partners ! (Value : **${updatedUser.requestsMax}**)`, flags: MessageFlags.Ephemeral })
            return
        }

        const teammate = interaction.options.getUser('user')
        if (teammate.id == interaction.user.id) {
            await interaction.reply({ content: 'You cannot send a team invite to yourself!', flags: MessageFlags.Ephemeral })
            return
        }

        const teammateData = await data.loadUserAsync(teammate.id)
        const updatedTeammate = teammateData?.getUpdatedVersion()

        if (!teammateData || updatedTeammate.level < levelRequired) {
            await interaction.reply({ content: 'This user doesn\'t have the required level to have accountability partners.', flags: MessageFlags.Ephemeral })
            return
        }

        if (teammateData.teammates.length == updatedTeammate.requestsMax) {
            await interaction.reply({ content: `This user has reached the maximum capacity of accountability partners ! (Value : **${updatedTeammate.requestsMax}**)`, flags: MessageFlags.Ephemeral })
            return
        }

        if (user.teammates.includes(teammate.id)) {
            await interaction.reply({ content: `You already are in the same team as <@${teammate.id}>.`, flags: MessageFlags.Ephemeral })
            return
        }

        if (teammateData.requests.includes(interaction.user.id)) {
            await interaction.reply({ content: 'A team request have already been sent to this user.', flags: MessageFlags.Ephemeral })
            return
        }

        teammateData.requests.push(interaction.user.id)
        await data.saveUserAsync(teammate.id, teammateData)
        await interaction.reply({content: `A team request have been sent to ${teammate} !`, flags: MessageFlags.Ephemeral})
    }

}
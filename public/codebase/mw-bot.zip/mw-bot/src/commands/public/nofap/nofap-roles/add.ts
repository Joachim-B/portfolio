import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, MessageFlags } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import NofapRoleData from '../../../../db-objects/data/nofap-roles';

export default class NofapAddRoleCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Add a role reward for reaching a certain level')
        .addRoleOption(o => o
            .setName('role')
            .setDescription('The role to add to the player')
            .setRequired(true)
        )
        .addIntegerOption(o => o
            .setName('level')
            .setDescription('The level at which the role is rewarded')
            .setMinValue(1)
            .setRequired(true)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const role = interaction.options.getRole('role')
        const level = interaction.options.getInteger('level')
        const data = new NofapRoleData(interaction.guildId)
        await data.loadAsync()

        data.roles = data.roles.filter(r => r.roleId != role.id)
        data.roles.push({roleId: role.id, level})

        await data.saveAsync()
        await interaction.reply({content: `${role} has been added to the nofap roles.\nThe role will be granted whenever a player checks in and possess the required level.`, flags: MessageFlags.Ephemeral})
    }
}
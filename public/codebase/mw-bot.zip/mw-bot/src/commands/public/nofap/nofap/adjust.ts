import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, MessageFlags } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import StreakData from '../../../../db-objects/data/streak-data';
import { InteractionError } from '../../../../utils/common/sharedElements';

const FORTY_EIGHT_HOURS = 48 * 60 * 60 * 1000

export default class NofapAdjust extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('adjust')
        .setDescription('Adjust your streak')
        .addIntegerOption(o => o
            .setName('days')
            .setDescription('You current streak')
            .setMinValue(0)
            .setRequired(true)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new StreakData()
        const userId = interaction.user.id
        const userData = await data.loadUserAsync(userId)
        if (!userData) {
            throw new InteractionError('Type `/nofap checkin` first!')
        }

        const days = interaction.options.getInteger('days')
        if (days == 0) {
            await interaction.reply({ content: 'Please use the command `/nofap checkin` to update your streak back to zero.', flags: MessageFlags.Ephemeral })
            return
        }
        if (!userData.lastScoreResult.noNut && userData.lastCheck + FORTY_EIGHT_HOURS > Date.now()) {
            await interaction.reply({ content: 'You cannot adjust the days if the last check-in is a relapse.', flags: MessageFlags.Ephemeral })
            return
        }
        const updatedUser = userData.getUpdatedVersion()

        if (days < updatedUser.perfectStreak) {
            await interaction.reply({ content: 'You cannot choose a number lower than your current perfect streak.', flags: MessageFlags.Ephemeral })
            return
        }
        userData.adjustedDays = Math.max(days - updatedUser.currentStreak, 0)

        await data.saveUserAsync(userId, userData)
        await interaction.reply(`Your streak is now set to **${days}** day${days == 1 ? '' : 's'}!`)
    }

}
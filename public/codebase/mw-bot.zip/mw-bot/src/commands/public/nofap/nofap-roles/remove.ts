import { SlashCommandSubcommandBuilder, ChatInputCommandInteraction, MessageFlags } from 'discord.js';
import BaseSlashSubCommand from '../../../../utils/common/abstraction/baseSlashSubCommand';
import NofapRoleData from '../../../../db-objects/data/nofap-roles';
import { InteractionError } from '../../../../utils/common/sharedElements';

export default class NofapAddRoleCommand extends BaseSlashSubCommand {
    command = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Remove a nofap role')
        .addRoleOption(o => o
            .setName('role')
            .setDescription('The role to remove')
            .setRequired(true)
        )
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const role = interaction.options.getRole('role')
        const data = new NofapRoleData(interaction.guildId)
        await data.loadAsync()

        if (!data.roles.some(r => r.roleId == role.id)) {
            throw new InteractionError('The provided role doesn\'t match any existing nofap role!')
        }

        data.roles = data.roles.filter(r => r.roleId != role.id)

        await data.saveAsync()
        await interaction.reply({content: `${role} has been removed successfully from the nofap roles.`, flags: MessageFlags.Ephemeral})
    }
}
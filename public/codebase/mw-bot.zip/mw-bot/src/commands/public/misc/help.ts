import { SlashCommandBuilder, ChatInputCommandInteraction, CacheType, Collection, ApplicationCommandOptionType, ApplicationCommand, PermissionsBitField, GuildMemberRoleManager, ApplicationCommandSubGroup, InteractionContextType } from 'discord.js'
import CacheManager from '../../../utils/cache-manager'
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand'
import { Categories } from '../../../utils/common/sharedEnums'
import ChampionshipsData, { GuildSettings } from '../../../db-objects/data/championship-data'
import { MWEmbedBuilder } from '../../../utils/common/sharedElements'

export default class HelpCommand extends BaseSlashCommand {
    category = Categories.help
    command = new SlashCommandBuilder()
        .setName('help')
        .setDescription('Show all the commands available')
        .setContexts(InteractionContextType.Guild)
    public async execute(interaction: ChatInputCommandInteraction<CacheType>): Promise<void> {
        const availableCommands = await this.getAvailableCommands(interaction)
        const categoryList = this.createCommandCategories(availableCommands)

        let message = categoryList.map(c1 => `## ${c1.category} :\n${c1.commands.map(c2 => `\`/${c2.name}\` : ${c2.description}`).join('\n')}`).join('\n')
        if (message == '') {
            message = 'No commands are available.'
        }

        if (interaction.user.id == process.env.DEV_ID) {
            message += `\n\n**Commands available : ${availableCommands.size}**\n**Sub-commands available : ${categoryList.map(c => c.commands).flat().length}**`
        }

        const embed = new MWEmbedBuilder()
            .setTitle('Commands available')
            .setDescription(message)

        await embed.displayMWEmbed(interaction)
    }

    private async getAvailableCommands(interaction: ChatInputCommandInteraction) {
        const { guild, member, client } = interaction;

        const serverCommands = (await guild.commands.fetch()).concat(await client.application.commands.fetch());
        const memberPermissions = member.permissions as PermissionsBitField

        if (memberPermissions.has(PermissionsBitField.Flags.Administrator)) {
            return serverCommands;
        }

        const guildSettings = await new ChampionshipsData(guild.id).getGuildSettingsAsync();
        const memberRoleIds = member.roles instanceof GuildMemberRoleManager
            ? Array.from(member.roles.cache.keys())
            : member.roles;

        const commandsAvailable = serverCommands.filter(command =>
            this.isCommandAccessible(command, memberPermissions, guildSettings, memberRoleIds)
        );

        return commandsAvailable;
    }

    private isCommandAccessible(command: ApplicationCommand, memberPermissions: PermissionsBitField, guildSettings: GuildSettings, memberRoleIds: string[]): boolean {
        let hasPermission = false
        if (!command.defaultMemberPermissions?.bitfield) {
            hasPermission = true
        }
        else if (memberPermissions && memberPermissions.has(command.defaultMemberPermissions?.bitfield)) {
            hasPermission = true
        }
        
        const hasChampionshipRole = this.getChampionshipRolesVisibility(command.name, guildSettings, memberRoleIds);

        return hasPermission && hasChampionshipRole;
    }

    private getChampionshipRolesVisibility(commandName: string, guildSettings: GuildSettings, memberRoleIds: string[]) {
        const { managerRoleId, teamLeaderRoleId } = guildSettings;

        switch (commandName) {
            case 'champ':
                return managerRoleId && memberRoleIds.includes(managerRoleId);
            case 'add':
            case 'remove':
            case 'exclude':
            case 'bonus':
                return managerRoleId && memberRoleIds.includes(managerRoleId) || teamLeaderRoleId && memberRoleIds.includes(teamLeaderRoleId);
            default:
                return true;
        }
    }

    createCommandCategories(commands: Collection<string, ApplicationCommand>): CommandData[] {
        const commandList = CacheManager.commands
        const categoryList = new Array<CommandData>()

        commands.forEach(serverCommand => {
            const commandCategory = commandList.find(c => c.command.name == serverCommand.name)?.category ?? ''
            const subCommandGroups = serverCommand.options.filter(c => c.type == ApplicationCommandOptionType.SubcommandGroup) as ApplicationCommandSubGroup[]

            subCommandGroups.forEach(scg => {
                const subCommands = scg.options.filter(c => c.type == ApplicationCommandOptionType.Subcommand)
                subCommands.forEach(sc => {
                    const commandName = `${serverCommand.name} ${scg.name} ${sc.name}`
                    this.addCommandToCategory(categoryList, commandCategory, commandName, sc.description)
                })
            })

            const subCommands = serverCommand.options.filter(c => c.type == ApplicationCommandOptionType.Subcommand)
            subCommands.forEach(sc => {
                const commandName = `${serverCommand.name} ${sc.name}`
                this.addCommandToCategory(categoryList, commandCategory, commandName, sc.description)
            })

            if (subCommandGroups.length == 0 && subCommands.length == 0) {
                this.addCommandToCategory(categoryList, commandCategory, serverCommand.name, serverCommand.description)
            }
        });

        categoryList.forEach(c => c.commands.sort((a, b) => a.name.localeCompare(b.name)))
        return categoryList.sort((a, b) => a.category.localeCompare(b.category))
    }

    addCommandToCategory(categoryList: CommandData[], category: string, name: string, description: string) {
        const correctCategory = categoryList.find(cc => cc.category == category)
        if (correctCategory) {
            correctCategory.addCommand(name, description)
        }
        else {
            const newCategory = new CommandData(category)
            newCategory.addCommand(name, description)
            categoryList.push(newCategory)
        }
    }
}

class CommandData {
    category: string
    commands = new Array<{ name: string, description: string }>()

    constructor(category: string) {
        this.category = category;
    }

    addCommand(name: string, description: string): void {
        this.commands.push({ name, description });
    }
}
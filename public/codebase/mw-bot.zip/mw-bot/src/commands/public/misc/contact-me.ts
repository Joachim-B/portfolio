import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, MessageFlags, InteractionContextType } from 'discord.js';
import BaseSlashCommand from '../../../utils/common/abstraction/baseSlashCommand';
import { Categories } from '../../../utils/common/sharedEnums';
import { MWEmbedBuilder } from '../../../utils/common/sharedElements';

export default class ContactMeCommand extends BaseSlashCommand {
    private userCooldowns: Map<string, number> = new Map();
    command = new SlashCommandBuilder()
        .setName('contact-me')
        .setDescription('Send a message to the developer of the bot')
        .addStringOption(o => o
            .setName('message')
            .setDescription('Your message')
            .setRequired(true)
        )
        .addStringOption(o => o
            .setName('discord-invite-link')
            .setDescription('An invite link to your server')
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setContexts(InteractionContextType.Guild)
    category = Categories.help;
    public async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        const userId = interaction.user.id;
        const currentTime = Date.now();
        const cooldownTime = 5 * 60 * 1000; // 5 minutes in milliseconds

        if (this.userCooldowns.has(userId)) {
            const lastUsed = this.userCooldowns.get(userId) || 0;

            if (currentTime - lastUsed < cooldownTime) {
                await interaction.reply({ content: 'Due to spam prevention, you can only send a message every 5 minutes.', flags: MessageFlags.Ephemeral });
                return;
            }
        }

        this.userCooldowns.set(userId, currentTime);

        const message = interaction.options.getString('message');
        const inviteLink = interaction.options.getString('discord-invite-link') ?? '';
        const embed = new MWEmbedBuilder()
            .setAuthor({ name: interaction.user.displayName, iconURL: interaction.user.displayAvatarURL() })
            .setDescription(`### Sent by \`@${interaction.user.username}\` (${interaction.member}) from '${interaction.guild.name}'\n${inviteLink}\n${message}`)
        const gor = await interaction.client.users.fetch(process.env.DEV_ID);
        embed.displayToUser(gor)

        await interaction.reply({ content: 'Thank you for your message, I will review it and respond as soon as possible.', flags: MessageFlags.Ephemeral });
    }
}
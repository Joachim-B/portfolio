import fs from 'fs';
import path from 'path';
import { formatInTimeZone } from 'date-fns-tz';
import cacheManager from './cache-manager';
import IGuildLogData from './common/sharedElements';

// Define log levels
enum LogLevel {
    INFO = '',
    ERROR = '❌ ERROR: '
}

const logDirectoryPath = path.resolve('./logs')
const logFileFormat = '{1}-log-{0}.log'
const logTimeFormat = 'HH:mm:ss'
const fileTimeFormat = 'yyyy-MM-dd'

export default class Logger {

    public info(message: string, guildId: string, consoleLog: boolean = true): void {
        const logMsg = this.log(LogLevel.INFO, message, guildId)
        if (consoleLog) console.log(logMsg);
    }

    public error(message: string, guildId: string, consoleLog: boolean = true): void {
        const logMsg = this.log(LogLevel.ERROR, message, guildId)
        if (consoleLog) console.error(logMsg);
    }

    private log(level: LogLevel, message: string, guildId: string): string {
        try {
            const guildData = cacheManager.getGuildLogData(guildId)
            const { logMessage, consoleMessage } = this.formatMessage(level, message, guildData.ACRONYM);
            this.appendLogFile(logMessage, guildData)
            return consoleMessage
        }
        catch (e) {
            console.error('Logging error:', e)
            return 'Logging error'
        }
    }

    private appendLogFile(logMessage: string, guildData: IGuildLogData) {
        const filePath = this.formatFilePath(guildData)
        const dirPath = path.dirname(filePath);
        fs.mkdirSync(dirPath, { recursive: true });
        fs.appendFileSync(filePath, logMessage + '\n', { flag: 'a' });
    }

    private formatFilePath(guildData: IGuildLogData) {
        return path.join(logDirectoryPath, guildData.DIRECTORY_NAME, logFileFormat.replace('{0}', formatInTimeZone(new Date(), 'Europe/Paris', fileTimeFormat)).replace('{1}', guildData.ACRONYM))
    }

    private formatMessage(level: LogLevel, message: string, guildAcronym: string): { logMessage: string, consoleMessage: string } {
        const time = formatInTimeZone(new Date(), 'Europe/Paris', logTimeFormat)
        return {
            logMessage: `[${time}] ${level}${message}`,
            consoleMessage: `[${time}] ${guildAcronym} - ${level}${message}`
        };
    }
}
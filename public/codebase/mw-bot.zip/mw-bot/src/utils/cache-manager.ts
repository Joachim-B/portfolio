import { Client, Collection, Guild } from 'discord.js'
import path from 'path'
import fs from 'fs'
import BaseEvent from '../events/abstraction/baseEvent'
import BaseSlashCommand from './common/abstraction/baseSlashCommand'
import Utils from './utils'
import { ITask } from '../events/abstraction/baseTask'
import IGuildLogData from './common/sharedElements'
import Papa from 'papaparse'
import AllowedCommandsData from '../db-objects/data/commands-data'

const commandsDirectory = path.join(__dirname, '../commands')
const publicCommandsDirectory = path.join(__dirname, '../commands/public')
const mwCommandsDirectory = path.join(__dirname, '../commands/mw')
const whitelistCommandsDirectory = path.join(__dirname, '../commands/whitelist')
const eventsDirectory = path.join(__dirname, '../events')
const intervalDirectory = path.join(__dirname, '../events/intervals')
const logDataFile = path.join(__dirname, '../../logs/guilds.csv')

class CacheManager {
    private static instance: CacheManager
    public commands = new Collection<string, BaseSlashCommand>()
    private guildLogData: IGuildLogData[] = []
    private utils = new Utils()

    private constructor() { }

    public static getInstance(): CacheManager {
        if (!CacheManager.instance) {
            CacheManager.instance = new CacheManager()
        }
        return CacheManager.instance
    }

    //#region Bot initialization

    public init(client: Client) {
        this.initGuildLoadData()
        this.initCommandList()
        this.initClientEvents(client)
        this.initIntervals(client)
    }

    private initCommandList() {
        const commandFolders = fs.readdirSync(commandsDirectory)
        for (const folder of commandFolders) {
            const commandsSubFolder = path.join(commandsDirectory, folder)
            for (const command of this.getFolderCommands(commandsSubFolder)) {
                this.commands.set(command.command.name, command)
            }
        }
    }

    private initClientEvents(client: Client) {
        const eventFiles = fs
            .readdirSync(eventsDirectory)
            .filter((file) => file.endsWith('.js'))

        for (const file of eventFiles) {
            const filePath = path.join(eventsDirectory, file)
            const event = this.getEventInstance(filePath)
            if (!event) {
                continue;
            }
            if (event.once) {
                client.once(event.name, (...args) => event.executeWithSuper(...args))
            } else {
                client.on(event.name, (...args) => event.executeWithSuper(...args))
            }
        }
    }

    private initIntervals(client: Client) {
        const intervalsFiles = fs
            .readdirSync(intervalDirectory)
            .filter((file) => file.endsWith('.js'))

        for (const file of intervalsFiles) {
            const filePath = path.join(intervalDirectory, file)
            const task = this.getIntervalInstance(filePath)
            if (!task) {
                continue;
            }
            task.execute(client).catch(e => console.error('Task execution failed:', e))
            setInterval(async () => {
                try {
                    await task.execute(client);
                } catch (error) {
                    console.error('Task execution failed:', error);
                }
            }, task.interval);
        }
    }

    //#endregion

    //#region Log data management

    private initGuildLoadData() {
        this.guildLogData = this.loadLogDataFile()
    }

    updateGuildLoadData(client: Client) {
        for (const guild of client.guilds.cache.values()) {
            this.addLogDataEntryIfNotExists(guild)
        }
    }

    addLogDataEntryIfNotExists(guild:Guild) {
        if (this.guildLogData.find(d => d.ID == guild.id)) {
            return
        }
        const data: IGuildLogData = {
            ID: guild.id,
            NAME: guild.name,
            DIRECTORY_NAME: this.utils.normalize(guild.name),
            ACRONYM: guild.nameAcronym
        }
        this.guildLogData.push(data)

        const csv = Papa.unparse(this.guildLogData, {
            delimiter: ';'
        });

        fs.writeFileSync(logDataFile, csv, 'utf8');
    }

    getGuildLogData(guildId: string): IGuildLogData {
        return this.guildLogData.find(d => d.ID == guildId)
    }

    private loadLogDataFile(): IGuildLogData[] {
        try {
            // Read file content synchronously
            const data = fs.readFileSync(logDataFile, 'utf8');
    
            // Parse CSV data with PapaParse
            const parsed = Papa.parse<IGuildLogData>(data, {
                header: true,            // Use the first row as headers
                delimiter: ';',          // Set the delimiter to `;`
                skipEmptyLines: true     // Skip empty lines
            });
    
            // Check for parsing errors
            if (parsed.errors.length > 0) {
                throw new Error(`CSV parsing error: ${parsed.errors[0].message}`);
            }
    
            return parsed.data; // Return the parsed data as an array of objects
        } catch (error) {
            console.error('Error loading CSV file:', error);
            throw error;
        }
    }

    //#endregion

    //#region Commands reloading

    public async reloadGlobalCommands(client: Client) {
        const publicCommands = this.getFolderCommands(publicCommandsDirectory).map(c => c.command)
        console.log(`Started refreshing ${publicCommands.length} global (/) commands.`)

        try {
            await client.application.commands.set(publicCommands)
            console.log(`Successfully reloaded ${publicCommands.length} global (/) commands.`)
        } catch (error) {
            console.error(error)
        }
    }

    public async reloadAllGuildsCommands(client: Client) {
        const data = await new AllowedCommandsData().loadAsync()
        const guilds = Array.from(client.guilds.cache.values())
        await Promise.all(guilds.map(g => this.reloadGuildCommands(g, data)))
    }

    public async reloadGuildCommands(guild: Guild, data?: AllowedCommandsData) {
        const guildId = guild.id
        if (!data) {
            data = await new AllowedCommandsData().loadAsync()
        }

        const guildCommands: Array<BaseSlashCommand> = []

        if (guildId == process.env.MW_GUILD) {
            guildCommands.push(...this.getFolderCommands(mwCommandsDirectory))
        }
        const hasChampionshipAllowed = data.championshipAllowedGuilds.includes(guildId)
        if (hasChampionshipAllowed) {
            guildCommands.push(...this.getSubFolderCommands(whitelistCommandsDirectory, 'championships'))
        }
        if (data.connectAllowedGuilds.includes(guildId)) {
            guildCommands.push(...this.getSubFolderCommands(whitelistCommandsDirectory, 'connect'))
        }

        if (guildCommands.length != 0) {
            await guild.commands.set(guildCommands.map(c => c.command));
            console.log(`Reloaded ${guildCommands.length} guild commands for ${guild.name}`)
        }
    }

    private getFolderCommands(commandDirectory: string): Array<BaseSlashCommand> {
        const commands = new Array<BaseSlashCommand>()

        const commandFolders = fs.readdirSync(commandDirectory)
        for (const folderName of commandFolders) {
            commands.push(...this.getSubFolderCommands(commandDirectory, folderName))
        }

        return commands
    }

    private getSubFolderCommands(commandDirectory: string, folderName: string) {
        const commands = new Array<BaseSlashCommand>()
        const commandsPath = path.join(commandDirectory, folderName)
        const commandFiles = fs
            .readdirSync(commandsPath)
            .filter((file) => file.endsWith('.js'))
        for (const file of commandFiles) {
            const command = this.getCommandInstance(commandsPath, file)
            if (command) {
                commands.push(command)
            }
        }
        return commands
    }

    //#endregion

    //#region Get instances

    private getEventInstance(filePath: string): BaseEvent {
        const commandInstance = this.utils.getDefaultClassInstance(filePath)
        if (commandInstance instanceof BaseEvent) {
            return commandInstance
        }
    }

    private getCommandInstance(commandsDirectory: string, file: string): BaseSlashCommand {
        const filePath = path.join(commandsDirectory, file);
        const commandInstance = this.utils.getDefaultClassInstance(filePath)
        if (!commandInstance) {
            return
        }
        if (commandInstance instanceof BaseSlashCommand) {
            return commandInstance
        }
    }

    private getIntervalInstance(filePath: string): ITask {
        const commandInstance = this.utils.getDefaultClassInstance(filePath)
        if ('interval' in commandInstance && 'execute' in commandInstance) {
            return commandInstance as ITask
        }
    }

    //#endregion
}
export default CacheManager.getInstance()

export default class Utils {
    replaceAll(str: string, find: string, replace: any) {
        return str?.replace(new RegExp(find, 'g'), replace)
    }

    isDiscordMessageLink(url): boolean {
        const discordUrlRegex = /^https:\/\/((ptb|canary).)?discord(app)?.com\/channels\/\d{17,19}\/\d{17,19}\/\d{17,19}(?:\/\d{17,19})?$/;
        return discordUrlRegex.test(url);
    }

    hasValue(array: Array<any> | null | undefined): boolean {
        return (array?.length ?? 0) > 0
    }

    getRandomValue<T>(arr: T[]): T {
        const randomIndex = Math.floor(Math.random() * arr.length);
        return arr[randomIndex];
    }

    randomNumber(min: number, max: number) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    getDefaultClassInstance(filePath: string): any {
        const unknownClass = require(filePath).default
        if (typeof unknownClass === 'function' && unknownClass.prototype) {
            return new unknownClass()
        }
    }

    normalize(input: string): string {
        return input.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9]/g, '_');
    }

    async isImage(url: string): Promise<boolean> {
        try {
            const response = await fetch(url, { method: 'HEAD' });
            const contentType = response.headers.get('Content-Type');

            return response.ok && contentType?.startsWith('image/');
        } catch {
            return false;
        }
    }
}

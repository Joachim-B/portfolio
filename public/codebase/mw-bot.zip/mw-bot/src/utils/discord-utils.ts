import { ActionRowBuilder, ButtonBuilder, ButtonInteraction, ButtonStyle, ChatInputCommandInteraction, Client, Collection, ComponentType, Guild, GuildMember, InteractionCollector, InteractionResponse, Message, MessageFlags, ReadonlyCollection, Role, RoleResolvable, TextChannel } from 'discord.js';
import ModCmdData from '../db-objects/data/mod-cmd-data';
import Utils from './utils';
import { InteractionError } from './common/sharedElements';
import CategoryRoleData from '../db-objects/data/category-roles';

export default class DiscordUtils {
    public utils = new Utils()

    //#region Fetching Data

    async getChannelAsync(channelId: string, guild: Guild, throwIfNull: boolean = false) {
        try {
            const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId);
            return channel
        }
        catch {
            if (throwIfNull) {
                throw new InteractionError(`Channel not found based on id '${channelId}'`);
            }
        }
    }

    async getTextChannelAsync(channelId: string, guild: Guild, throwIfNull: boolean = false) {
        try {
            const channel = await this.getChannelAsync(channelId, guild, true)
            this.isTextChannel(channel, true)
            return channel as TextChannel
        }
        catch (err) {
            if (throwIfNull) {
                if (err instanceof InteractionError) {
                    throw err
                }
                else {
                    throw new InteractionError(`The provided channel with id '${channelId}' is not a text channel`);
                }
            }
        }
    }

    async getMessageAsync(messageId: string, channelId: string, guild: Guild, throwIfNull: boolean = false) {
        try {
            const channel = await this.getTextChannelAsync(channelId, guild, true)
            const message = channel.messages.cache.get(messageId) || await channel.messages.fetch(messageId)
            return message;
        }
        catch (err) {
            if (throwIfNull) {
                if (err instanceof InteractionError) {
                    throw err
                }
                else {
                    throw new InteractionError(`Message not found based on id '${messageId}' and channelId '${channelId}'`);
                }
            }
        }
    }

    async getMessageByLinkAsync(messageLink: string, guild: Guild, throwIfNull: boolean = false) {
        try {
            const [, channelId, messageId] = messageLink.match(/(\d{17,19})/g)
            return await this.getMessageAsync(messageId, channelId, guild, true)
        }
        catch (err) {
            if (throwIfNull) {
                throw err
            }
        }
    }

    async getMessagesAsync(count: number, channelId: string, guild: Guild, filter: (m: Message) => boolean, cache: boolean = false): Promise<Message<true>[]> {
        const channel = await this.getTextChannelAsync(channelId, guild)
        const messages = new Array<Message<true>>()
        let endReached = false
        let lastMessageId: string = undefined
        while (!endReached && messages.length < count) {
            const limit = count - messages.length > 100 ? 100 : count - messages.length

            let receivedMessages = await channel.messages.fetch({ before: lastMessageId, limit: limit, cache: cache })
            lastMessageId = receivedMessages.lastKey()

            if (receivedMessages.size < limit) {
                endReached = true
            }
            if (filter) {
                receivedMessages = receivedMessages.filter(m => filter(m))
            }

            messages.push(...receivedMessages.values())
        }
        return messages
    }

    async getRoleAsync(roleId: string, guild: Guild, throwIfNull: boolean = false) {
        try {
            const role = guild.roles.cache.get(roleId) || await guild.roles.fetch(roleId);
            return role
        }
        catch {
            if (throwIfNull) {
                throw new InteractionError(`Role not found based on id '${roleId}'`);
            }
        }
    }

    async getMemberAsync(memberId: string, guild: Guild, throwIfNull: boolean = false) {
        try {
            const role = guild.members.cache.get(memberId) || await guild.members.fetch(memberId);
            return role;
        }
        catch {
            if (throwIfNull) {
                throw new InteractionError(`Member not found in the server for the given ID: '${memberId}'`);
            }
        }
    }

    async getGuildAsync(guildId: string, client: Client, throwIfNull: boolean = false) {
        try {
            const guild = client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId)
            return guild
        }
        catch {
            if (throwIfNull) {
                throw new InteractionError(`Server not found for the ID: \`${guildId}\`. Add the bot to this server first.`);
            }
        }
    }

    async fetchDataAsync(guild: Guild, options: { members?: boolean, roles?: boolean, channels?: boolean } = {}) {
        const { members = false, roles = false, channels = false } = options;

        if (members) await guild.members.fetch();
        if (roles) await guild.roles.fetch();
        if (channels) await guild.channels.fetch();
    }

    async doesRolesExist(guild: Guild, ...roleIds: string[]): Promise<boolean[]> {
        const results = await Promise.all(
            roleIds.map(async (id) => {
                if (!id) return false;
                return !!(await this.getRoleAsync(id, guild));
            })
        );
    
        return results;
    }

    //#endregion

    //#region Perform actions

    public async updateMemberRolesAsync(member: GuildMember,
        rolesToAdd?: RoleResolvable | readonly RoleResolvable[] | ReadonlyCollection<string, Role>,
        rolesToRemove?: RoleResolvable | readonly RoleResolvable[] | ReadonlyCollection<string, Role>,
        reason?: string) {

        // Normalize rolesToAdd and rolesToRemove to always be arrays
        const rolesToAddArray = rolesToAdd
            ? Array.isArray(rolesToAdd)
                ? rolesToAdd
                : rolesToAdd instanceof Map || rolesToAdd instanceof Collection
                    ? Array.from(rolesToAdd.values())
                    : [rolesToAdd]
            : [];

        const rolesToRemoveArray = rolesToRemove
            ? Array.isArray(rolesToRemove)
                ? rolesToRemove
                : rolesToRemove instanceof Map || rolesToRemove instanceof Collection
                    ? Array.from(rolesToRemove.values())
                    : [rolesToRemove]
            : [];

        const hasRolesToAdd = this.utils.hasValue(rolesToAddArray)
        const hasRolesToRemove = this.utils.hasValue(rolesToRemoveArray)
        if (hasRolesToAdd && hasRolesToRemove) {
            // Try to add and remove roles with a set request
            try {

                const newMemberRoles = Array.from(member.roles.cache.values())
                    .filter(r => !rolesToRemoveArray.some(rr => rr.id == r.id))

                newMemberRoles.push(...rolesToAddArray)

                await member.roles.set(newMemberRoles, reason)
                return
            }
            catch {
                // Update the roles with usual add and remove requests
            }
        }

        if (hasRolesToAdd) {
            await member.roles.add(rolesToAddArray, reason)
        }

        if (hasRolesToRemove) {
            await member.roles.remove(rolesToRemoveArray, reason)
        }
    }

    async displayConfirmationMessage(interaction: ChatInputCommandInteraction | ButtonInteraction, confirmationMessage: string, ephemeral: boolean = false, deleteIfCancelled: boolean = false): Promise<{ confirmed: boolean; confirmationMessage: ButtonInteraction }> {
        const confirm = new ButtonBuilder()
            .setCustomId('confirm')
            .setLabel('Confirm')
            .setStyle(ButtonStyle.Primary);

        const cancel = new ButtonBuilder()
            .setCustomId('cancel')
            .setLabel('Cancel')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(confirm, cancel);

        const response = await interaction.reply({
            content: confirmationMessage,
            components: [row],
            flags: ephemeral ? MessageFlags.Ephemeral : undefined
        });

        try {
            const confirmation = await response.awaitMessageComponent({ filter: i => i.user.id === interaction.user.id, time: 60_000 });
            if (confirmation.customId === 'confirm') {
                return { confirmed: true, confirmationMessage: confirmation as ButtonInteraction }
            } else if (confirmation.customId === 'cancel') {
                if (deleteIfCancelled) {
                    await confirmation.message.delete()
                    await confirmation.deferUpdate()
                }
                else {
                    await confirmation.update({ content: 'Action cancelled.', components: [] });
                }
                return { confirmed: false, confirmationMessage: null }
            }

        } catch {
            await interaction.editReply({ content: 'Confirmation not received within 1 minute, cancelling...', components: [] });
            return { confirmed: false, confirmationMessage: null }
        }
    }

    //#endregion

    //#region Constraints

    mustBeDiscordMessageLinkAsync(url: string) {
        if (!this.utils.isDiscordMessageLink(url)) {
            throw new InteractionError(`The URL \`${url}\` is not a valid message link !`)
        }
    }

    mustBeTextChannelAsync(channel: any) {
        if (!this.isTextChannel(channel)) {
            throw new InteractionError(`The channel ${channel} must be a text channel !`)
        }
    }

    //#endregion

    //#region Verifications

    async checkIfModCmdChannel(interaction: ChatInputCommandInteraction): Promise<void> {
        const data = new ModCmdData(interaction.guild.id)
        await data.loadAsync()

        if (!data.channelId) {
            return
        }

        const channelId = interaction.channelId
        if (data.channelId == channelId) {
            return
        }

        const modChannel = await this.getChannelAsync(data.channelId, interaction.guild)
        throw new InteractionError(`This command must be executed in ${modChannel} !`)
    }

    isTextChannel(channel: any, throwIfFalse: boolean = false): boolean {
        const result = channel instanceof TextChannel
        if (!result && throwIfFalse) {
            throw new InteractionError('The channel provided is not a text channel!')
        }
        return result
    }

    //#endregion

    //#region Update category roles

    async updateMemberCategoryRolesAsync(member: GuildMember, rolesAdded: boolean = true, rolesRemoved: boolean = true) {
        const roleUpdate = await this.findCategoryRolesUpdatesAsync(member, rolesAdded, rolesRemoved)
        if (roleUpdate.needsUpdate()) {
            await this.updateMemberRolesAsync(member, roleUpdate.rolesToAdd, roleUpdate.rolesToRemove)
        }
    }

    async findCategoryRolesUpdatesAsync(member: GuildMember, rolesAdded: boolean = true, rolesRemoved: boolean = true): Promise<MemberRoleUpdate> {
        const data = new CategoryRoleData(member.guild.id)
        await data.loadAsync()
        if (!data.categoryRoleIds.length) {
            return
        }
        const memberCategoryRoles = this.getUserCategoryRoles(data, member)
        const allCategoryRoles = member.guild.roles.cache.filter(r => data.getCategoryRoleIdsSet().has(r.id));
        const correctCategoryRoles = await this.getCorrectCategoryRoles(allCategoryRoles, member)
        const categoryRolesUpdate = new MemberRoleUpdate()

        if (rolesRemoved) {
            const categoryRolesToRemove = memberCategoryRoles.filter(mcr => !correctCategoryRoles.some(r => r.id == mcr.id))
            categoryRolesUpdate.rolesToRemove.push(...categoryRolesToRemove)
        }
        if (rolesAdded) {
            const categoryRolesToAdd = correctCategoryRoles
                .filter(cr => !memberCategoryRoles.some(r => r.id == cr.id)
                    && !data.getGhostRoleIdsSet().has(cr.id))
            categoryRolesUpdate.rolesToAdd.push(...categoryRolesToAdd)
        }
        return categoryRolesUpdate
    }

    private getUserCategoryRoles(data: CategoryRoleData, member: GuildMember) {
        return Array.from(member.roles.cache.filter(r => data.getCategoryRoleIdsSet().has(r.id)).values())
    }

    private async getCorrectCategoryRoles(allCategoryRoles: Collection<string, Role>, member: GuildMember): Promise<Role[]> {
        const correctCategoryRoles = new Set<Role>();

        member.roles.cache.forEach(role => {
            if (role.id === member.guild.id || allCategoryRoles.has(role.id)) return;

            const categoryRole = allCategoryRoles
                .filter(r => r.position > role.position)  // Roles above the user's current role
                .sort((r1, r2) => r1.position - r2.position) // Sort by position (ascending)
                .first(); // Get the first (lowest) role above

            if (categoryRole) {
                correctCategoryRoles.add(categoryRole);
            }
        });

        return Array.from(correctCategoryRoles);
    }

    //#endregion

    //#region Buttons

    createButtonCollector(reply: InteractionResponse, userId?: string, seconds?: number, ...rows: ActionRowBuilder<any>[]): InteractionCollector<ButtonInteraction> {
        const time = seconds ? 1000 * seconds : undefined
        const filter = userId ? (i: ButtonInteraction) => i.user.id === userId : undefined
        const collector = reply.createMessageComponentCollector({
            componentType: ComponentType.Button,
            filter,
            time,
            dispose: true
        })

        if (time && rows) {
            collector.on('end', async _ => {
                rows.forEach(r => r.components.forEach(c => c['setDisabled'](true)))
                await reply.edit({ components: rows })
            })
        }
        else if (time) {
            collector.on('end', async _ => {
                await reply.edit({ components: [] })
            })
        }

        return collector
    }


    getButtonRowBuilder(...buttons: ButtonBuilder[]) {
        return new ActionRowBuilder<ButtonBuilder>()
            .addComponents(buttons);
    }

    //#endregion
}

export class MemberRoleUpdate {
    rolesToAdd = new Array<Role>()
    rolesToRemove = new Array<Role>()

    public push(roles: MemberRoleUpdate) {
        if (!roles) return
        this.rolesToAdd.push(...roles.rolesToAdd)
        this.rolesToRemove.push(...roles.rolesToRemove)
    }

    public needsUpdate(): boolean {
        return !(this.rolesToAdd.length == 0 && this.rolesToRemove.length == 0)
    }
}
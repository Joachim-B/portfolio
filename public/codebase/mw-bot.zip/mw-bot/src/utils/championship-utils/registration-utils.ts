import { TextChannel, ButtonBuilder, ButtonStyle, ButtonInteraction, GuildMember, Message, ActionRowBuilder, Guild, MessageFlags } from 'discord.js'
import { InteractionPrefix } from '../common/sharedEnums'
import DiscordUtils from '../discord-utils'
import ChampionshipsData, { ChampionshipsSettings, TeamData } from '../../db-objects/data/championship-data'
import { Dictionary } from '../common/sharedElements'
import ChampionshipUtils from './utils'

export default class RegistrationUtils {
    private dUtils = new DiscordUtils()

    async handleJoinClick(interaction: ButtonInteraction) {
        const { customId } = interaction
        const [, action, result, teamId] = customId.split('.')

        if (action == 'join') {
            await this.joinOrLeaveChampionship(interaction)
        }
        else {
            const data = new ChampionshipsData(interaction.guildId)
            if (result == 'confirm') {
                let content = ''

                if (action == 'leaveChamp') {
                    const member = interaction.member as GuildMember
                    const memberId = member.user.id

                    await data.removePlayersFromTeam(teamId, memberId)
                    const teamRole = await this.dUtils.getRoleAsync(teamId, interaction.guild)
                    await this.dUtils.updateMemberRolesAsync(member, null, teamRole)
                    await this.addNextApplicantToTeam(teamId, (await data.getChampionshipAsync()).data, interaction.guild)
                    content = 'You have successfully left the championship!'
                }
                else {
                    await data.removePlayerFromWaitingList(interaction.member.user.id)
                    content = 'You have successfully left the championship\'s waiting list!'
                }

                await interaction.reply({ content, flags: MessageFlags.Ephemeral })
            }
            else {
                await interaction.reply({ content: 'Action cancelled.', flags: MessageFlags.Ephemeral })
            }
        }
    }

    private async joinOrLeaveChampionship(interaction: ButtonInteraction) {
        const data = new ChampionshipsData(interaction.guildId)
        const champ = (await data.getChampionshipAsync()).data
        const member = interaction.member as GuildMember
        const memberId = member.user.id

        const teamId = champ.playerToTeamMapping[memberId]
        if (teamId) {
            await this.displayLeaveConfirmationMessage(interaction, 'leaveChamp', teamId)
            return
        }

        const guildData = champ.guilds[interaction.guildId]
        const waitinglist = guildData.waitinglist ?? new Array<string>()

        if (waitinglist.includes(memberId)) {
            await this.displayLeaveConfirmationMessage(interaction, 'leaveWaiting')
            return
        }

        if (!guildData.registrationMessage.registrationOpen) {
            await interaction.reply({ content: 'Registrations are currently closed.', flags: MessageFlags.Ephemeral })
            return
        }

        if (guildData.registrationMessage.sendNotifications) {
            await this.createJoiningNotification(member, interaction.message)
        }

        await interaction.deferReply({ flags: MessageFlags.Ephemeral })

        if (guildData.autoFillTeams) {
            const teamAvailable = this.getNextAvailableTeam(new ChampionshipUtils().getGuildTeams(interaction.guildId, champ), champ.slotsPerTeam)
            if (teamAvailable) {
                await data.addPlayersToTeam(teamAvailable.id, member)
                const role = await this.dUtils.getRoleAsync(teamAvailable.id, interaction.guild)
                await member.roles.add(role)
                await interaction.editReply({ content: `Congratulations! You have successfully joined the team **${teamAvailable.team.name}**! 🔥\nYou can find out who your team leader is in the team chat.` })
                return
            }
        }

        await data.addPlayerToWaitingList(memberId)
        const content = '**You are on the waiting list to join the championship!** You will be added to a team once they are finalized or when a slot becomes available.'

        await interaction.editReply({ content })
    }

    async createJoiningNotification(member: GuildMember, message: Message) {
        const channel = message.channel as TextChannel
        await channel.send({ content: `${member} has joined the championship!` })
        await message.delete()
        return await this.createOpenRegistrationsMessage(channel)
    }

    async createOpenRegistrationsMessage(channel: TextChannel, messageId?: string) {
        const row = this.getJoinButtonRow()

        if (messageId) {
            const message = await this.dUtils.getMessageAsync(messageId, channel.id, channel.guild)
            await message.delete()
        }
        return await channel.send({ content: '### Click here to join the championship!\n-# Note: This button can also be used to leave', components: [row] })
    }

    async createCloseRegistrationsMessage(channel: TextChannel) {
        const row = this.getLeaveButtonRow()
        return await channel.send({ content: '### Championship registrations are currently closed.', components: [row] })
    }

    getJoinButtonRow() {
        const join = new ButtonBuilder()
            .setCustomId(`${InteractionPrefix.champRegister}.join`)
            .setStyle(ButtonStyle.Success)
            .setLabel('Join!')

        return this.dUtils.getButtonRowBuilder(join)
    }

    getLeaveButtonRow() {
        const leave = new ButtonBuilder()
            .setCustomId(`${InteractionPrefix.champRegister}.join`)
            .setStyle(ButtonStyle.Danger)
            .setLabel('Leave Championship')

        return this.dUtils.getButtonRowBuilder(leave)
    }

    private async displayLeaveConfirmationMessage(interaction: ButtonInteraction, action: string, parameter?: string) {
        parameter = parameter ? '.' + parameter : ''
        const confirm = new ButtonBuilder()
            .setCustomId(`${InteractionPrefix.champRegister}.${action}.confirm${parameter}`)
            .setLabel('Confirm')
            .setStyle(ButtonStyle.Primary);

        const cancel = new ButtonBuilder()
            .setCustomId(`${InteractionPrefix.champRegister}.${action}.cancel${parameter}`)
            .setLabel('Cancel')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(cancel, confirm);

        const content = action == 'leaveChamp'
            ? 'Are you sure you want to leave the championship ?'
            : 'Are you sure you want to leave the waiting list ?'
        await interaction.reply({
            content,
            components: [row],
            flags: MessageFlags.Ephemeral
        });
    }

    getNextAvailableTeam(teams: Dictionary<TeamData>, slotsPerTeam: number) {
        const availableTeams = Object.entries(teams)
            .map(([id, team]) => { return { id, team, teamSize: Object.keys(team.scoreboard).length } })
            .filter(data => data.teamSize < slotsPerTeam)

        if (availableTeams.length > 0) {
            const chosenTeam = availableTeams.reduce((previous, current) => {
                if (current.teamSize < previous.teamSize) {
                    return current
                }
                return previous
            }, availableTeams[0])

            return chosenTeam
        }
    }

    async addNextApplicantToTeam(teamId: string, champ: ChampionshipsSettings, guild: Guild) {
        const guildId = champ.teams[teamId]?.guildId
        if (!guildId) {
            return
        }
        const waitingList = champ.guilds[guildId].waitinglist

        const nextPlayerId = waitingList[0]

        if (!nextPlayerId) {
            return
        }

        const data = new ChampionshipsData(guildId)
        const player =  await new DiscordUtils().getMemberAsync(nextPlayerId, guild)
        if (player) {
            const role = await this.dUtils.getRoleAsync(teamId, guild)
            if (role) {
                await this.dUtils.updateMemberRolesAsync(player, role)
            }
            await data.addPlayersToTeam(teamId, player)
        }

        await data.removePlayerFromWaitingList(nextPlayerId)
        return player
    }
}
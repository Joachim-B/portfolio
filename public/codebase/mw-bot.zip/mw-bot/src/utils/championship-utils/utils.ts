import { APIApplicationCommandOptionChoice, ApplicationCommand, ApplicationCommandOption, ApplicationCommandOptionType, ApplicationCommandSubGroup, BaseInteraction, ButtonInteraction, ChatInputCommandInteraction, Client, Collection, Guild, GuildMemberRoleManager, SlashCommandBuilder, SlashCommandSubcommandBuilder } from 'discord.js';
import ChampionshipsData, { ChampionshipsSettings, TeamData } from '../../db-objects/data/championship-data';
import { Dictionary, InteractionError } from '../common/sharedElements';
import ShowCommand from '../../commands/whitelist/championships/show';
import AddBonusSubCommand from '../../commands/whitelist/championships/bonus/add';
import RemoveBonusSubcommand from '../../commands/whitelist/championships/bonus/remove';
import ChampTeamRemoveSubCommand from '../../commands/whitelist/championships/champ/team/remove';
import ChampTeamRenameSubCommand from '../../commands/whitelist/championships/champ/team/rename';
import ChampTeamConfigSubCommand from '../../commands/whitelist/championships/champ/team/config';
import ChampForceAddSubCommand from '../../commands/whitelist/championships/champ/force/add';
import ChampForceRemoveSubCommand from '../../commands/whitelist/championships/champ/force/remove';
import DiscordUtils from '../discord-utils';

export default class ChampionshipUtils {

    readonly champTeamDynamicCommands: DynamicCommandData = {
        name: 'champ',
        groupName: 'team',
        subCommands: [
            new ChampTeamRemoveSubCommand(),
            new ChampTeamRenameSubCommand(),
            new ChampTeamConfigSubCommand()
        ]
    }

    readonly champForceDynamicCommands: DynamicCommandData = {
        name: 'champ',
        groupName: 'force',
        subCommands: [
            new ChampForceAddSubCommand(),
            new ChampForceRemoveSubCommand()
        ]
    }

    readonly bonusDynamicSubCommands: DynamicCommandData = {
        name: 'bonus',
        subCommands: [
            new AddBonusSubCommand(),
            new RemoveBonusSubcommand()
        ]
    }

    async reloadCommandsChoices(interaction: BaseInteraction): Promise<void> {
        await this.reloadGuildCommandsChoices(interaction.client, interaction.guild)
    }

    async reloadGuildCommandsChoices(client: Client, guild: Guild): Promise<void> {
        try {
            const data = new ChampionshipsData(guild.id)
            const championship = await data.getChampionshipAsync()
            const teamChoices = this.getTeamChoices(championship.data)
            const guildCommands = await guild.commands.fetch()
            const guildTeamChoices = this.getTeamChoices(championship.data, guild.id);
            const multipleServers = Object.keys(championship.data.guilds).length > 1

            const requests: Promise<void>[] = []
            requests.push(
                ...this.getReloadServerCommandsPromises(guild, guildTeamChoices, guildCommands),
                this.reloadChampionshipShowCommand(client, guild.id, teamChoices, multipleServers)
            )
            await Promise.all(requests)
        }
        catch { /* */ }
    }

    async reloadCommandsOfAllGuilds(client: Client) {
        const data = new ChampionshipsData(undefined);
        const championships = await data.getChampionshipsAsync();

        console.log('Started refreshing the championship commands.')

        const requests = (
            await Promise.all(
                Object.values(championships).map(async championship => {
                    const teamChoices = this.getTeamChoices(championship);
                    const guildIds = Object.keys(championship.guilds)
                    const multipleServers = guildIds.length > 1;
                    const updatedShowCommand = new ShowCommand().getCommand(teamChoices, multipleServers);

                    return Promise.all(
                        guildIds.map(async guildId => {
                            const guild = client.guilds.cache.get(guildId);
                            if (!guild) return []
                            const guildCommands = await guild.commands.fetch();
                            const guildTeamChoices = this.getTeamChoices(championship, guild.id);

                            return [
                                ...this.getReloadServerCommandsPromises(guild, guildTeamChoices, guildCommands),
                                this.reloadServerShowCommand(guild, guildCommands, updatedShowCommand)
                            ];
                        })
                    );
                })
            )
        ).flat(2);

        Promise.all(requests)

        console.log('Successfully reloaded the championship commands.')
    }

    async cleanExistingChampionship(interaction: BaseInteraction) {
        const guildId = interaction.guildId
        const data = new ChampionshipsData(guildId)
        try { // If the championship is hosted by the guild
            await data.removeGuildsFromNewChampionship()
            return
        }
        catch {/* */ }

        try { // If the guild has joined a running championship
            await data.removeGuildFromChampionship()
            await this.reloadCommandsChoices(interaction)
        }
        catch {/* */ }
    }

    getGuildTeams(guildId: string, championship: ChampionshipsSettings) {
        const guildTeamIds = championship.guilds[guildId].teamIds
        const teamData = championship.teams

        const guildTeamData = guildTeamIds.reduce((result, id) => {
            if (teamData[id]) {
                result[id] = teamData[id];
            }
            return result;
        }, {} as Dictionary<TeamData>);

        return guildTeamData;
    }

    getScoreUpdateFormat(playerName: string, oldScore: number, newScore: number, points: string) {
        return `Updated **${playerName}** score (**${points}**) : ${oldScore}  ⮕  **${newScore}**`
    }

    getTeamsPlayerCount(playerToTeamMapping: Dictionary<string>): Dictionary<number> {
        return Object.values(playerToTeamMapping).reduce((acc, teamId) => {
            acc[teamId] = (acc[teamId] || 0) + 1;
            return acc;
        }, {} as Dictionary<number>);
    }

    getTeamPlayerCount(playerToTeamMapping: Dictionary<string>, teamId: string): number {
        let count = 0;
        for (const playerTeamId of Object.values(playerToTeamMapping)) {
            if (playerTeamId === teamId) {
                count++;
            }
        }
        return count;
    }

    checkPlayerUpdateValidity(championship: ChampionshipsSettings, guildId: string, playerId: string) {
        const teamId = championship.playerToTeamMapping[playerId]
        if (!teamId) {
            throw new InteractionError('The selected player hasn\'t joined any team! They might be missing a role.')
        }
        this.checkTeamUpdateValidity(championship, guildId, teamId)
    }

    checkTeamUpdateValidity(championship: ChampionshipsSettings, guildId: string, teamId: string) {
        const selectedPlayerGuildId = championship.teams[teamId].guildId
        if (selectedPlayerGuildId != guildId) {
            throw new InteractionError('Cannot perform actions on players from other servers!')
        }
    }

    async throwIfChampCommandUnavailable(interaction: ChatInputCommandInteraction | ButtonInteraction, roleRequirement: ChampionshipRoles, throwIfFalse = true): Promise<boolean> {
        const memberRoleIds = interaction.member.roles instanceof GuildMemberRoleManager
            ? Array.from(interaction.member.roles.cache.keys())
            : interaction.member.roles;

        const { managerRoleId, teamLeaderRoleId } = await this.getValidChampionshipRoleIds(interaction)

        const actionType = interaction instanceof ChatInputCommandInteraction ? 'command' : 'action'

        if (roleRequirement == ChampionshipRoles.challenger) {
            const data = new ChampionshipsData(interaction.guildId)
            const champTeams = (await data.getChampionshipAsync()).data.teams
            const teamRoleIds = Object.keys(champTeams)

            if (memberRoleIds.some(item => teamRoleIds.includes(item))) {
                return true
            }

            if (!throwIfFalse) return false
            throw new InteractionError(`This ${actionType} is reserved for those taking part in the championship.`);
        }
        const managerRoleOK = !managerRoleId || memberRoleIds.includes(managerRoleId);
        const teamLeaderRoleOK = !teamLeaderRoleId || memberRoleIds.includes(teamLeaderRoleId);

        if (roleRequirement === ChampionshipRoles.manager && !managerRoleOK) {
            if (!throwIfFalse) return false
            throw new InteractionError(`This ${actionType} is restricted to users with the <@&${managerRoleId}> role.`);
        }

        if (roleRequirement === ChampionshipRoles.teamLeader && !managerRoleOK && !teamLeaderRoleOK) {
            if (!throwIfFalse) return false
            throw new InteractionError(`This ${actionType} is restricted to users with the <@&${teamLeaderRoleId}> or <@&${managerRoleId}> role.`);
        }
        return true
    }

    private async getValidChampionshipRoleIds(interaction: ChatInputCommandInteraction | ButtonInteraction) {
        const data = new ChampionshipsData(interaction.guildId)
        const guildSettings = await data.getGuildSettingsAsync();

        let { managerRoleId, teamLeaderRoleId, playerRoleId } = guildSettings;

        if (managerRoleId || teamLeaderRoleId || playerRoleId) {
            const dUtils = new DiscordUtils()
            const [managerRoleExists, teamLeaderRoleExists, playerRoleExists] = await dUtils.doesRolesExist(interaction.guild, managerRoleId, teamLeaderRoleId, playerRoleId)
            const resetManager = managerRoleId && !managerRoleExists;
            const resetTeamLeader = teamLeaderRoleId && !teamLeaderRoleExists;
            const resetPlayerRole = playerRoleId && !playerRoleExists

            if (resetManager || resetTeamLeader || resetPlayerRole) {
                await data.resetGuildRolesAsync(resetManager, resetTeamLeader, resetPlayerRole);
                managerRoleId = resetManager ? undefined : managerRoleId;
                teamLeaderRoleId = resetTeamLeader ? undefined : teamLeaderRoleId;
                playerRoleId = resetPlayerRole ? undefined : playerRoleId
            }
        }

        return { managerRoleId, teamLeaderRoleId }
    }

    private async reloadChampionshipShowCommand(client: Client, guildId: string, teamChoices: APIApplicationCommandOptionChoice<string>[], multipleServers: boolean) {
        const guilds = await new ChampionshipsData(guildId).getChampionshipGuildsAsync()
        const updatedShowCommand = new ShowCommand().getCommand(teamChoices, multipleServers)

        for (const [, guild] of client.guilds.cache.filter((_, id) => guilds.includes(id))) {
            const guildCommands = await guild.commands.fetch()
            await this.reloadServerShowCommand(guild, guildCommands, updatedShowCommand)
        }
    }

    private async reloadServerShowCommand(guild: Guild, guildCommands: Collection<string, ApplicationCommand>, updatedShowCommand: SlashCommandBuilder) {
        const showCommand = guildCommands.find(c => c.name == 'show');
        if (!showCommand) return
        await guild.commands.edit(showCommand.id, updatedShowCommand.toJSON() as unknown)
    }

    private getReloadServerCommandsPromises(guild: Guild, teamChoices: APIApplicationCommandOptionChoice<string>[], guildCommands: Collection<string, ApplicationCommand>) {
        return [
            this.reloadCommandSubCommands(this.bonusDynamicSubCommands, guild, teamChoices, guildCommands),
            this.reloadCommandSubCommands(this.champTeamDynamicCommands, guild, teamChoices, guildCommands),
            this.reloadCommandSubCommands(this.champForceDynamicCommands, guild, teamChoices, guildCommands)
        ]
    }

    private async reloadCommandSubCommands(commandData: DynamicCommandData, guild: Guild, teamChoices: APIApplicationCommandOptionChoice<string>[], guildCommands: Collection<string, ApplicationCommand>) {
        const command = guildCommands.find(c => c.name == commandData.name);
        if (!command) return
        const subCommandsData = commandData.subCommands.map(c => c.getCommand(teamChoices))

        if (commandData.groupName) {
            const subCommandGroup = command.options.find(g => g.name == commandData.groupName && g.type == ApplicationCommandOptionType.SubcommandGroup) as ApplicationCommandSubGroup
            subCommandGroup.options = subCommandGroup.options.map(o => this.getCorrectSubCommandOption(o, subCommandsData))
            command.options = command.options.map(o => o.name == commandData.groupName && o.type == ApplicationCommandOptionType.SubcommandGroup ? subCommandGroup : o)
        }
        else {
            command.options = command.options.map(o => this.getCorrectSubCommandOption(o, subCommandsData))
        }

        await guild.commands.edit(command.id, command.toJSON())
    }

    private getCorrectSubCommandOption(option: ApplicationCommandOption, subCommandsData: SlashCommandSubcommandBuilder[]): any {
        const newSubCommand = subCommandsData.find(sc => sc.name == option.name)
        if (newSubCommand) {
            return newSubCommand.toJSON()
        }
        else {
            return option
        }
    }

    private getTeamChoices(championship: ChampionshipsSettings, guildId?: string): APIApplicationCommandOptionChoice<string>[] {
        const options = new Array<APIApplicationCommandOptionChoice<string>>()
        const teams = guildId ? this.getGuildTeams(guildId, championship) : championship.teams
        const addAliases = !guildId && Object.keys(championship.guilds).length > 1

        for (const [key, team] of Object.entries(teams)) {
            const guildAlias = championship.guilds[team.guildId]?.alias
            options.push({ name: `${team.name}${!addAliases ? '' : guildAlias ? ` (${guildAlias})` : ''}`, value: key })
        }

        return options
    }
}

export enum ChampionshipRoles {
    manager,
    teamLeader,
    challenger
}

export interface IScoreBoardDynamicSubCommand {
    getCommand(teamChoices?: APIApplicationCommandOptionChoice<string>[]): SlashCommandSubcommandBuilder
}

class DynamicCommandData {
    name: string
    groupName?: string
    subCommands: IScoreBoardDynamicSubCommand[]
}
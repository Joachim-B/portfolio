import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, ComponentType, EmbedBuilder, InteractionResponse, Message, User } from 'discord.js';

export class InteractionError extends Error {
    ephemeral: boolean = true

    constructor(message: string, ephemeral?: boolean) {
        super(message)
        this.ephemeral = ephemeral ?? true
    }
}

export interface Dictionary<T> {
    [key: string]: T;
}

export class MWEmbedBuilder extends EmbedBuilder {
    private hasMultiplePages: boolean = false
    private multiplePages: boolean
    private pages: string[]
    constructor(multiplePages: boolean = true) {
        super()
        this.setColor(0x900000)
        this.multiplePages = multiplePages
    }

    override setDescription(description: string): this {
        if (!this.multiplePages || description.length <= 4096) {
            return super.setDescription(description)
        }

        this.pages = this.getPages(description)
        this.hasMultiplePages = true
        return super.setDescription(this.pages[0])
    }

    private getPages(description: string): string[] {
        const pages: string[] = [];
        let currentPage = '';

        // Split description by paragraphs (using newlines as delimiters)
        const paragraphs = description.split(/(?<=\n)/);

        for (const paragraph of paragraphs) {
            if (paragraph.length > 4096) {
                // If currentPage has content, push it to pages before handling long paragraph
                if (currentPage) {
                    pages.push(currentPage.trim());
                    currentPage = '';
                }

                // Split long paragraph into 4096-character chunks and add them as new pages
                for (let i = 0; i < paragraph.length; i += 4096) {
                    const chunk = paragraph.slice(i, i + 4096).trim();

                    // If adding chunk to currentPage would exceed 4096, push currentPage and reset
                    if (currentPage.length + chunk.length > 4096) {
                        pages.push(currentPage.trim());
                        currentPage = chunk;
                    } else {
                        currentPage += chunk;
                    }
                }
                continue;
            }

            // For paragraphs within 4096 characters
            if (currentPage.length + paragraph.length > 4096) {
                // If adding paragraph exceeds limit, push currentPage and reset
                pages.push(currentPage.trim());
                currentPage = paragraph;
            } else {
                currentPage += paragraph;
            }
        }

        // Add any remaining content in currentPage to pages
        if (currentPage) {
            pages.push(currentPage.trim());
        }

        return pages;
    }

    async displayMWEmbed(interaction: ChatInputCommandInteraction) {
        const method = interaction.deferred ? 'editReply' : 'reply'
        const reply = await interaction[method]({ embeds: [this], components: this.getComponents() })
        if (this.hasMultiplePages) {
            this.createButtonCollector(reply, 120)
        }
        return reply
    }

    async displayToUser(user: User) {
        const message = await user.send({ embeds: [this], components: this.getComponents() })
        if (this.hasMultiplePages) {
            this.createButtonCollector(message)
        }
    }

    private getComponents() {
        return this.hasMultiplePages ? [this.getButtonRow(1, this.pages.length)] : undefined
    }

    private getButtonRow(page: number, totalPages: number) {
        const row = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`${page - 1}`)
                    .setLabel('◀️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(page === 1),
                new ButtonBuilder()
                    .setCustomId('page')
                    .setLabel(`${page}/${totalPages}`)
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId(`${page + 1}`)
                    .setLabel('▶️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(page === totalPages)
            );

        return row;
    }

    private createButtonCollector(reply: InteractionResponse | Message, timeInSeconds?: number) {
        const time = timeInSeconds ? timeInSeconds * 1000 : undefined
        const collector = reply.createMessageComponentCollector({
            componentType: ComponentType.Button,
            time,
            dispose: true
        })

        collector.on('collect', async i => {
            const newPage = parseInt(i.customId)
            const embed = new EmbedBuilder(i.message.embeds[0])
            embed.setDescription(this.pages[newPage - 1])
            await i.message.edit({ embeds: [embed], components: [this.getButtonRow(newPage, this.pages.length)] })
            await i.deferUpdate()
        })

        if (time) {
            collector.on('end', async _ => {
                await reply.edit({ components: [] })
            })
        }

        return collector
    }
}

export default interface IGuildLogData {
    ID: string;
    NAME: string;
    DIRECTORY_NAME: string;
    ACRONYM: string;
}
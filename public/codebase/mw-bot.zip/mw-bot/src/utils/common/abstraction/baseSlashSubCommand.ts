import { SlashCommandSubcommandBuilder } from 'discord.js';
import BaseSlashCommandAbstract from './baseSlashCommandAbstract';

export default abstract class BaseSlashSubCommand extends BaseSlashCommandAbstract {
    abstract command : SlashCommandSubcommandBuilder
}
import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import BaseSlashCommand from './baseSlashCommand';
import BaseSlashSubCommand from './baseSlashSubCommand';
import BaseSlashSubCommandGroup from './baseSlashSubCommandGroup';
import path from 'path'
import fs from 'fs'
import { Categories } from '../sharedEnums';

export default class BaseSlashCommandGroup extends BaseSlashCommand {
    readonly category: string;
    readonly command = new SlashCommandBuilder();
    private subCommands: Array<BaseSlashSubCommand | BaseSlashSubCommandGroup> = []

    constructor(category: Categories, filename: string) {
        super()
        const dirname = path.dirname(filename);
        const filenameWithoutExtension = path.basename(filename, path.extname(filename));
        this.command.setName(filenameWithoutExtension).setDescription('description')
        this.category = category
        this.addSubCommands(dirname)
    }

    protected addSubCommands(dirname: string): void {
        const folder = path.join(dirname, `./${this.command.name}`)
        if (!fs.existsSync(folder)) {
            throw new Error(`The folder '${this.command.name}' is missing from the directory '${dirname}'!`)
        }
        const subcommandFiles = fs.readdirSync(folder)
            .filter((file) => file.endsWith('.js'))

        for (const file of subcommandFiles) {
            const filePath = path.join(folder, file);
            const commandInstance = this.dUtils().utils.getDefaultClassInstance(filePath)
            if (!commandInstance) {
                continue
            }

            if (commandInstance instanceof BaseSlashSubCommandGroup) {
                this.command.addSubcommandGroup(commandInstance.command)
                this.subCommands.push(commandInstance)
            }
            else if (commandInstance instanceof BaseSlashSubCommand) {
                this.command.addSubcommand(commandInstance.command)
                this.subCommands.push(commandInstance)
            }
        }
    }

    // eslint-disable-next-line unused-imports/no-unused-vars
    protected async beforeExecute(interaction: ChatInputCommandInteraction) { /*Empty command*/ }

    public async execute(interaction: ChatInputCommandInteraction) {
        await this.beforeExecute(interaction)
        const subcommand = interaction.options.getSubcommandGroup() ?? interaction.options.getSubcommand()

        for (let i = 0; i < this.subCommands.length; i++) {
            if (subcommand === this.subCommands[i].command.name) {
                await this.subCommands[i].execute(interaction)
                break
            }
        }
    }
}
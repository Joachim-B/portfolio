import { SharedSlashCommand, SlashCommandBuilder } from 'discord.js';
import BaseSlashCommandAbstract from './baseSlashCommandAbstract';
import { Categories } from '../sharedEnums';

export default abstract class BaseSlashCommand extends BaseSlashCommandAbstract {
    abstract command : SlashCommandBuilder | SharedSlashCommand
    abstract category: Categories | string
}
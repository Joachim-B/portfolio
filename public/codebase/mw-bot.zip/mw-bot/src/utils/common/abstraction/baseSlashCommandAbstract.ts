import { ChatInputCommandInteraction } from 'discord.js';
import DiscordUtils from '../../discord-utils';

export default abstract class BaseSlashCommandAbstract {
    public abstract execute(interaction: ChatInputCommandInteraction) : Promise<void>
    private discordUtils: DiscordUtils
    protected dUtils() {
        if (!this.discordUtils) {
            this.discordUtils = new DiscordUtils()
        }
        return this.discordUtils
    }
}
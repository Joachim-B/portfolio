export enum Categories {
    help = 'Help',
    misc = 'Misc',
    ranking = 'Ranking',
    categoryRoles = 'Category roles',
    setup = 'Setup',
    moderation = 'Moderation',
    messageStats = 'Message stats',
    championship = 'Championship',
    championshipSetup = 'Championship setup',
    connect = 'Channel connect',
    nofap = 'Nofap'
}

export enum InteractionPrefix {
    champLeaderboard = 'champLeaderboard',
    teamConfig = 'teamConfig',
    champRegister = 'champRegister',
    champSubmit = 'champSubmit'
}
import BaseData from '../base-data'
import DataKey from '../datakeys'

export default class PaladinData extends BaseData {
    paladinRoleId: string
    headPaladinRoleId: string
    description:string

    constructor(guildId: string) {
        super(guildId, DataKey.paladinsSetup)
    }
}

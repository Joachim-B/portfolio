import BaseData from '../base-data'
import DataKey from '../datakeys'

type UrgeMessage = {
    message: string,
    id: number,
    attachmentLink: string
}

export default class UrgeData extends BaseData {
    nextId: number = 0
    messages: UrgeMessage[] = []

    constructor() {
        super(process.env.MW_GUILD, DataKey.urge)
    }
}
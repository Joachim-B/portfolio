import BaseData from '../base-data'
import DataKey from '../datakeys'

export default class StaffData extends BaseData {
    staffRoles: string[] = []

    constructor(guildId: string) {
        super(guildId, DataKey.staff)
    }
}

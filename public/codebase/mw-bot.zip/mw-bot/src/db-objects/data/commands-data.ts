import BaseData from '../base-data'
import DataKey from '../datakeys'

export default class AllowedCommandsData extends BaseData {
    championshipAllowedGuilds: string[] = []
    connectAllowedGuilds: string[] = []

    constructor() {
        super(process.env.MW_GUILD, DataKey.allowedCommands)
    }
}
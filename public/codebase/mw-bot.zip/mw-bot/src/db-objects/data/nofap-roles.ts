import BaseData from '../base-data'
import DataKey from '../datakeys'

export default class NofapRoleData extends BaseData {
    roles: RoleData[] = []

    constructor(guildId: string) {
        super(guildId, DataKey.nofapRoles)
    }
}

export interface RoleData {
    roleId: string,
    level: number
}
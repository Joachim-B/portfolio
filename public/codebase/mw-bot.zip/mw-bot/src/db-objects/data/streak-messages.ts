import BaseData from '../base-data'
import DataKey from '../datakeys'

export enum MessageType {
    Relapse = 'Relapse',
    Edging = 'Edging',
    Milestone = 'Milestone'
}

export type MessageData = { id: number, message: string, type: MessageType, milestone?: number }

export default class StreakMessageData extends BaseData {
    nextId: number = 0
    messageData: Array<MessageData> = []
    constructor() {
        super(process.env.MW_GUILD, DataKey.streakMessages)
    }
}
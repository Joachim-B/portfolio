import { QuickDB } from 'quick.db'
import { Dictionary, InteractionError } from '../../utils/common/sharedElements';
import ChampionshipUtils from '../../utils/championship-utils/utils';
import { GuildMember, User } from 'discord.js';

export default class ChampionshipsData {
    guildId: string
    champId: string

    constructor(guildId: string) {
        this.guildId = guildId
    }

    async getChampId() {
        if (!this.champId) {
            this.champId = await this.getChampionshipIdAsync(this.guildId)
        }
        return this.champId
    }

    //#region Logic methods

    async createChampionshipAsync(name: string, serverName: string, slotsPerTeam: number, publicStatus?: boolean, serverAlias?: string) {
        const championshipsSettings = new ChampionshipsSettings()
        championshipsSettings.name = name
        championshipsSettings.public = publicStatus ?? false
        championshipsSettings.guilds[this.guildId] = new GuildData(serverName, serverAlias)
        championshipsSettings.slotsPerTeam = slotsPerTeam

        await this.setChampionShipIdToGuildAsync(this.guildId, this.guildId)
        await this.setChampionshipsSettingsAsync(this.guildId, championshipsSettings)
    }

    async joinChampionshipAsync(championshipId: string, serverName: string, serverAlias: string) {
        const runningChampionships = await this.getGuildToChampionshipMapping()
        if (runningChampionships[championshipId] != championshipId) {
            throw new InteractionError('The provided ID doesn\'t match any public championship.')
        }
        this.champId = championshipId
        const championship = await this.getChampionshipAsync()
        if (!championship.data.public) {
            throw new InteractionError('The provided ID doesn\'t match any public championship.')
        }

        await this.setChampionShipIdToGuildAsync(this.guildId, championshipId)
        await this.setGuildDataAsync(championshipId, this.guildId, new GuildData(serverName, serverAlias))
    }

    async removeGuildsFromNewChampionship() {
        const guildToChampionshipMapping = await this.getGuildToChampionshipMapping()
        const champId = guildToChampionshipMapping[this.guildId]
        if (this.guildId != champId) {
            throw new InteractionError('This command can only be used by hosting servers.')
        }
        let deleteCount = 0
        for (const key in guildToChampionshipMapping) {
            if (guildToChampionshipMapping[key] == champId) {
                delete guildToChampionshipMapping[key]
                deleteCount++
            }
        }
        if (deleteCount > 1) {
            await this.setGuildToChampionshipMapping(guildToChampionshipMapping)
        }
    }

    async removeGuildFromChampionship() {
        const championship = await this.getChampionshipAsync()
        if (championship.id == this.guildId) {
            throw new InteractionError('The server hosting the championship cannot be removed.')
        }

        const guildTeams = new ChampionshipUtils().getGuildTeams(this.guildId, championship.data)
        for (const key in guildTeams) {
            for (const pKey in championship.data.playerToTeamMapping) {
                if (championship.data.playerToTeamMapping[pKey] == key) {
                    delete championship.data.playerToTeamMapping[pKey]
                }
            }
            delete championship.data.teams[key]
        }

        const guildToChampionshipMapping = await this.getGuildToChampionshipMapping()
        for (const key in guildToChampionshipMapping) {
            if (guildToChampionshipMapping[key] == championship.id) {
                delete guildToChampionshipMapping[key]
            }
        }

        await this.setGuildToChampionshipMapping(guildToChampionshipMapping)
        await this.setChampionshipsSettingsAsync(championship.id, championship.data)
    }

    async setGuildRolesAsync(managerRoleId?: string, teamLeaderRoleId?: string, playerRoleId?: string) {
        const settings = await this.getGuildSettingsAsync(this.guildId)
        if (managerRoleId) settings.managerRoleId = managerRoleId
        if (teamLeaderRoleId) settings.teamLeaderRoleId = teamLeaderRoleId
        if (playerRoleId) settings.playerRoleId = playerRoleId
        await this.setGuildSettingsAsync(this.guildId, settings)
    }

    async resetGuildRolesAsync(resetManagerRole: boolean = false, resetTeamLeaderRole: boolean = false, resetPlayerRole: boolean = false) {
        const settings = await this.getGuildSettingsAsync(this.guildId)
        if (resetManagerRole) settings.managerRoleId = undefined
        if (resetTeamLeaderRole) settings.teamLeaderRoleId = undefined
        if (resetPlayerRole) settings.playerRoleId = undefined
        await this.setGuildSettingsAsync(this.guildId, settings)
    }

    async setServerInviteAsync(inviteLink: string, description: string) {
        const settings = await this.getGuildSettingsAsync(this.guildId)
        settings.inviteLink = inviteLink
        settings.serverDescription = description
        await this.setGuildSettingsAsync(this.guildId, settings)
    }

    async createTeamAsync(name: string, roleId: string, channelId?: string) {
        const champId = await this.getChampId()
        const newTeam = new TeamData()
        newTeam.name = name
        newTeam.guildId = this.guildId
        newTeam.scoreboard = {}
        newTeam.totalPoints = 0
        newTeam.teamChannel = channelId
        await this.setTeamAsync(champId, roleId, newTeam)
        await this.addGuildTeamIds(champId, this.guildId, roleId)
    }

    async removeTeamAsync(teamId: string) {
        const champId = await this.getChampId()
        await this.deleteTeamAsync(champId, teamId)
        await this.deleteGuildTeamId(champId, this.guildId, teamId)
        const playerToTeamMapping = await this.getPlayerToTeamMapping(champId)
        for (const key in playerToTeamMapping) {
            if (playerToTeamMapping[key] == teamId) {
                delete playerToTeamMapping[key]
            }
        }
        await this.setPlayerToTeamMapping(champId, playerToTeamMapping)
    }

    async renameTeamAsync(teamId: string, updatedName: string) {
        const champId = await this.getChampId()
        await this.setTeamNameAsync(champId, teamId, updatedName)
    }

    async addPlayersToTeam(teamId: string, ...players: GuildMember[]): Promise<void> {
        const championship = await this.getChampionshipAsync();
        const scoreboard = championship.data.teams[teamId].scoreboard
        const playerToTeamMapping = championship.data.playerToTeamMapping

        const playersToRemove: Dictionary<string[]> = {};
        const playersToRemoveFromWaitingList = new Array<string>()
        const addScoreBoard = { ...scoreboard }

        let scoreboardChanged = false
        for (const player of players) {
            const oldTeamId = playerToTeamMapping[player.id];

            if (oldTeamId && oldTeamId !== teamId) {
                if (!playersToRemove[oldTeamId]) {
                    playersToRemove[oldTeamId] = [];
                }
                playersToRemove[oldTeamId].push(player.id);
            }

            if (addScoreBoard[player.id] == undefined) {
                addScoreBoard[player.id] = new PlayerData(player.user.username);
                scoreboardChanged = true
            }
            playerToTeamMapping[player.id] = teamId;

            if (championship.data.guilds[this.guildId].waitinglist.includes(player.id)) {
                playersToRemoveFromWaitingList.push(player.id)
            }
        }

        const removalPromises = Object.entries(playersToRemove).map(([oldTeamId, players]) =>
            this.removePlayersFromTeam(oldTeamId, ...players)
        );
        const removalWaitingListPromises = playersToRemoveFromWaitingList.map(p => this.removePlayerFromWaitingList(p))

        await Promise.all([...removalPromises, ...removalWaitingListPromises]);

        if (scoreboardChanged) {
            await this.setScoreboardAsync(championship.id, teamId, addScoreBoard)
        }
        await this.setPlayerToTeamMapping(championship.id, playerToTeamMapping)
    }

    async removePlayersFromTeam(teamId: string, ...playerIds: string[]): Promise<void> {
        const championship = await this.getChampionshipAsync();
        const scoreboard = championship.data.teams[teamId].scoreboard
        const playerToTeamMapping = championship.data.playerToTeamMapping

        let scoreboardChanged = false
        playerIds.forEach(playerId => {
            if (!scoreboard[playerId] || scoreboard[playerId]?.score === 0) {
                scoreboardChanged = true
                delete scoreboard[playerId];
            }
            delete playerToTeamMapping[playerId];
        });

        if (scoreboardChanged) {
            await this.setScoreboardAsync(championship.id, teamId, scoreboard)
        }
        await this.setPlayerToTeamMapping(championship.id, playerToTeamMapping)
    }

    async addScoreAsync(playerId: string, score: number) {
        const champ = await this.getChampionshipAsync()
        new ChampionshipUtils().checkPlayerUpdateValidity(champ.data, this.guildId, playerId)
        return await this.addPlayerScoreAsync(champ.id, champ.data.playerToTeamMapping[playerId], playerId, score)
    }

    async substractScoreAsync(playerId: string, score: number) {
        const champ = await this.getChampionshipAsync()
        new ChampionshipUtils().checkPlayerUpdateValidity(champ.data, this.guildId, playerId)
        return await this.substractPlayerScoreAsync(champ.id, champ.data.playerToTeamMapping[playerId], playerId, score)
    }

    async addScoreForceAsync(teamId: string, player: User, score: number) {
        const champ = await this.getChampionshipAsync()
        await this.addPlayerDataIfNotExists(champ.data, champ.id, teamId, player)
        const finalScore = await this.addPlayerScoreAsync(champ.id, teamId, player.id, score)
        await this.removePlayerIfScoreIsZero(champ.data, champ.id, teamId, player.id, finalScore)
        return finalScore
    }

    async substractScoreForceAsync(teamId: string, player: User, score: number) {
        const champ = await this.getChampionshipAsync()
        await this.addPlayerDataIfNotExists(champ.data, champ.id, teamId, player)
        const finalScore = await this.substractPlayerScoreAsync(champ.id, teamId, player.id, score)
        await this.removePlayerIfScoreIsZero(champ.data, champ.id, teamId, player.id, finalScore)
        return finalScore
    }

    private async addPlayerDataIfNotExists(champ: ChampionshipsSettings, champId: string, teamId: string, player: User) {
        const playerId = player.id
        if (!champ.teams[teamId].scoreboard[playerId]) {
            const data = new PlayerData(player.username)
            await this.setPlayerData(champId, teamId, playerId, data)
        }
    }

    private async removePlayerIfScoreIsZero(champ: ChampionshipsSettings, champId: string, teamId: string, playerId: string, score: number) {
        if (score == 0 && champ.playerToTeamMapping[playerId] != teamId) {
            await this.deletePlayerData(champId, teamId, playerId)
        }
    }

    async addBonusAsync(teamId: string, score: number) {
        const champ = await this.getChampionshipAsync()
        new ChampionshipUtils().checkTeamUpdateValidity(champ.data, this.guildId, teamId)
        return await this.addBonusScoreAsync(champ.id, teamId, score)
    }

    async substractBonusAsync(teamId: string, score: number) {
        const champ = await this.getChampionshipAsync()
        new ChampionshipUtils().checkTeamUpdateValidity(champ.data, this.guildId, teamId)
        return await this.substractBonusScoreAsync(champ.id, teamId, score)
    }

    async updateTotalScoresAsync(): Promise<{ team: TeamData, scoreDifference: number }[]> {
        const champ = await this.getChampionshipAsync()
        const updatedTeams: { team: TeamData, scoreDifference: number }[] = []
        for (const [teamId, team] of Object.entries(champ.data.teams)) {
            const actualTotalPoints = this.getTeamTotalPoints(team)
            if (actualTotalPoints != team.totalPoints) {
                await this.setTotalPointsAsync(champ.id, teamId, actualTotalPoints)
                updatedTeams.push({ team: team, scoreDifference: actualTotalPoints - team.totalPoints })
            }
        }
        return updatedTeams
    }

    private getTeamTotalPoints(team: TeamData) {
        return Object.values(team.scoreboard)?.reduce((sum, current) => sum + (current.score ?? 0), 0) + (team.bonusPoints ?? 0);
    }

    async getChampionshipGuildsAsync(): Promise<string[]> {
        const runningChampionships = await this.getGuildToChampionshipMapping()
        return Object.keys(runningChampionships)
            .filter(guildId => runningChampionships[guildId] === runningChampionships[this.guildId]);
    }

    async setChampionshipVisibilityAsync(champId: string, publicState: boolean) {
        await this.setChampionshipPublicState(champId, publicState)
    }

    async setTeamSlotsAsync(value: number) {
        await this.setTeamSlots(await this.getChampId(), value)
    }

    async setRegistrationMessageDataAsync(data: RegistrationMessageData) {
        await this.setRegistrationMessageData(await this.getChampId(), this.guildId, data)
    }

    async addPlayerToWaitingList(playerId: string) {
        await this.pushWaitingList(await this.getChampId(), this.guildId, playerId)
    }

    async removePlayerFromWaitingList(playerId: string) {
        await this.pullWaitingList(await this.getChampId(), this.guildId, playerId)
    }

    async setWaitingListAsync(waitingList: string[]) {
        await this.setWaitingList(await this.getChampId(), this.guildId, waitingList)
    }
    
    async setAutoFillTeamsAsync(value: boolean) {
        await this.setAutoFillTeams(await this.getChampId(), this.guildId, value)
    }

    //#endregion

    //#region Obtain data methods

    async getChampionshipIdAsync(guildId: string) {
        const champId = await this.loadAsync(`${Key.guildToChampionshipMapping}[${guildId}]`) as string
        if (!champId) {
            throw new InteractionError('The server has not joined any championship!', false)
        }
        return champId
    }

    async getGuildToChampionshipMapping() {
        return (await this.loadAsync(`${Key.guildToChampionshipMapping}`) ?? {}) as Dictionary<string>
    }

    async getChampionshipsAsync() {
        return (await this.loadAsync(`${Key.championships}`) ?? {}) as Dictionary<ChampionshipsSettings>
    }

    async getChampionshipAsync() {
        const champId = await this.getChampId()
        return { id: champId, data: await (this.loadAsync(`${Key.championships}[${champId}]`) ?? {}) as ChampionshipsSettings }
    }

    async getGuildSettingsAsync(guildId?: string) {
        if (!guildId) {
            guildId = this.guildId
        }
        return (await this.loadAsync(`${Key.guildsSettings}[${guildId}]`) ?? new GuildSettings()) as GuildSettings
    }

    private async getPlayerToTeamMapping(champId: string) {
        return (await this.loadAsync(`${Key.championships}[${champId}].${Key.playerToTeamMapping}`) ?? {}) as Dictionary<string>
    }

    //#endregion

    //#region Data management methods

    private async setGuildToChampionshipMapping(runningChampionships: Dictionary<string>) {
        await this.saveAsync(`${Key.guildToChampionshipMapping}`, runningChampionships)
    }

    private async setChampionShipIdToGuildAsync(guildId: string, championshipId: string) {
        await this.saveAsync(`${Key.guildToChampionshipMapping}[${guildId}]`, championshipId)
    }

    public async setChampionshipsSettingsAsync(championshipId: string, settings: ChampionshipsSettings) {
        await this.saveAsync(`${Key.championships}[${championshipId}]`, settings)
    }

    private async setGuildSettingsAsync(guildId: string, guildSettings: GuildSettings) {
        await this.saveAsync(`${Key.guildsSettings}[${guildId}]`, guildSettings)
    }

    private async setTeamAsync(championshipId: string, teamId: string, data: TeamData) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}]`, data)
    }

    private async deleteTeamAsync(championshipId: string, teamId: string) {
        await this.deleteAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}]`)
    }

    private async setTeamNameAsync(championshipId: string, teamId: string, name: string) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.nameKey}`, name)
    }

    private async setChampionshipPublicState(championshipId: string, publicState: boolean) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.public}`, publicState)
    }

    //#region Scoreboard management

    private async setScoreboardAsync(championshipId: string, teamId: string, scoreboard: Dictionary<PlayerData>) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.scoreboard}`, scoreboard)
    }

    private async addPlayerScoreAsync(championshipId: string, teamId: string, playerId: string, scoreToAdd: number) {
        await this.addAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.totalPoints}`, scoreToAdd)
        return await this.addAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.scoreboard}[${playerId}].${Key.score}`, scoreToAdd)
    }

    private async substractPlayerScoreAsync(championshipId: string, teamId: string, playerId: string, scoreToSubstract: number) {
        await this.substractAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.totalPoints}`, scoreToSubstract)
        return await this.substractAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.scoreboard}[${playerId}].${Key.score}`, scoreToSubstract)
    }

    private async addBonusScoreAsync(championshipId: string, teamId: string, scoreToAdd: number) {
        await this.addAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.totalPoints}`, scoreToAdd)
        return await this.addAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.bonusPoints}`, scoreToAdd)
    }

    private async substractBonusScoreAsync(championshipId: string, teamId: string, scoreToSubstract: number) {
        await this.substractAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.totalPoints}`, scoreToSubstract)
        return await this.substractAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.bonusPoints}`, scoreToSubstract)
    }

    private async setTotalPointsAsync(championshipId: string, teamId: string, score: number) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.totalPoints}`, score)
    }

    //#endregion

    private async setPlayerToTeamMapping(championshipId: string, data: Dictionary<string>) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.playerToTeamMapping}`, data ?? {})
    }

    private async setPlayerData(championshipId: string, teamId: string, playerId: string, data: PlayerData) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.scoreboard}[${playerId}]`, data ?? {})
    }

    private async deletePlayerData(championshipId: string, teamId: string, playerId: string) {
        await this.deleteAsync(`${Key.championships}[${championshipId}].${Key.teams}[${teamId}].${Key.scoreboard}[${playerId}]`)
    }

    private async setGuildDataAsync(championshipId: string, guildId: string, data: GuildData) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.guilds}[${guildId}]`, data)
    }

    private async addGuildTeamIds(championshipId: string, guildId: string, ...teamIds: string[]) {
        await this.pushAsync(`${Key.championships}[${championshipId}].${Key.guilds}[${guildId}].${Key.teamIds}`, ...teamIds)
    }

    private async deleteGuildTeamId(championshipId: string, guildId: string, teamId: string) {
        await this.pullAsync(`${Key.championships}[${championshipId}].${Key.guilds}[${guildId}].${Key.teamIds}`, teamId)
    }

    private async setTeamSlots(championshipId: string, value: number) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.slotsPerTeam}`, value)
    }

    private async setRegistrationMessageData(championshipId: string, guildId: string, data: RegistrationMessageData) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.guilds}[${guildId}].${Key.registrationMessage}`, data)
    }

    private async pushWaitingList(championshipId: string, guildId: string, playerId: string) {
        await this.pushAsync(`${Key.championships}[${championshipId}].${Key.guilds}[${guildId}].${Key.waitinglist}`, playerId)
    }

    private async pullWaitingList(championshipId: string, guildId: string, playerId: string) {
        await this.pullAsync(`${Key.championships}[${championshipId}].${Key.guilds}[${guildId}].${Key.waitinglist}`, playerId)
    }

    private async setWaitingList(championshipId: string, guildId: string, playerIds: string[]) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.guilds}[${guildId}].${Key.waitinglist}`, playerIds)
    }

    private async setAutoFillTeams(championshipId: string, guildId: string, value: boolean) {
        await this.saveAsync(`${Key.championships}[${championshipId}].${Key.guilds}[${guildId}].${Key.autoFillTeams}`, value)
    }

    //#endregion

    //#region DB access

    private db = new QuickDB()
    private async loadAsync(key: string) {
        //console.log('Loading: ' + key)
        return await this.db.get(this.getCompleteKey(key))
    }
    private async saveAsync(key: string, value: any) {
        // console.log('Setting: ' + key + ' Value: ' + JSON.stringify(value))
        await this.db.set(this.getCompleteKey(key), value)
    }

    private async deleteAsync(key: string) {
        // console.log('Deleting: ' + key)
        await this.db.delete(this.getCompleteKey(key))
    }

    private async addAsync(key: string, value: number) {
        // console.log('Adding: ' + value + ' : ' + key)
        return await this.db.add(this.getCompleteKey(key), value)
    }

    private async substractAsync(key: string, value: number) {
        // console.log('Substracting: ' + value + ' : ' + key)
        return await this.db.sub(this.getCompleteKey(key), value)
    }

    private async pushAsync(key: string, ...values: any[]) {
        // console.log('Pushing: ' + values + ' into ' + key)
        await this.db.push(this.getCompleteKey(key), ...values)
    }

    private async pullAsync(key: string, value: any) {
        // console.log('Pulling: ' + value + ' from ' + key)
        await this.db.pull(this.getCompleteKey(key), value)
    }

    private getCompleteKey(key: string) {
        return `${Key.root}.${key}`;
    }

    //#endregion
}

//#region Classes

// eslint-disable-next-line unused-imports/no-unused-vars
class ChampionshipDataSchema {
    championships: Dictionary<ChampionshipsSettings> // key : championshipId
    guildsSettings: Dictionary<GuildSettings> // key : guildId
    guildToChampionshipMapping: Dictionary<string> // key : guildId ; value : championshipId
}

export class ChampionshipsSettings {
    name: string
    public: boolean = false
    teams: Dictionary<TeamData> = {} // key : teamRoleId
    guilds: Dictionary<GuildData> = {} // key: guildId
    playerToTeamMapping: Dictionary<string> = {} // key : playerId ; value : teamRoleId
    slotsPerTeam: number
}

export class GuildSettings {
    teamLeaderRoleId: string
    playerRoleId: string
    managerRoleId: string
    mainCategoryId: string
    pointCategoryId: string
    inviteLink: string
    serverDescription: string
}

export class TeamData {
    guildId: string
    name: string
    totalPoints: number
    scoreboard: Dictionary<PlayerData> // key : userId
    bonusPoints: number = 0
    teamChannel: string
}

export class GuildData {
    name: string
    alias: string
    teamIds: string[] = []
    registrationMessage: RegistrationMessageData
    waitinglist: string[] = [] //playerIds
    createChannels: boolean = false
    autoFillTeams: boolean = false

    constructor(name: string, alias: string) {
        this.name = name ?? ''
        this.alias = alias ?? ''
    }
}

export class RegistrationMessageData {
    messageId: string
    channelId: string
    registrationOpen: boolean = false
    sendNotifications: boolean
}

export class PlayerData {
    username: string
    score: number

    constructor(username: string) {
        this.username = username
        this.score = 0
    }
}

class Key {
    static readonly root = 'champ'
    static readonly championships = 'championships'
    static readonly guildToChampionshipMapping = 'guildToChampionshipMapping'
    static readonly guildsSettings = 'guildsSettings'
    static readonly teams = 'teams'
    static readonly scoreboard = 'scoreboard'
    static readonly playerToTeamMapping = 'playerToTeamMapping'
    static readonly guilds = 'guilds'
    static readonly totalPoints = 'totalPoints'
    static readonly nameKey = 'name'
    static readonly score = 'score'
    static readonly teamIds = 'teamIds'
    static readonly public = 'public'
    static readonly bonusPoints = 'bonusPoints'
    static readonly slotsPerTeam = 'slotsPerTeam'
    static readonly registrationMessage = 'registrationMessage'
    static readonly waitinglist = 'waitinglist'
    static readonly autoFillTeams = 'autoFillTeams'
}

//#endregion
import { QuickDB } from 'quick.db'
import { Dictionary } from '../../utils/common/sharedElements'
import DataKey from '../datakeys'

export default class ConnectData {
    hostChannels: Dictionary<HostChannel> = {} // key: hostChannelId
    channelToHost: Dictionary<string> = {} // key: channelId ; value: hostChannelId

    async loadAsync() {
        const json = await new QuickDB().get(DataKey.connect)
        Object.assign(this, json)
    }

    // async setHostChannel(hostId: string, data: HostChannel) {
    //     await this.saveFromKeyAsync(`hostChannels[${hostId}]`, data)
    // }

    // async setChannelToHost(channelId: string, hostId: string) {
    //     await this.saveFromKeyAsync(`channelToHost[${channelId}]`, hostId)
    // }

    // private async saveFromKeyAsync(key: string, data: any) {
    //     await new QuickDB().set(`${DataKey.connect}.${key}`, data)
    // }

    async saveAsync() {
        await new QuickDB({}).set(DataKey.connect, this)
    }
}

export class HostChannel {
    connectedChannels: ChannelData[] 
    status: HostStatus
    championshipChannel: boolean

    constructor(status: HostStatus, championshipChannel: boolean) {
        this.connectedChannels = []
        this.status = status
        this.championshipChannel = championshipChannel
    }
}

export class ChannelData {
    channelId: string
    guildId: string

    constructor(channelId: string, guildId: string) {
        this.channelId = channelId
        this.guildId = guildId
    }
}

export enum HostStatus {
    private,
    public
}
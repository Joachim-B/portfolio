import BaseData from '../base-data'
import DataKey from '../datakeys'

export default class ChallengeRolesData extends BaseData {
    challengeRoleIds: Array<string>
    spartanChallengeDescription: string
    level0Message: string

    constructor(guildId: string) {
        super(guildId, DataKey.challengeRoles)
        this.challengeRoleIds = new Array<string>()
    }
}

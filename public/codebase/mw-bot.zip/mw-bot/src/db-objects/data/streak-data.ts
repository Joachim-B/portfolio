import { QuickDB } from 'quick.db';
import DataKey from '../datakeys';

export default class StreakData {
    private db = new QuickDB()
    users: Map<string, UserData> = new Map(); //key: userId

    async loadAsync() {
        const json = await this.db.get(DataKey.streakNofap) || {};
        this.users = new Map(Object.entries(json).map(([id, data]) => [id, new UserData(data)]));
    }

    async loadUserAsync(userId: string): Promise<UserData | undefined> {
        const data = await this.db.get(`${DataKey.streakNofap}[${userId}]`);
        if (!data) return
        return new UserData(data);
    }

    async saveUserAsync(userId: string, userData: UserData) {
        const key = `${DataKey.streakNofap}[${userId}]`
        //console.log('Setting: ' + key + ' Value: ' + JSON.stringify(userData))
        await this.db.set(key, userData);
    }
}

export type CheckInResult = { noPorn: boolean, noEdge: boolean, noNut: boolean }

export class UserData {
    lastCheck: number // unix time
    lastScoreResult: CheckInResult
    totalScore: number
    todayScore: number
    highestStreak: number
    currentStreak: number
    perfectStreak: number
    adjustedDays: number
    level: number
    weekPoints: number

    teammates: string[] //userIDs

    //Requests
    requests: string[] //userIDs
    requestsMax: number

    //Leaderboard display
    username: string
    serverName: string
    serverId: string

    constructor(rawData?: any) {
        Object.assign(this, rawData)
    }

    loadDefault() {
        this.lastCheck = null // unix time
        this.lastScoreResult = { noPorn: false, noEdge: false, noNut: false }
        this.totalScore = 0
        this.todayScore = 0
        this.highestStreak = 0
        this.currentStreak = 0
        this.perfectStreak = 0
        this.adjustedDays = 0
        this.teammates = []
        this.level = 1
        this.requests = []
        this.weekPoints = 0
        this.requestsMax = 0
        return this
    }

    getUpdatedVersion() {
        const updatedUser = new UserData({ ...this });

        updatedUser.totalScore += updatedUser.todayScore;
        updatedUser.todayScore = 0
        const { noPorn, noEdge, noNut } = updatedUser.lastScoreResult;

        // Handle streaks
        if (noPorn && noEdge && noNut) {
            updatedUser.perfectStreak++;
            if (updatedUser.perfectStreak % 7 === 0) {
                updatedUser.weekPoints++;
            }
        } else {
            updatedUser.perfectStreak = 0;
        }

        if (noNut) {
            updatedUser.currentStreak++;
            const totalStreak = updatedUser.adjustedDays + updatedUser.currentStreak;
            if (updatedUser.highestStreak !== 0 && totalStreak > updatedUser.highestStreak) {
                updatedUser.highestStreak = 0;
            }
        } else {
            updatedUser.resetStreak(); // Handle relapse
        }

        const level = this.getLevelAndXpLeft(updatedUser.totalScore).level

        if (updatedUser.level != level) {
            for (const reward of new StreakRewardData().rewards) {
                if (updatedUser.level < reward.level && level >= reward.level) {
                    reward.execute(updatedUser);
                }
            }
        }

        updatedUser.level = level

        return updatedUser
    }

    resetStreak() {
        if (this.highestStreak == 0) {
            this.highestStreak = this.currentStreak + this.adjustedDays
        }
        this.currentStreak = 0
        this.perfectStreak = 0
        this.adjustedDays = 0
        this.lastScoreResult = { noPorn: false, noEdge: false, noNut: false }
    }

    getNextLevelExp(level: number): number {
        return 250 * (level) ** 2 + 750 * (level)
    }

    getExpBeforeNextLevel() {
        return this.getLevelAndXpLeft(this.totalScore).xpLeft
    }

    private getLevelAndXpLeft(totalXp: number): { level: number, xpLeft: number } {
        let level = 1;
        let expForNextLevel = this.getNextLevelExp(level);

        while (totalXp >= expForNextLevel) {
            totalXp -= expForNextLevel;
            level++;
            expForNextLevel = this.getNextLevelExp(level);
        }

        return { level, xpLeft: totalXp };
    }
}

export class StreakRewardData {
    rewards: Reward[] = [
        new Reward(2, RewardKeys.partners_2, 'You can now team up with **2** accountability partners for daily exp boosts. Use `/nofap invite` to send a request and `/nofap requests` to accept it.', (u) => u.requestsMax = 2),
        new Reward(3, RewardKeys.quotes, 'Get a nice quote from **Minute Wisdom Community** members!'),
        new Reward(4, RewardKeys.partners_4, 'Raised the max number of accountability partners to **4**.', (u) => u.requestsMax = 4),
        new Reward(6, RewardKeys.partners_6, 'Raised the max number of accountability partners to **6**.', (u) => u.requestsMax = 6),
        new Reward(8, RewardKeys.partners_8, 'Raised the max number of accountability partners to **8**.', (u) => u.requestsMax = 8),
    ]
}

export class Reward {
    level: number
    rewardKey: RewardKeys
    description: string
    execute: (userData: UserData) => void;
    constructor(level: number, rewardKey: RewardKeys, description: string, execute?: (userData: UserData) => void) {
        this.level = level
        this.rewardKey = rewardKey
        this.description = description
        this.execute = execute ?? (() => { });
    }
}

export enum RewardKeys {
    partners_2,
    partners_4,
    partners_6,
    partners_8,
    quotes
}
import { QuickDB } from 'quick.db'
import DataKey from './datakeys'

abstract class BaseData {
    protected _key: string

    async loadAsync() {
        const json = await new QuickDB().get(this._key)
        Object.assign(this, json)
        return this
    }

    async saveAsync() {
        const key = this._key
        delete this._key
        await new QuickDB().set(key, this)
    }

    constructor(guildId: string, key: string | DataKey) {
        if (typeof key !== 'string') {
            this._key = guildId.concat('.', DataKey[key])
        } else {
            this._key = guildId.concat('.', key)
        }
    }
}

export default BaseData

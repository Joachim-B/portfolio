enum DataKey {
    welcomeMessageSetup = 'setup.welcomeMessage',
    quoteSetup = 'setup.quote',
    jailSetup = 'setup.jail',
    modCmdSetup = 'setup.modCmd',
    challengeRoles = 'setup.challengeRoles',
    challengeLevels = 'setup.challengeLevels',
    categoryRoles = 'setup.categoryRoles',
    botRole = 'setup.botRole',
    analysis = 'analysis',
    staff = 'staff',
    connect = 'connect',
    paladinsSetup = 'setup.paladins',
    streakNofap = 'streak.nofap',
    nofapRoles = 'nofapRoles',
    allowedCommands = 'allowedCommands',
    urge = 'urgeMessage',
    streakMessages = 'streakMessages',
}

export default DataKey

import { Client, GatewayIntentBits } from 'discord.js'
import CacheManager from './utils/cache-manager'
import dotenv from 'dotenv';
import onBeforeStart from './startup/pre-script'

dotenv.config()

async function main() {
    await onBeforeStart()

    const client = new Client({
        intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMembers,
            GatewayIntentBits.GuildPresences,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.MessageContent
        ],
    })

    CacheManager.init(client)
    client.login(process.env.DISCORD_TOKEN)
        .then(_ => printGuildsInfo(client))
}

async function printGuildsInfo(client: Client) {
    const guilds = Array.from(await client.guilds.fetch())
    console.log()
    console.log(guilds.map(([, g]) => g.name).join('\n'), '\nNumber of guilds :', guilds.length)
}

main()
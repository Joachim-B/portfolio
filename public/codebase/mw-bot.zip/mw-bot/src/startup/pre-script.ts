async function onBeforeStart() {
}

export default onBeforeStart
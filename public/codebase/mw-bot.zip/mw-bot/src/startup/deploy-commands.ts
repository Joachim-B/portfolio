import { Client, GatewayIntentBits } from 'discord.js';
import CacheManager from '../utils/cache-manager';
import ChampionshipUtils from '../utils/championship-utils/utils';
import dotenv from 'dotenv';

// Config the env variables
dotenv.config()

    // Deploy the commands
    ; (async () => {
        const client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMembers,
                GatewayIntentBits.GuildPresences
            ],
        })

        // Log in to Discord with your client's token
        await client.login(process.env.DISCORD_TOKEN)
        const mwGuild = client.guilds.cache.get(process.env.MW_GUILD)

        if (process.argv[2] === 'global') {
            await CacheManager.reloadGlobalCommands(client)
            await CacheManager.reloadAllGuildsCommands(client)
            await new ChampionshipUtils().reloadCommandsOfAllGuilds(client)
        }
        else {
            await CacheManager.reloadGuildCommands(mwGuild)
            await new ChampionshipUtils().reloadGuildCommandsChoices(client, mwGuild)
        }

        await client.destroy()
    })()

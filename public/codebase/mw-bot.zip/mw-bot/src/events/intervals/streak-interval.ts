import { Client } from 'discord.js';
import StreakData, { UserData } from '../../db-objects/data/streak-data';
import Logger from '../../utils/logger';
import { ITask } from '../abstraction/baseTask';

const CHECK_IN_ALERT_COOLDOWN = 36 * 60 * 60 * 1000
const RESET_STREAK_COOLDOWN = 48 * 60 * 60 * 1000

export default class StreakInterval implements ITask {
    interval = 60 * 60 * 1000 // 1 hour

    async execute(client: Client) {
        const data = new StreakData();
        await data.loadAsync();

        const now = Date.now();
        const usersToUpdate = new Map<string, UserData>();
        let resetStreakCount = 0;
        let streakAlertCount = 0;

        for (const [userId, u] of data.users.entries()) {
            if (u.currentStreak > 0 && now > u.lastCheck + RESET_STREAK_COOLDOWN) {
                const user = await client.users.fetch(userId)
                if (u.teammates.length > 0) {
                    for (const teammateId of u.teammates) {
                        const teammate = data.users.get(teammateId)
                        if (teammate) {
                            teammate.teammates = teammate.teammates.filter(t => t != userId)
                            usersToUpdate.set(teammateId, teammate)
                        }
                    }
                    u.teammates = []
                }
                const updatedVersion = u.getUpdatedVersion()
                updatedVersion.resetStreak()
                usersToUpdate.set(userId, updatedVersion);
                resetStreakCount++

                try {
                    await user.send('Greetings, Spartan. It has been 48 hours since your last check-in, so your streak has been reset to ensure fairness for all.\nHowever, your level and rewards progression remain unaffected.\nThank you for your understanding, and take care!')
                }
                catch {/* Unable to send a message */ }

            }
            else if (u.currentStreak > 0 && now > u.lastCheck + CHECK_IN_ALERT_COOLDOWN && now <= u.lastCheck + CHECK_IN_ALERT_COOLDOWN + 60 * 60 * 1000) {
                try {
                    const user = await client.users.fetch(userId)
                    const updatedVersion = u.getUpdatedVersion()
                    const currentStreak = updatedVersion.currentStreak + updatedVersion.adjustedDays
                    await user.send(`Greetings Spartan. It has been 36 hours since your last check-in. Your streak of ${currentStreak} day${currentStreak == 1 ? '' : 's'} will be reset in **12 hours**. To maintain your progress, type the command \`/nofap checkin\` in your server to update your streak! Stay strong and take care!`)
                    streakAlertCount++
                }
                catch {/* Unable to send a message */ }
            }
        }

        for (const [userId, updatedUserData] of usersToUpdate.entries()) {
            await data.saveUserAsync(userId, updatedUserData);
        }

        try {
            new Logger().info(
                `Streak task finished. Streak end alerts: ${streakAlertCount}; Streak resets: ${resetStreakCount}`,
                process.env.MW_GUILD,
                false
            );
        }
        catch { /* Log data not set for MW_GUILD */ }
    }
}
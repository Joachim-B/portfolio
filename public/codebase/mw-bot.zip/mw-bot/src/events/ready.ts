import { Client, Events } from 'discord.js'
import BaseEvent from './abstraction/baseEvent'
import CacheManager from '../utils/cache-manager'

export default class ReadyEvent extends BaseEvent {
    name = Events.ClientReady
    once = true
    async execute(client: Client) {
        console.log(`Ready! Logged in as ${client.user.tag}`)
        CacheManager.updateGuildLoadData(client)
    }
}

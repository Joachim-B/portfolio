import { Collection, Events, GuildMember, Role } from 'discord.js'
import ChallengeRolesData from '../db-objects/data/challenge-roles-data';
import ChallengeLevelData from '../db-objects/data/challenge-levels-data';
import BaseEvent from './abstraction/baseEvent';
import { MemberRoleUpdate } from '../utils/discord-utils';
import SharedFunctions from '../utils/common/sharedFunctions';
import ChampionshipsData, { ChampionshipsSettings } from '../db-objects/data/championship-data';

export default class GuildMemberUpdateEvent extends BaseEvent {
    name = Events.GuildMemberUpdate
    async execute(oldMember: GuildMember, newMember: GuildMember) {
        const rolesAdded = this.getAddedRoles(oldMember, newMember);
        const rolesRemoved = this.getRemovedRoles(oldMember, newMember);

        if (rolesRemoved.size == 0 && rolesAdded.size == 0) {
            return
        }
        await newMember.guild.roles.fetch()

        let logTrace = `Role update for '${newMember.user.username}':\n${this.getRoleTrace('Initial roles', Array.from(rolesAdded.values()), Array.from(rolesRemoved.values()))}`

        const challengeLevelsUpdate = await this.findChallengeLevelRolesUpdates(rolesAdded, rolesRemoved, newMember)
        const categoryRolesUpdate = await this.dUtils.findCategoryRolesUpdatesAsync(newMember, rolesAdded.size > 0, rolesRemoved.size > 0)
        const championshipRolesUpdate = await this.findChampionshipRoleUpdate(rolesAdded, rolesRemoved, newMember)

        const roleUpdate = new MemberRoleUpdate()
        if (challengeLevelsUpdate?.needsUpdate()) {
            logTrace += this.getRoleTrace('Rank level roles', challengeLevelsUpdate.rolesToAdd, challengeLevelsUpdate.rolesToRemove)
            roleUpdate.push(challengeLevelsUpdate)
        }
        if (categoryRolesUpdate?.needsUpdate()) {
            logTrace += this.getRoleTrace('Category roles', categoryRolesUpdate.rolesToAdd, categoryRolesUpdate.rolesToRemove)
            roleUpdate.push(categoryRolesUpdate)
        }
        if (championshipRolesUpdate?.needsUpdate()) {
            logTrace += this.getRoleTrace('Championship roles', championshipRolesUpdate.rolesToAdd, championshipRolesUpdate.rolesToRemove)
            roleUpdate.push(championshipRolesUpdate)
        }

        if (roleUpdate.needsUpdate()) {
            this.logger.info(logTrace, newMember.guild.id, false)
            await this.dUtils.updateMemberRolesAsync(newMember, roleUpdate.rolesToAdd, roleUpdate.rolesToRemove)
        }
    }

    getAddedRoles(oldMember: GuildMember, newMember: GuildMember): Collection<string, Role> {
        const difference = this.getRoleDifference(oldMember, newMember)
        return difference.filter(d => newMember.roles.cache.some(r => r.id == d.id))
    }
    getRemovedRoles(oldMember: GuildMember, newMember: GuildMember): Collection<string, Role> {
        const difference = this.getRoleDifference(oldMember, newMember)
        return difference.filter(d => oldMember.roles.cache.some(r => r.id == d.id))
    }

    getRoleDifference(oldMember: GuildMember, newMember: GuildMember): Collection<string, Role> {
        const oldRoles = oldMember.roles.cache;
        const newRoles = newMember.roles.cache;
        return oldRoles.difference(newRoles)
    }

    getRoleTrace(traceTitle: string, rolesAdded: Role[], rolesRemoved: Role[]) {
        return `${traceTitle} :
    \tRoles added: ${rolesAdded.map(r => `@${r.name}`).join(', ')}
    \tRoles removed: ${rolesRemoved.map(r => `@${r.name}`).join(', ')}
`;
    }

    //#region Challenge role management

    async findChallengeLevelRolesUpdates(rolesAdded: Collection<string, Role>, rolesRemoved: Collection<string, Role>, member: GuildMember): Promise<MemberRoleUpdate> {
        const challengeData = new ChallengeRolesData(member.guild.id)
        const levelData = new ChallengeLevelData(member.guild.id)
        await challengeData.loadAsync()
        await levelData.loadAsync()

        if (challengeData.challengeRoleIds.length == 0
            || levelData.challengeLevelIds.length == 0
        ) {
            return
        }

        if (!rolesAdded.some(r => challengeData.challengeRoleIds.includes(r.id))
            && !rolesRemoved.some(r => challengeData.challengeRoleIds.includes(r.id))) {
            return
        }

        const memberChallengeRolesCount = member.roles.cache.filter(r => challengeData.challengeRoleIds.includes(r.id)).size
        const memberLevelRoles = member.roles.cache.filter(r => levelData.challengeLevelIds.some(l => l.roleId == r.id))
        const correctLevelRoleId = new SharedFunctions().getCorrectLevelRoleId(memberChallengeRolesCount, levelData)

        if (memberLevelRoles.size == 1 && memberLevelRoles.first().id == correctLevelRoleId) {
            return
        }

        const rolesToUpdate = new MemberRoleUpdate()

        // Update level roles
        if (memberLevelRoles.size > 0) {
            rolesToUpdate.rolesToRemove.push(...memberLevelRoles.values())
        }
        if (correctLevelRoleId != null) {
            const correctLevelRole = await this.dUtils.getRoleAsync(correctLevelRoleId, member.guild)
            rolesToUpdate.rolesToAdd.push(correctLevelRole)
        }
        return rolesToUpdate
    }

    //#endregion

    //#region Championship role management

    async findChampionshipRoleUpdate(rolesAdded: Collection<string, Role>, rolesRemoved: Collection<string, Role>, member: GuildMember): Promise<MemberRoleUpdate> {
        const guildId = member.guild.id
        const data = new ChampionshipsData(guildId)
        let championship: { id: string; data: ChampionshipsSettings; }
        try {
            championship = await data.getChampionshipAsync()
        }
        catch {
            return // The server is not part of any championship
        }

        let addPlayerRole = false
        let removePlayerRole = false

        const guildTeamsIds = championship.data.guilds[guildId].teamIds

        for (const [roleId] of rolesAdded) {
            if (guildTeamsIds.includes(roleId)) {
                console.log(`Added ${member.displayName} to a team. Role added : ${rolesAdded.get(roleId)}`)
                await data.addPlayersToTeam(roleId, member)
                addPlayerRole = true
                break;
            }
        }

        for (const [roleId] of rolesRemoved) {
            if (guildTeamsIds.includes(roleId)) {
                console.log(`Removed ${member.displayName} from a team. Role removed : ${rolesRemoved.get(roleId)}`)
                await data.removePlayersFromTeam(roleId, member.id)
                const otherTeamRole = member.roles.cache.find(r => guildTeamsIds.includes(r.id))
                if (otherTeamRole) {
                    await data.addPlayersToTeam(otherTeamRole.id, member) // Adds the player to this other team
                }
                else {
                    removePlayerRole = true
                }
                break;
            }
        }

        if (!addPlayerRole && !removePlayerRole) {
            return
        }

        const playerRoleId = (await data.getGuildSettingsAsync(guildId))?.playerRoleId
        if (!playerRoleId) {
            return
        }

        const playerRole = await this.dUtils.getRoleAsync(playerRoleId, member.guild)
        
        if (!playerRole) {
            await data.resetGuildRolesAsync(false, false, true)
            return
        }
        
        const roleUpdate = new MemberRoleUpdate()
        if (addPlayerRole) {
            if (!member.roles.cache.has(playerRole.id)) {
                roleUpdate.rolesToAdd.push(playerRole)
            }
        }
        else if (removePlayerRole) {
            if (member.roles.cache.has(playerRole.id)) {
                roleUpdate.rolesToRemove.push(playerRole)
            }
        }
        return roleUpdate
    }

    //#endregion
};
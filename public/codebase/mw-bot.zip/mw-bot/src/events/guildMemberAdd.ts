import { AttachmentBuilder, Events, GuildMember } from 'discord.js'
import Utils from '../utils/utils'
import WelcomeData from '../db-objects/data/welcome-data'
import BotRoleData from '../db-objects/data/bot-role'
import BaseEvent from './abstraction/baseEvent'
import { MWEmbedBuilder } from '../utils/common/sharedElements'

export default class GuildMemberAddEvent extends BaseEvent {
    name = Events.GuildMemberAdd
    override async execute(member: GuildMember) {
        await this.printWelcomeMessage(member)
        await this.manageNewBot(member)
    }

    async printWelcomeMessage(member: GuildMember) {
        const data = new WelcomeData(member.guild.id)
        await data.loadAsync()
    
        if (!data.welcomeChannel
            || (!data.message && !data.embedTitle && !data.embedContent && !data.attachmentLink)) {
            return
        }
    
        const welcomeChannel = await this.dUtils.getTextChannelAsync(data.welcomeChannel, member.guild)
    
        if (!welcomeChannel) {
            this.logError(`Couldn't find welcome channel with id ${data.welcomeChannel}`, member)
        }
    
        const messageContent = new Utils().replaceAll(data.message, '{user}', member)
        let embed: MWEmbedBuilder = null
        let attachmentFile: AttachmentBuilder = null
    
        if (data.embedTitle || data.embedContent) {
            embed = new MWEmbedBuilder()
                .setTitle(data.embedTitle)
                .setDescription(data.embedContent);
        }
    
        if (data.attachmentLink) {
            attachmentFile = new AttachmentBuilder(null)
                .setFile(data.attachmentLink)
        }
    
        welcomeChannel.send({ content: messageContent ? messageContent : null, embeds: embed ? [embed] : null, files: attachmentFile ? [attachmentFile] : null })
    }
    
    async manageNewBot(member: GuildMember) {
        if (member.user.bot) {
            const data = new BotRoleData(member.guild.id)
            await data.loadAsync()
    
            if (data.roleId) {
                const botRole = await this.dUtils.getRoleAsync(data.roleId, member.guild)
                member.roles.add(botRole)
            }
        }
    }
}


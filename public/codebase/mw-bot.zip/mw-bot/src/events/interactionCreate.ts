import { BaseInteraction, Events, MessageFlags, PermissionFlagsBits } from 'discord.js'
import BaseEvent from './abstraction/baseEvent'
import { InteractionError } from '../utils/common/sharedElements'
import ButtonManager from './interaction-managers/buttonManager'
import ChatInputCommandManager from './interaction-managers/chatInputCommandManager'
import UserSelectMenuManager from './interaction-managers/userSelectMenuManager'

export default class InteractionCreateEvent extends BaseEvent {
    name = Events.InteractionCreate
    UserSelectMenuManager = new UserSelectMenuManager()
    ButtonManager = new ButtonManager()
    ChatInputCommandManager = new ChatInputCommandManager()
    async execute(interaction: BaseInteraction) {
        try {
            if (interaction.isChatInputCommand()) {
                await this.ChatInputCommandManager.execute(interaction)
            }
            else if (interaction.isButton()) {
                await this.ButtonManager.execute(interaction)
            }
            else if (interaction.isUserSelectMenu()) {
                await this.UserSelectMenuManager.execute(interaction)
            }
        } catch (error) {
            if (!interaction.isChatInputCommand() && !interaction.isButton() && !interaction.isUserSelectMenu()) {
                return
            }
            const isAdmin = interaction.memberPermissions.has(PermissionFlagsBits.Administrator)
            const replyMethod = interaction.replied || interaction.deferred ? 'followUp' : 'reply';
            if (error instanceof InteractionError) {
                await interaction[replyMethod]({
                    content: `Error: ${error.message}`,
                    flags: error.ephemeral ? MessageFlags.Ephemeral : undefined
                });
                return
            }

            const errorMessage = `I apologize for the inconvenience—an error occurred while executing the command. Please contact Gor (\`@gornerzh\`) ${isAdmin ? 'using the `/contact-me` command or ': ''}in the Minute Wisdom Community (link in the bot profile) to solve the issue as soon as possible.`
            await interaction[replyMethod]({
                content: errorMessage + `\n**Error:** ${error.message}`
            });

            if (error instanceof Error) {
                this.logError(`Error message: ${error.message}\n${error.stack}`, interaction);
            }
            else {
                this.logError(`An unknown error occurred: ${error}`, interaction)
            }
        }
    }
}

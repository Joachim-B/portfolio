import { Events, Message, TextChannel, WebhookClient } from 'discord.js';
import ConnectData, { ChannelData } from '../db-objects/data/connect-data';
import BaseEvent from './abstraction/baseEvent';
import ChampionshipsData, { GuildSettings } from '../db-objects/data/championship-data';
import DiscordUtils from '../utils/discord-utils';
import Utils from '../utils/utils';
import Logger from '../utils/logger';

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

class MessageQueue {
    private queue: Array<() => Promise<void>> = [];
    private isProcessing = false;

    // Enqueue a new task and start processing if not already processing
    public async enqueue(task: () => Promise<void>) {
        this.queue.push(task);
        if (!this.isProcessing) {
            this.processQueue();
        }
    }

    // Process the tasks in the queue sequentially
    private async processQueue() {
        this.isProcessing = true;

        while (this.queue.length > 0) {
            const task = this.queue.shift();
            if (task) {
                try {
                    await task(); // Execute the task
                    await delay(2400);
                }
                catch {
                    new Logger().error('Queuing task failed', process.env.MW_GUILD)
                }
            }
        }

        this.isProcessing = false;
    }
}

export default class MessageCreateEvent extends BaseEvent {
    public name = Events.MessageCreate;
    private webhookCache: Map<string, WebhookCacheEntry> = new Map();  // Store both webhooks and their original names
    private messageQueues: Map<string, MessageQueue> = new Map(); // Queue map for each channel

    public async execute(message: Message): Promise<void> {
        if (message.author.bot && message.author.id !== message.client.user.id) {
            return;
        }

        const data = new ConnectData();
        await data.loadAsync();

        const hostId = data.channelToHost[message.channelId];
        if (!hostId) {
            return;
        }

        const connectedChannels = data.hostChannels[hostId].connectedChannels.filter(c => c.channelId !== message.channelId);

        const hostChampSettings = data.hostChannels[hostId].championshipChannel
            ? await new ChampionshipsData(message.guildId).getGuildSettingsAsync()
            : undefined;

        for (const channelData of connectedChannels) {
            const queue = this.getMessageQueueForChannel(channelData.channelId);
            queue.enqueue(async () => {
                await this.sendWebhookMessageInChannel(channelData, message, hostChampSettings);
            });
        }
    }

    private async sendWebhookMessageInChannel(
        data: ChannelData,
        message: Message,
        hostChampSettings: GuildSettings
    ): Promise<void> {

        const guild = message.client.guilds.cache.get(data.guildId);
        if (!guild) {
            return;
        }

        const channel = await new DiscordUtils().getTextChannelAsync(data.channelId, guild);
        if (!channel) {
            return;
        }

        let mainContent = message.content ?? '';
        mainContent = this.dUtils.utils.replaceAll(mainContent, '@everyone', '@ everyone')
        mainContent = this.dUtils.utils.replaceAll(mainContent, '@here', '@ here')

        if (hostChampSettings) {
            const champData = new ChampionshipsData(guild.id)
            const guildChampSettings = await champData.getGuildSettingsAsync();
            const canPing = !hostChampSettings.managerRoleId || message.member.roles.cache.has(hostChampSettings.managerRoleId);
            let champHostGuild: boolean;
            try {
                champHostGuild = data.guildId == await champData.getChampId()
            }
            catch {/* This guild is not part of any championship */ }
            mainContent = this.replaceRoles(mainContent, hostChampSettings, guildChampSettings, canPing, champHostGuild ?? false);
        }

        mainContent = mainContent.substring(0, 2000)

        await this.cacheWebhooksIfNotExists(channel, message);
        let cacheEntry = this.webhookCache.get(channel.id)

        if (!cacheEntry || cacheEntry.webhooks.length === 0) {
            return;
        }

        let webhookToUse: WebhookClient | null = null;

        // Check if the member is already linked to a specific webhook
        if (cacheEntry.memberLinkage.has(message.member.id)) {
            webhookToUse = cacheEntry.memberLinkage.get(message.member.id)!;
        } else {
            webhookToUse = this.linkWebHookToMember(cacheEntry, message.member.id)
            this.logger.info(`Linked webhook to user '${message.member.displayName}' in '#${channel.name}'`, channel.guildId)
        }

        try {
            await this.editWebHookAndSend(cacheEntry, webhookToUse, mainContent, channel, message)
        } catch {
            cacheEntry = await this.createAndCacheWebHooks(channel, message)
            webhookToUse = this.linkWebHookToMember(cacheEntry, message.member.id)
            this.logger.info(`Linked webhook to user '${message.member.displayName}' in '#${channel.name}'`, channel.guildId)
            await this.editWebHookAndSend(cacheEntry, webhookToUse, mainContent, channel, message)
        }
    }

    private async editWebHookAndSend(cacheEntry: WebhookCacheEntry, webhookToUse: WebhookClient, content: string, channel: TextChannel, message: Message) {
        const webHookIndex = cacheEntry.webhooks.indexOf(webhookToUse)

        const originalName = cacheEntry.names[webHookIndex];
        const avatarUrl = cacheEntry.avatarUrls[webHookIndex];

        if (originalName !== message.member.displayName || avatarUrl !== message.member.displayAvatarURL()) {
            const footer = `\n-# Sent from **${message.guild.name}**`;
            if (content.length + footer.length < 2000) {
                content += footer;
            }

            this.logger.info(`Editing webhook from channel '${channel.name}'. Name : '${message.member.displayName}'. WIndex : ${webHookIndex}`, channel.guildId)
            await webhookToUse.edit({ name: message.member.displayName, avatar: message.member.displayAvatarURL() });

            if (webHookIndex !== -1) {
                cacheEntry.names[webHookIndex] = message.member.displayName;
                cacheEntry.avatarUrls[webHookIndex] = message.member.displayAvatarURL();
            }
        }

        await webhookToUse.send({ content, embeds: message.embeds, files: Array.from(message.attachments.values()) })
    }

    private linkWebHookToMember(cacheEntry: WebhookCacheEntry, memberId: string) {
        cacheEntry = this.rotateFirstToLast(cacheEntry)
        const webhookToUse = cacheEntry.webhooks[0];
        cacheEntry.memberLinkage.set(memberId, webhookToUse);
        return webhookToUse
    }

    private replaceRoles(content: string, hostSettings: GuildSettings, guildSettings: GuildSettings, canPing: boolean, hostGuild: boolean): string {
        const utils = new Utils()
        if (hostSettings.managerRoleId) {
            content = utils.replaceAll(content, `<@&${hostSettings.managerRoleId}>`, hostGuild && guildSettings.managerRoleId ? `<@&${guildSettings.managerRoleId}>` : '@Championship Managers')
        }
        if (hostSettings.teamLeaderRoleId) {
            content = utils.replaceAll(content, `<@&${hostSettings.teamLeaderRoleId}>`, canPing && guildSettings.teamLeaderRoleId ? `<@&${guildSettings.teamLeaderRoleId}>` : '@Team Leaders')
        }
        if (hostSettings.playerRoleId) {
            content = utils.replaceAll(content, `<@&${hostSettings.playerRoleId}>`, canPing && guildSettings.playerRoleId ? `<@&${guildSettings.playerRoleId}>` : '@Challengers')
        }
        return content
    }

    private async cacheWebhooksIfNotExists(channel: TextChannel, message: Message) {
        // Check if the webhooks for this channel are already cached
        const cachedWebhooks = this.webhookCache.get(channel.id);
        if (!cachedWebhooks) {
            await this.createAndCacheWebHooks(channel, message)
        }
    }

    private async createAndCacheWebHooks(channel: TextChannel, message: Message) {
        try {
            // Fetch existing webhooks for the channel and filter those owned by the bot
            const webhooks = await channel.fetchWebhooks();
            const botOwnedWebhooks = Array.from(webhooks.values()).filter(w => w.owner?.id === message.client.user.id);

            // Create or use the first three webhooks owned by the bot
            const [webhook1, webhook2, webhook3] = await Promise.all(
                [1, 2, 3].map(async (i) => {
                    const existingWebhook = botOwnedWebhooks[i - 1];
                    if (existingWebhook) {
                        return existingWebhook;
                    }

                    const webhookName = 'MW-WebHook';
                    return await channel.createWebhook({ name: webhookName });
                })
            );

            // Store the original names and avatar URLs of the webhooks
            const names = [webhook1.name, webhook2.name, webhook3.name];
            const avatarUrls = [webhook1.avatarURL(), webhook2.avatarURL(), webhook3.avatarURL()];

            // Create WebhookClient instances for each webhook
            const webhookClients = [webhook1, webhook2, webhook3].map(w => new WebhookClient({ id: w.id, token: w.token }));

            // Initialize or reset member linkage for this channel
            const memberLinkage = new Map<string, WebhookClient>();

            const entry = new WebhookCacheEntry()
            entry.webhooks = webhookClients
            entry.names = names
            entry.avatarUrls = avatarUrls
            entry.memberLinkage = memberLinkage

            // Cache the webhooks, names, avatar URLs, and member linkage
            this.webhookCache.set(channel.id, entry);
            return entry

        } catch (error) {
            this.logger.error(`Error when creating webhooks : ${error}`, channel.guildId)
        }
    }

    // Returns the queue for a specific channel, creating one if it doesn't exist
    private getMessageQueueForChannel(channelId: string): MessageQueue {
        if (!this.messageQueues.has(channelId)) {
            this.messageQueues.set(channelId, new MessageQueue());
        }
        return this.messageQueues.get(channelId)!;
    }

    private rotateFirstToLast(entry: WebhookCacheEntry): WebhookCacheEntry {
        const arrays = [entry.webhooks, entry.names, entry.avatarUrls]
        arrays.forEach(array => {
            if (array.length > 0) {
                const firstElement = array.shift();
                array.push(firstElement as any);
            }
        });

        return entry
    }
}

class WebhookCacheEntry {
    webhooks: WebhookClient[];
    names: string[];
    avatarUrls: string[];
    memberLinkage: Map<string, WebhookClient>;
}
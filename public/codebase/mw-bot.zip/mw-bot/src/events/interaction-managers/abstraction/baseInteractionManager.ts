/* eslint @typescript-eslint/no-unsafe-function-type: 0 */
import BaseEvent from '../../abstraction/baseEvent';

export default abstract class BaseInteractionManager extends BaseEvent {
    eventType: Function;
    public name: string;

    constructor(eventType: Function) {
        super();  
        this.eventType = eventType; 
        this.name = this.eventType.name; 
    }
}

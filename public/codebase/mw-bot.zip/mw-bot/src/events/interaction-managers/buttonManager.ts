import { ButtonInteraction } from 'discord.js';
import ChampTeamConfigSubCommand from '../../commands/whitelist/championships/champ/team/config';
import ShowCommand from '../../commands/whitelist/championships/show';
import { InteractionPrefix } from '../../utils/common/sharedEnums';
import BaseInteractionManager from './abstraction/baseInteractionManager';
import RegistrationUtils from '../../utils/championship-utils/registration-utils';
import SubmitCommand from '../../commands/whitelist/championships/submit';

export default class ButtonManager extends BaseInteractionManager {
    async execute(interaction: ButtonInteraction): Promise<void> {
        const { customId } = interaction
        const interactionPrefix = customId.split('.')[0]
        
        switch (interactionPrefix) {
            case InteractionPrefix.champLeaderboard:
                return await new ShowCommand().handleLeaderboardButton(interaction)
            case InteractionPrefix.teamConfig:
                return await new ChampTeamConfigSubCommand().handleButtonClick(interaction)
            case InteractionPrefix.champRegister:
                return await new RegistrationUtils().handleJoinClick(interaction)
            case InteractionPrefix.champSubmit:
                return await new SubmitCommand().handleLeaderboardButton(interaction)
        }
    }

    constructor() {
        super(ButtonInteraction);
    }
}
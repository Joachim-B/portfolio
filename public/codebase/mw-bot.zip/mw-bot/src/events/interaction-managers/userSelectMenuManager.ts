import { UserSelectMenuInteraction } from 'discord.js';
import ChampTeamConfigSubCommand from '../../commands/whitelist/championships/champ/team/config';
import { InteractionPrefix } from '../../utils/common/sharedEnums';
import BaseInteractionManager from './abstraction/baseInteractionManager';

export default class UserSelectMenuManager extends BaseInteractionManager {
    async execute(interaction: UserSelectMenuInteraction): Promise<void> {
        const { customId } = interaction
        const interactionPrefix = customId.split('.')[0]

        switch (interactionPrefix) {
            case InteractionPrefix.teamConfig:
                return await new ChampTeamConfigSubCommand().handleUserSelectMenu(interaction)
        }
    }

    constructor() {
        super(UserSelectMenuInteraction)
    }
}
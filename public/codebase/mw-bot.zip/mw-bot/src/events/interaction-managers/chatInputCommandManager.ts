import { ApplicationCommandOptionType, ChatInputCommandInteraction } from 'discord.js';
import CacheManager from '../../utils/cache-manager';
import BaseInteractionManager from './abstraction/baseInteractionManager';

export default class ChatInputCommandManager extends BaseInteractionManager {
    async execute(interaction: ChatInputCommandInteraction): Promise<void> {
        this.log(`${interaction.user.username} - \`${this.writeFullCommand(interaction)}\``, interaction)

        const command = CacheManager.commands.get(
            interaction.commandName
        )

        if (!command) {
            this.logError(`No command matching ${interaction.commandName} was found.`, interaction)
            return
        }

        await command.execute(interaction)
    }

    constructor() {
        super(ChatInputCommandInteraction)
    }

    private writeFullCommand(interaction: ChatInputCommandInteraction): string {
        return `/${interaction.commandName}${this.writeSubCommand(interaction)}${this.writeParameters(interaction)}`
    }
    
    private writeSubCommand(interaction: ChatInputCommandInteraction): string {
        const subCommand = interaction.options.getSubcommandGroup(false) ?
            `${interaction.options.getSubcommandGroup(false)} ${interaction.options.getSubcommand(false)}` :
            interaction.options.getSubcommand(false) ? interaction.options.getSubcommand(false) : ''
    
        return subCommand ? ' ' + subCommand : ''
    }
    
    private writeParameters(interaction: ChatInputCommandInteraction): string {
        const parameters = !interaction.options.getSubcommand(false) ?
            interaction.options.data :
            interaction.options.getSubcommandGroup(false) ?
                interaction.options.data?.[0]?.options?.[0]?.options :
                interaction.options.data?.[0]?.options
    
        if (parameters.length > 0) {
            return ' ' + parameters.map(p => {
                let value: string;
                switch (p.type) {
                    case ApplicationCommandOptionType.Channel:
                        value = p.channel ? `#${p.channel.name}` : 'unknown-channel';
                        break;
                    case ApplicationCommandOptionType.User:
                        value = p.user ? `@${p.user.username}` : 'unknown-user';
                        break;
                    case ApplicationCommandOptionType.Role:
                        value = p.role ? `@${p.role.name}` : 'unknown-role';
                        break;
                    case ApplicationCommandOptionType.Mentionable:
                        value = p.user ? `@${p.user.username}` :
                            p.role ? `@${p.role.name}` : 'unknown-mentionable';
                        break;
                    default:
                        value = p.value.toString() || 'undefined'
                        break;
                }
    
                return `${p.name}:${value}`
            }).join(' ')
        }
        return ''
    }
}
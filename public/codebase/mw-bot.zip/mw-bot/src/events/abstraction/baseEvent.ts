
import DiscordUtils from '../../utils/discord-utils'
import Logger from '../../utils/logger'

export default abstract class BaseEvent {
    public async executeWithSuper(...args: any): Promise<void> {
        try
        {
            await this.execute(...args)
        }
        catch (error) {
            if (error instanceof Error) {
                this.logError(`Error message: ${error.message}\n${error.stack}`, args[0])
            } else {
                this.logError(`An unknown error occurred: ${error}`, args[0]);
            }
        }
    }
    public abstract name:string
    public abstract execute(...args: any) : Promise<void>
    public once = false
    protected logger = new Logger()
    protected dUtils = new DiscordUtils()

    protected log(message: string, args: any) {
        this.logger.info(`${this.name} | ${message}`, args.guild.id)
    }

    protected logError(message: string, args: any) {
        this.logger.error(`${this.name} | ${message}`, args.guild.id)
    }
}
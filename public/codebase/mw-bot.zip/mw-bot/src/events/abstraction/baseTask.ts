import { Client } from 'discord.js';

export interface ITask {
    interval: number; // Interval time in milliseconds
    execute: (client: Client) => Promise<void>; // Function to execute on interval
}
import { Events, Guild } from 'discord.js'
import BaseEvent from './abstraction/baseEvent'
import CacheManager from '../utils/cache-manager';
import ChampionshipUtils from '../utils/championship-utils/utils';

export default class GuildCreateEvent extends BaseEvent {
    name = Events.GuildCreate
    async execute(guild: Guild) {
        try {
            CacheManager.reloadGuildCommands(guild)
            await new ChampionshipUtils().reloadGuildCommandsChoices(guild.client, guild)
            CacheManager.addLogDataEntryIfNotExists(guild)
            this.logger.info(`Registered commands for guild: ${guild.name}`, guild.id);
        } catch (error) {
            const errorObject = error as Error
            this.logger.error(`Failed to register commands for guild ${guild.name}: ${errorObject.name} - ${errorObject.message}`, guild.id);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AidePrepaFac
{
    /// <summary>
    /// Logique d'interaction pour PagePrepaFacParam.xaml
    /// </summary>
    public partial class PagePrepaFacParam : Page
    {
        public PagePrepaFacParam()
        {
            InitializeComponent();
            cbDecimal.ItemsSource = new List<string>() { ", (Virgule)", ". (Point)" };
            SetValues();
        }

        private void SetValues()
        {
            txtColRefClientPF.Text = DataManager.Data.PF_PF_ReferenceClientColumn;
            txtColCommentaire.Text = DataManager.Data.PF_PF_CommentairePersoColumn;
            txtColFactuOuiNon.Text = DataManager.Data.PF_PF_FacturationColumn;
            txtColRefClientI.Text = DataManager.Data.PF_I_ReferenceClientColumn;
            txtColClos.Text = DataManager.Data.PF_I_ClosColumn;
            txtColDureeFacture.Text = DataManager.Data.PF_I_DureeFactureeColumn;
            txtChecked.Text = DataManager.Data.PF_Checked;
            txtUnchecked.Text = DataManager.Data.PF_Unchecked;
            cbDecimal.Text = DataManager.Data.PF_DecimalSign;
            txtLessThan1Day.Text = DataManager.Data.PF_MessageUnder1Day;
            txtColorLessThan1Day.Text = DataManager.Data.PF_ColorUnder1Day;
            txtNoInterv.Text = DataManager.Data.PF_MessageNoInterventions;
            txtColorNoInterv.Text = DataManager.Data.PF_ColorNoInterventions;
            txtNonClosedInterv.Text = DataManager.Data.PF_MessageUncheckedInterventions;
            txtColorNonClosedInterv.Text = DataManager.Data.PF_ColorUncheckedInterventions;
            txtFactuOK.Text = DataManager.Data.PF_MessageAllGood;
            txtColorFactuOK.Text = DataManager.Data.PF_ColorAllGood;
        }
    }
}

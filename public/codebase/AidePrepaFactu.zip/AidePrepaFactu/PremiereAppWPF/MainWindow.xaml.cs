﻿using AidePrepaFac;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PremiereAppWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public PagePrepaFac PagePrepaFac { get; set; } = new PagePrepaFac();
        public PagePrepaFacParam PagePrepaFacParam { get; set; } = new PagePrepaFacParam();
        public PageObtenirListeColonne PageObtenirListeColonne { get; set; } = new PageObtenirListeColonne();


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(PagePrepaFac);
            PagePrepaFac.OnClickParametrage += OnClickParametrage;
            MainFrame.Navigating += MainFrame_Navigating;
        }

        private void MainFrame_Navigating(object sender, NavigatingCancelEventArgs e)
        {
            SaveData();
        }

        private void OnClickParametrage(object? sender, EventArgs e)
        {
            ChangeFrameParamPrepaFac();
        }

        private void ChangeFramePrepaFac(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(PagePrepaFac);
        }

        private void ChangeFrameObtListeCol(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(PageObtenirListeColonne);
        }

        private void ChangeFrameParamPrepaFac()
        {
            MainFrame.Navigate(PagePrepaFacParam);
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            SaveData();
            DataManager.Save();
        }

        private void SaveData()
        {
            DataManager.Data = new JSONData()
            {
                PF_PrepaFacFilePath = PagePrepaFac.txtPrepaFacFile.Text,
                PF_InterventionFilePath = PagePrepaFac.txtIntervFile.Text,
                PF_PrepaFacSheetName = PagePrepaFac.txtFileName.Text,
                PF_PF_ReferenceClientColumn = PagePrepaFacParam.txtColRefClientPF.Text,
                PF_PF_CommentairePersoColumn = PagePrepaFacParam.txtColCommentaire.Text,
                PF_PF_FacturationColumn = PagePrepaFacParam.txtColFactuOuiNon.Text,
                PF_I_ReferenceClientColumn = PagePrepaFacParam.txtColRefClientI.Text,
                PF_I_ClosColumn = PagePrepaFacParam.txtColClos.Text,
                PF_I_DureeFactureeColumn = PagePrepaFacParam.txtColDureeFacture.Text,
                PF_Checked = PagePrepaFacParam.txtChecked.Text,
                PF_Unchecked = PagePrepaFacParam.txtUnchecked.Text,
                PF_DecimalSign = PagePrepaFacParam.cbDecimal.Text,
                PF_MessageUnder1Day = PagePrepaFacParam.txtLessThan1Day.Text,
                PF_ColorUnder1Day = PagePrepaFacParam.txtColorLessThan1Day.Text,
                PF_MessageNoInterventions = PagePrepaFacParam.txtNoInterv.Text,
                PF_ColorNoInterventions = PagePrepaFacParam.txtColorNoInterv.Text,
                PF_MessageUncheckedInterventions = PagePrepaFacParam.txtNonClosedInterv.Text,
                PF_ColorUncheckedInterventions = PagePrepaFacParam.txtColorNonClosedInterv.Text,
                PF_MessageAllGood = PagePrepaFacParam.txtFactuOK.Text,
                PF_ColorAllGood = PagePrepaFacParam.txtColorFactuOK.Text,

                OLC_FilePath = PageObtenirListeColonne.txtFilePath.Text,
                OLC_SheetName = PageObtenirListeColonne.txtSheetName.Text,
                OLC_HeaderColumnName = PageObtenirListeColonne.txtColName.Text,
                OLC_HeaderRowIndex = PageObtenirListeColonne.txtColIndex.Text,
                OLC_GroupSimilarValues = PageObtenirListeColonne.cbDistinct.IsChecked ?? false,
                OLC_AlphabeticalOrder = PageObtenirListeColonne.cbAlphabetic.IsChecked ?? false,
            };
        }
    }
}

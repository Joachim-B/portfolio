﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AidePrepaFac
{
    public class ExcelHelper
    {
        public XLWorkbook Workbook;
        public IXLWorksheet Worksheet;

        public ExcelHelper()
        {
        }

        public ExcelHelper(XLWorkbook workbook, IXLWorksheet worksheet)
        {
            Workbook = workbook;
            Worksheet = worksheet;
        }

        public static bool TryOpenFile(string filePath)
        {
            try
            {
                using (XLWorkbook workbook = new XLWorkbook(filePath)) { }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<int> GetNonEmptyCellIndices(string columnName)
        {
            List<int> nonEmptyIndices = new List<int>();

            var column = Worksheet.Column(columnName);

            int rowIndex = 1;
            foreach (var cell in column.CellsUsed())
            {
                if (!cell.IsEmpty())
                {
                    nonEmptyIndices.Add(rowIndex);
                }

                rowIndex++;
            }

            return nonEmptyIndices;
        }

        public List<string> GetColumnsWithFilter(int rowIndex, string filter)
        {
            List<string> columnsWithFilter = new List<string>();

            var row = Worksheet.Row(rowIndex);

            foreach (var cell in row.CellsUsed())
            {
                if (cell.Value.ToString() == filter)
                {
                    columnsWithFilter.Add(cell.WorksheetColumn().ColumnLetter());
                }
            }

            return columnsWithFilter;
        }

        public string GetCellValue(string cellReference)
        {
            return Worksheet.Cell(cellReference).GetString();
        }

        public List<string> GetColumnValues(string column, int? startLine = null, int? endLine = null)
        {
            if (startLine.HasValue && startLine.Value == 0)
            {
                throw new ArgumentException("La ligne de départ doit être supérieure ou égale à 1.");
            }

            if (endLine.HasValue && startLine.HasValue && endLine.Value < startLine.Value)
            {
                throw new ArgumentException("La ligne de fin doit être supérieure ou égale à la ligne de départ.");
            }

            List<string> columnValues = new List<string>();

            IEnumerable<int> rows = Worksheet.RowsUsed().Select(r => r.RowNumber());

            if (startLine.HasValue)
            {
                rows = rows.Where(row => row >= startLine.Value);
            }

            if (endLine.HasValue)
            {
                rows = rows.Where(row => row <= endLine.Value);
            }

            foreach (int row in rows)
            {
                IXLCell? targetCell = Worksheet.Cell(row, column);
                if (targetCell != null)
                {
                    string cellValue = targetCell.GetString();
                    columnValues.Add(cellValue);
                }
            }

            return columnValues;
        }

        public static void ColorRowCells(IXLRow row, string hexColor, string startColumn, string endColumn)
        {
            XLColor color;
            if (string.IsNullOrEmpty(hexColor))
            {
                color = XLColor.Transparent;
            }
            else
            {
                if (!hexColor.StartsWith("#"))
                {
                    hexColor = "#" + hexColor;
                }

                color = XLColor.FromHtml(hexColor);
            }
            
            foreach (IXLCell cell in row.Cells(startColumn, endColumn))
            {
                cell.Style.Fill.BackgroundColor = color;
            }
        }
    }
}

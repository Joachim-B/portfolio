﻿using Newtonsoft.Json;
using System.IO;

namespace AidePrepaFac
{
    public static class DataManager
    {
        static DataManager()
        {
            LoadJSONData();
        }

        private static string FileName = @".\data.json";

        public static JSONData Data { get; set; } = new();

        private static void LoadJSONData()
        {
            if (!File.Exists(FileName))
            {
                File.Create(FileName);
            }

            using (StreamReader reader = new StreamReader(FileName))
            {
                string json = reader.ReadToEnd();

                JSONData? jsonData = JsonConvert.DeserializeObject<JSONData>(json);

                if (jsonData != null)
                {
                    Data = jsonData;
                }
                else
                {
                    Data = new JSONData();
                }
            }
        }

        public static void Save()
        {
            if (!File.Exists(FileName))
            {
                File.Create(FileName);
            }

            string json = JsonConvert.SerializeObject(Data, Formatting.Indented);
            File.WriteAllText(FileName, json);
        }
    }
}

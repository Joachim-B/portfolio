﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AidePrepaFac
{
    public class JSONData
    {
        #region Prépa fac

        public string PF_PrepaFacFilePath { get; set; } = string.Empty;
        public string PF_InterventionFilePath { get; set; } = string.Empty;
        public string PF_PrepaFacSheetName { get; set; } = string.Empty;

        public string PF_PF_ReferenceClientColumn { get; set; } = string.Empty;
        public string PF_PF_FacturationColumn { get; set; } = string.Empty;
        public string PF_PF_CommentairePersoColumn { get; set; } = string.Empty;
        public string PF_I_ReferenceClientColumn { get; set; } = string.Empty;
        public string PF_I_ClosColumn { get; set; } = string.Empty;
        public string PF_I_DureeFactureeColumn { get; set; } = string.Empty;
        public string PF_Checked { get; set; } = string.Empty;
        public string PF_Unchecked { get; set; } = string.Empty;
        public string PF_DecimalSign { get; set; } = string.Empty;
        public string PF_MessageUnder1Day { get; set; } = string.Empty;
        public string PF_MessageUncheckedInterventions { get; set; } = string.Empty;
        public string PF_MessageAllGood { get; set; } = string.Empty;
        public string PF_MessageNoInterventions { get; set; } = string.Empty;
        public string PF_ColorUnder1Day { get; set; } = string.Empty;
        public string PF_ColorUncheckedInterventions { get; set; } = string.Empty;
        public string PF_ColorAllGood { get; set; } = string.Empty;
        public string PF_ColorNoInterventions { get; set; } = string.Empty;

        #endregion

        #region Obtenir liste colonne

        public string OLC_FilePath { get; set; } = string.Empty;
        public string OLC_SheetName { get;set; } = string.Empty;
        public string OLC_HeaderColumnName { get; set; } = string.Empty;
        public string OLC_HeaderRowIndex { get; set; } = string.Empty;
        public bool OLC_GroupSimilarValues { get; set; }
        public bool OLC_AlphabeticalOrder { get; set; }

        #endregion
    }
}

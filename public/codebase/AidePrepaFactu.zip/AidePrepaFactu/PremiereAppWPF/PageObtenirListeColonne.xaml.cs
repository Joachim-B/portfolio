﻿using AidePrepaFac;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using Page = System.Windows.Controls.Page;

namespace PremiereAppWPF
{
    /// <summary>
    /// Logique d'interaction pour PageObtenirListeColonne.xaml
    /// </summary>
    public partial class PageObtenirListeColonne : Page
    {
        public PageObtenirListeColonne()
        {
            InitializeComponent();
            SetValues();
        }

        public ExcelHelper ExcelHelper { get; set; }

        private void SetValues()
        {
            txtFilePath.Text = DataManager.Data.OLC_FilePath;
            txtSheetName.Text = DataManager.Data.OLC_SheetName;
            txtColName.Text = DataManager.Data.OLC_HeaderColumnName;
            txtColIndex.Text = DataManager.Data.OLC_HeaderRowIndex;
            cbDistinct.IsChecked = DataManager.Data.OLC_GroupSimilarValues;
            cbAlphabetic.IsChecked = DataManager.Data.OLC_AlphabeticalOrder;
        }

        private void BtnSelectFilePrepaFac(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Fichiers Excel (*.xlsx)|*.xlsx|Tous les fichiers (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                // Obtenir le chemin du fichier sélectionné
                string filePath = openFileDialog.FileName;

                // Mettre à jour le TextBox avec le chemin du fichier
                txtFilePath.Text = filePath;
            }
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void Btn_GetColValues(object sender, RoutedEventArgs e)
        {
            string colName = txtColName.Text;
            int rowIndex = int.Parse(txtColIndex.Text);

            bool selectDistinct = cbDistinct.IsChecked.GetValueOrDefault();
            bool alphabeticOrder = cbAlphabetic.IsChecked.GetValueOrDefault();

            string filePath = txtFilePath.Text;
            string sheetName = txtSheetName.Text;

            if (string.IsNullOrEmpty(filePath)
                || string.IsNullOrEmpty(sheetName))
            {
                MessageBox.Show("Certaines informations sont manquantes pour lancer le traitement.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            txtResult.Text = GetTiersFacturesList(filePath, sheetName, colName, rowIndex, selectDistinct, alphabeticOrder);
        }

        public string GetTiersFacturesList(string filePath, string sheetName, string colName, int rowIndex, bool selectDistinct, bool alphabeticOrder)
        {
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                using (XLWorkbook workbook = new XLWorkbook(filePath))
                {
                    IXLWorksheet ws;
                    if (string.IsNullOrEmpty(sheetName))
                        ws = workbook.Worksheet(1);
                    else
                        ws = workbook.Worksheet(sheetName);
                    ExcelHelper = new ExcelHelper(workbook, ws);

                    workbook.Save(true);


                    List<string> results = ExcelHelper.GetColumnsWithFilter(rowIndex, colName);

                    if (results.Count == 0)
                    {
                        return "Aucune cellule ne contient le filtre";
                    }

                    string column = results[0];

                    List<string> values = ExcelHelper.GetColumnValues(column, 2);

                    if (selectDistinct)
                        values = values.Distinct().ToList();

                    if (alphabeticOrder)
                        values = values.OrderBy(x => x).ToList();

                    return string.Join(Environment.NewLine, values);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return "";
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }
    }
}

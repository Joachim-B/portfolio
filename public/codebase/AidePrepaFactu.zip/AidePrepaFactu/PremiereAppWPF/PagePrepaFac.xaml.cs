﻿using AidePrepaFac;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Drawing;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Presentation;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace PremiereAppWPF
{
    /// <summary>
    /// Logique d'interaction pour PagePrepaFac.xaml
    /// </summary>
    public partial class PagePrepaFac : System.Windows.Controls.Page
    {
        public PagePrepaFac()
        {
            InitializeComponent();
            SetValues();
        }

        public event EventHandler OnClickParametrage;

        public ExcelHelper ExcelHelperPF { get; set; }
        public ExcelHelper ExcelHelperI { get; set; }

        private void SetValues()
        {
            txtPrepaFacFile.Text = DataManager.Data.PF_PrepaFacFilePath;
            txtIntervFile.Text = DataManager.Data.PF_InterventionFilePath;
            txtFileName.Text = DataManager.Data.PF_PrepaFacSheetName;
        }

        private void BtnSelectFilePrepaFac(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Fichiers Excel (*.xlsx)|*.xlsx|Tous les fichiers (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                txtPrepaFacFile.Text = filePath;
            }
        }

        private void BtnSelectFileInterv(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Fichiers Excel (*.xlsx)|*.xlsx|Tous les fichiers (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                txtIntervFile.Text = filePath;
            }
        }

        private void Btn_LancerTraitement(object sender, RoutedEventArgs e)
        {
            if (ControlerDonnees())
            {
                LancerTraitement();
            }
        }

        private bool ControlerDonnees()
        {
            if (string.IsNullOrEmpty(txtPrepaFacFile.Text)
                || string.IsNullOrEmpty(txtFileName.Text)
                || string.IsNullOrEmpty(txtIntervFile.Text)
                || string.IsNullOrEmpty(DataManager.Data.PF_PF_ReferenceClientColumn)
                || string.IsNullOrEmpty(DataManager.Data.PF_PF_FacturationColumn)
                || string.IsNullOrEmpty(DataManager.Data.PF_PF_CommentairePersoColumn)
                || string.IsNullOrEmpty(DataManager.Data.PF_I_ReferenceClientColumn)
                || string.IsNullOrEmpty(DataManager.Data.PF_I_ClosColumn)
                || string.IsNullOrEmpty(DataManager.Data.PF_I_DureeFactureeColumn)
                || string.IsNullOrEmpty(DataManager.Data.PF_DecimalSign))
            {
                MessageBox.Show("Certaines informations sont manquantes pour lancer le traitement. Vérifiez notamment dans la page de paramétrage.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }

        private void LancerTraitement()
        {
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                using (XLWorkbook workbookPF = new XLWorkbook(txtPrepaFacFile.Text))
                using (XLWorkbook workbookI = new XLWorkbook(txtIntervFile.Text))
                {
                    IXLWorksheet wsPF = workbookPF.Worksheet(txtFileName.Text);
                    IXLWorksheet wsI = workbookI.Worksheet(1);

                    ExcelHelperPF = new ExcelHelper(workbookPF, wsPF);
                    ExcelHelperI = new ExcelHelper(workbookI, wsI);

                    List<InterventionData> interventions = GetInterventionDatas();

                    string clientRefColumnName = DataManager.Data.PF_PF_ReferenceClientColumn;
                    string clientRefColumn = ExcelHelperPF.GetColumnsWithFilter(1, clientRefColumnName).FirstOrDefault() ?? string.Empty;

                    if (string.IsNullOrEmpty(clientRefColumn))
                    {
                        throw new Exception("La colonne \"" + clientRefColumnName + "\" n'a pas été trouvée.");
                    }

                    List<string> listReferencesName = ExcelHelperPF.GetColumnValues(clientRefColumn, 2);
                    interventions = interventions.Where(x => listReferencesName.Contains(x.ClientReference)).ToList();

                    string nbReferencesWithPrestas = "Nombre de références client avec prestations : " + interventions.Count;

                    List<string> results = EditPrepaFacPage(interventions);

                    txtResult.Text = nbReferencesWithPrestas +
                        Environment.NewLine +
                        Environment.NewLine +
                        string.Join(Environment.NewLine + Environment.NewLine, results);

                    workbookPF.Save(true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }

        private List<InterventionData> GetInterventionDatas()
        {
            List<InterventionData> interventions = new List<InterventionData>();

            string refClientColumnName = DataManager.Data.PF_I_ReferenceClientColumn;
            string closedColumnName = DataManager.Data.PF_I_ClosColumn;
            string closedColumn = ExcelHelperI.GetColumnsWithFilter(1, closedColumnName).FirstOrDefault() ?? string.Empty;
            string timeSpentColumnName = DataManager.Data.PF_I_DureeFactureeColumn;
            string timeSpentColumn = ExcelHelperI.GetColumnsWithFilter(1, timeSpentColumnName).FirstOrDefault() ?? string.Empty;

            if (string.IsNullOrEmpty(closedColumn))
            {
                throw new Exception("Impossible de trouver la colonne \"" + closedColumnName + "\" dans la feuille des interventions.");
            }
            if (string.IsNullOrEmpty(timeSpentColumn))
            {
                throw new Exception("Impossible de trouver la colonne \"" + timeSpentColumnName + "\" dans la feuille des interventions.");
            }

            foreach (IXLRow row in ExcelHelperI.Worksheet.Rows().Skip(1))
            {
                string cellValue = row.Cell("B").GetString();

                if (!cellValue.Contains(refClientColumnName))
                {
                    continue;
                }

                string clientRef = cellValue.Replace(refClientColumnName + ":", string.Empty).Trim();

                interventions.Add(AddInterventionData(row.RowNumber(), clientRef, timeSpentColumn, closedColumn));
            }

            return interventions;
        }

        private InterventionData AddInterventionData(int headerRow, string clientRefName, string timeSpentColumn, string closedColumn)
        {
            bool nonClosedInterventions = false;
            double facturedTime = 0;

            string checkedCell = DataManager.Data.PF_Checked;
            string uncheckedCell = DataManager.Data.PF_Unchecked;

            int currentRow = headerRow + 1;
            string closedCellValue = ExcelHelperI.GetCellValue(closedColumn + currentRow);
            CultureInfo culture = DataManager.Data.PF_DecimalSign == ", (Virgule)" ? new CultureInfo("fr-FR") : new CultureInfo("en-US");

            while (!string.IsNullOrEmpty(closedCellValue)
                && (closedCellValue == checkedCell || closedCellValue == uncheckedCell))
            {
                if (closedCellValue == uncheckedCell)
                {
                    nonClosedInterventions |= true;
                }

                string tempsPasse = ExcelHelperI.GetCellValue(timeSpentColumn + currentRow);

                double fTime = double.Parse(tempsPasse, culture);

                facturedTime += fTime;

                currentRow++;
                closedCellValue = ExcelHelperI.GetCellValue(closedColumn + currentRow);
            }

            string facturationOuiNon;
            string intervComment;
            string color;

            if (facturedTime < 1)
            {
                facturationOuiNon = "NON";
                intervComment = EditPersonalComment(DataManager.Data.PF_MessageUnder1Day, Math.Round(facturedTime, 2));
                color = DataManager.Data.PF_ColorUnder1Day;
            }
            else if (nonClosedInterventions)
            {
                facturationOuiNon = "OUI";
                intervComment = EditPersonalComment(DataManager.Data.PF_MessageUncheckedInterventions, Math.Round(facturedTime, 2));
                color = DataManager.Data.PF_ColorUncheckedInterventions;
            }
            else
            {
                facturationOuiNon = "OUI";
                intervComment = EditPersonalComment(DataManager.Data.PF_MessageAllGood, Math.Round(facturedTime, 2));
                color = DataManager.Data.PF_ColorAllGood;
            }

            InterventionData interventionData = new InterventionData()
            {
                ClientReference = clientRefName,
                FacturationOuiNon = facturationOuiNon,
                Comment = intervComment,
                Color = color
            };

            return interventionData;
        }

        private List<string> EditPrepaFacPage(List<InterventionData> interventions)
        {
            List<string> processResults = new List<string>();

            string clientRefColumnName = DataManager.Data.PF_PF_ReferenceClientColumn;
            string clientRefColumn = ExcelHelperPF.GetColumnsWithFilter(1, clientRefColumnName).FirstOrDefault() ?? string.Empty;

            string facturationColumnName = DataManager.Data.PF_PF_FacturationColumn;
            string facturationColumn = ExcelHelperPF.GetColumnsWithFilter(1, facturationColumnName).FirstOrDefault() ?? string.Empty;

            string commentColumnName = DataManager.Data.PF_PF_CommentairePersoColumn;
            string commentColumn = ExcelHelperPF.GetColumnsWithFilter(1, commentColumnName).FirstOrDefault() ?? string.Empty;

            var rows = ExcelHelperPF.Worksheet.Rows();

            foreach (IXLRow row in rows.Skip(1))
            {
                IXLCell? clientRefCell = row.Cell(clientRefColumn);

                if (clientRefCell != null)
                {
                    string clientReference = clientRefCell.GetString().Trim();
                    InterventionData? intervention = interventions.FirstOrDefault(i => i.ClientReference == clientReference);

                    string factuOuiNonContent;
                    string commentContent;
                    string colorValue;

                    if (intervention != null)
                    {
                        factuOuiNonContent = intervention.FacturationOuiNon;
                        commentContent = intervention.Comment;
                        colorValue = intervention.Color;

                        interventions.Remove(intervention);
                    }
                    else
                    {
                        factuOuiNonContent = "NON";
                        commentContent = EditPersonalComment(DataManager.Data.PF_MessageNoInterventions);
                        colorValue = DataManager.Data.PF_ColorNoInterventions;
                    }

                    IXLCell facturationCell = row.Cell(facturationColumn);
                    IXLCell commentCell = row.Cell(commentColumn);

                    facturationCell.Value = factuOuiNonContent;
                    commentCell.Value = commentContent;
                    commentCell.Style.Alignment.WrapText = true;
                    SetRowColor(row, colorValue);

                    string logResult = $"{clientReference} :{Environment.NewLine}Facturation : {factuOuiNonContent}{Environment.NewLine}Commentaire : {commentContent}";

                    processResults.Add(logResult);
                }
            }
            return processResults;
        }

        private string EditPersonalComment(string text, double facturedTime = 0)
        {
            return text.Replace("[Date]", DateTime.Now.ToString("dd/MM/yyyy"))
                .Replace("[Temps]", facturedTime.ToString());
        }

        private void SetRowColor(IXLRow row, string color)
        {
            IXLRow headerRow = ExcelHelperPF.Worksheet.Row(1);
            string lastColumnName = headerRow.LastCellUsed().Address.ColumnLetter;

            ExcelHelper.ColorRowCells(row, color, "A", lastColumnName);
        }

        private class InterventionData
        {
            public string ClientReference { get; set; } = string.Empty;
            public string FacturationOuiNon { get; set; } = string.Empty;
            public string Comment { get; set; } = string.Empty;
            public string Color { get; set; } = string.Empty;
        }

        private void Btn_PageParametrage(object sender, RoutedEventArgs e)
        {
            OnClickParametrage(sender, e);
        }
    }
}
